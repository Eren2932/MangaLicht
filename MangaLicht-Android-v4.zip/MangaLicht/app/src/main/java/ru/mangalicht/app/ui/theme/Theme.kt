package ru.mangalicht.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Токены сайта, которых нет в Material-схеме. */
data class MlColors(
    val bgMain: Color,
    val block: Color,
    val blockInner: Color,
    val border: Color,
    val brand: Color,
    val accent: Color,
    val yellow: Color,
    val positive: Color,
    val textMain: Color,
    val textMuted: Color,
    val textGhost: Color,
    val chip: Color,
    val chipSelected: Color,
    val overlay: Color,
    val isDark: Boolean
)

private val DarkMl = MlColors(
    bgMain = Palette.black,
    block = Color(0xFF121215),
    blockInner = Palette.grey800,
    border = Color(0xFF232327),
    brand = Palette.alertDark,
    accent = Palette.accentDark,
    yellow = Palette.yellowDark,
    positive = Palette.greenDark,
    textMain = Palette.white,
    textMuted = Palette.grey100,
    textGhost = Color(0x4DE4E5E7),
    chip = Palette.grey800,
    chipSelected = Palette.alertDark,
    overlay = Color(0xCC000000),
    isDark = true
)

private val LightMl = MlColors(
    bgMain = Palette.white,
    block = Palette.grey50,
    blockInner = Palette.white,
    border = Color(0xFFD8DADE),
    brand = Palette.alertLight,
    accent = Palette.accentLight,
    yellow = Palette.yellowLight,
    positive = Palette.greenLight,
    textMain = Palette.black,
    textMuted = Palette.grey500,
    textGhost = Color(0x4D000000),
    chip = Color(0xFFEDEEF0),
    chipSelected = Palette.alertLight,
    overlay = Color(0x99000000),
    isDark = false
)

val LocalMlColors = staticCompositionLocalOf { DarkMl }

private val darkScheme = darkColorScheme(
    primary = Palette.alertDark,
    onPrimary = Palette.white,
    secondary = Palette.accentDark,
    onSecondary = Palette.white,
    tertiary = Palette.yellowDark,
    background = Palette.black,
    onBackground = Palette.white,
    surface = Palette.black,
    onSurface = Palette.white,
    surfaceVariant = Palette.grey800,
    onSurfaceVariant = Palette.grey100,
    outline = Color(0xFF232327),
    error = Palette.alertDark
)

private val lightScheme = lightColorScheme(
    primary = Palette.alertLight,
    onPrimary = Palette.white,
    secondary = Palette.accentLight,
    onSecondary = Palette.white,
    tertiary = Palette.yellowLight,
    background = Palette.white,
    onBackground = Palette.black,
    surface = Palette.white,
    onSurface = Palette.black,
    surfaceVariant = Palette.grey50,
    onSurfaceVariant = Palette.grey500,
    outline = Color(0xFFD8DADE),
    error = Palette.alertLight
)

/** Радиусы мобильной сетки сайта: 12dp. */
private val MlShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(12.dp),
    large = RoundedCornerShape(16.dp),
    extraLarge = RoundedCornerShape(22.dp)
)

private val MlTypography = Typography(
    displaySmall = TextStyle(fontSize = 30.sp, lineHeight = 36.sp, fontWeight = FontWeight.Black),
    headlineMedium = TextStyle(fontSize = 26.sp, lineHeight = 32.sp, fontWeight = FontWeight.Bold),
    headlineSmall = TextStyle(fontSize = 22.sp, lineHeight = 28.sp, fontWeight = FontWeight.Bold),
    titleLarge = TextStyle(fontSize = 19.sp, lineHeight = 25.sp, fontWeight = FontWeight.Bold),
    titleMedium = TextStyle(fontSize = 16.sp, lineHeight = 21.sp, fontWeight = FontWeight.SemiBold),
    titleSmall = TextStyle(fontSize = 14.sp, lineHeight = 19.sp, fontWeight = FontWeight.SemiBold),
    bodyLarge = TextStyle(fontSize = 15.sp, lineHeight = 22.sp),
    bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 20.sp),
    bodySmall = TextStyle(fontSize = 13.sp, lineHeight = 18.sp),
    labelLarge = TextStyle(fontSize = 14.sp, lineHeight = 18.sp, fontWeight = FontWeight.SemiBold),
    labelMedium = TextStyle(fontSize = 12.sp, lineHeight = 16.sp, fontWeight = FontWeight.Medium),
    labelSmall = TextStyle(fontSize = 11.sp, lineHeight = 14.sp, fontWeight = FontWeight.Medium)
)

@Composable
fun MangaLichtTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val ml = if (darkTheme) DarkMl else LightMl
    CompositionLocalProvider(LocalMlColors provides ml) {
        MaterialTheme(
            colorScheme = if (darkTheme) darkScheme else lightScheme,
            shapes = MlShapes,
            typography = MlTypography,
            content = content
        )
    }
}

/** Короткий доступ: `ml.brand`, `ml.block` и т.д. */
val ml: MlColors
    @Composable get() = LocalMlColors.current
