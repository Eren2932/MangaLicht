package ru.mangalicht.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import ru.mangalicht.app.data.MangaTitle
import ru.mangalicht.app.ui.theme.ml

/** Вертикальная карточка каталога, как в сетке на сайте. */
@Composable
fun TitleCard(
    title: MangaTitle,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val c = ml
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
    ) {
        Box {
            ProceduralCover(
                seed = title.id,
                label = title.title,
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(0.68f)
            )
            Box(Modifier.padding(6.dp)) { RatingBadge(title.rating) }
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(6.dp)
            ) {
                MlTag(title.status.label)
            }
        }
        Spacer(Modifier.height(8.dp))
        Text(
            title.title,
            style = MaterialTheme.typography.titleSmall,
            color = c.textMain,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )
        Spacer(Modifier.height(2.dp))
        Text(
            title.subtitle,
            style = MaterialTheme.typography.labelSmall,
            color = c.textMuted,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

/** Горизонтальная строка тайтла: для закладок, истории, обновлений. */
@Composable
fun TitleRow(
    title: MangaTitle,
    secondary: String,
    trailing: String? = null,
    onClick: () -> Unit
) {
    val c = ml
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        ProceduralCover(
            seed = title.id,
            label = title.title,
            modifier = Modifier
                .width(48.dp)
                .height(66.dp),
            corner = 8
        )
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                title.title,
                style = MaterialTheme.typography.titleSmall,
                color = c.textMain,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(3.dp))
            Text(
                secondary,
                style = MaterialTheme.typography.labelSmall,
                color = c.textMuted,
                maxLines = 1
            )
        }
        if (trailing != null) {
            Spacer(Modifier.width(8.dp))
            Text(trailing, style = MaterialTheme.typography.labelSmall, color = c.textGhost)
        }
    }
}

/** Карточка для горизонтальных каруселей главного экрана. */
@Composable
fun CarouselCard(title: MangaTitle, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .width(126.dp)
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
    ) {
        Box {
            ProceduralCover(
                seed = title.id,
                label = title.title,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
            )
            Box(Modifier.padding(6.dp)) { RatingBadge(title.rating) }
        }
        Spacer(Modifier.height(6.dp))
        Text(
            title.title,
            style = MaterialTheme.typography.labelLarge,
            color = ml.textMain,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )
        Text(
            title.subtitle,
            style = MaterialTheme.typography.labelSmall,
            color = ml.textMuted,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun HorizontalTitleCarousel(
    titles: List<MangaTitle>,
    onOpen: (String) -> Unit
) {
    androidx.compose.foundation.lazy.LazyRow(
        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(count = titles.size, key = { titles[it].id }) { index ->
            val item = titles[index]
            CarouselCard(item) { onOpen(item.id) }
        }
    }
}
