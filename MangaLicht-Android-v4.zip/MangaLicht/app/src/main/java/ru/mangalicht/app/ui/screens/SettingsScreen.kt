package ru.mangalicht.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import ru.mangalicht.app.data.UserLibrary
import ru.mangalicht.app.ui.components.MlChip
import ru.mangalicht.app.ui.theme.ml

@Composable
fun SettingsScreen(onBack: () -> Unit) {
    val c = ml
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                Icons.AutoMirrored.Filled.ArrowBack,
                "Назад",
                tint = c.textMain,
                modifier = Modifier
                    .size(24.dp)
                    .clickable(onClick = onBack)
            )
            Spacer(Modifier.width(12.dp))
            Text("Настройки", style = MaterialTheme.typography.headlineSmall, color = c.textMain)
        }

        Column(Modifier.padding(horizontal = 16.dp)) {
            Block {
                Text("Оформление", style = MaterialTheme.typography.titleSmall, color = c.textMain)
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Тёмная тема", style = MaterialTheme.typography.bodyMedium, color = c.textMain)
                        Text(
                            "Палитра сайта MangaLicht",
                            style = MaterialTheme.typography.labelSmall,
                            color = c.textMuted
                        )
                    }
                    Switch(
                        checked = UserLibrary.darkTheme.value,
                        onCheckedChange = { UserLibrary.setDarkTheme(it) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = c.brand,
                            checkedTrackColor = c.brand.copy(alpha = 0.35f)
                        )
                    )
                }
            }
            Spacer(Modifier.height(12.dp))
            Block {
                Text("Читалка", style = MaterialTheme.typography.titleSmall, color = c.textMain)
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    MlChip("Вертикальная лента", selected = UserLibrary.readerMode.value == 0) {
                        UserLibrary.setReaderMode(0)
                    }
                    MlChip("Постранично", selected = UserLibrary.readerMode.value == 1) {
                        UserLibrary.setReaderMode(1)
                    }
                }
                Spacer(Modifier.height(12.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            "Не скрывать панели",
                            style = MaterialTheme.typography.bodyMedium,
                            color = c.textMain
                        )
                        Text(
                            "Панели чтения останутся на экране",
                            style = MaterialTheme.typography.labelSmall,
                            color = c.textMuted
                        )
                    }
                    Switch(
                        checked = UserLibrary.readerKeepUi.value,
                        onCheckedChange = { UserLibrary.setReaderKeepUi(it) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = c.brand,
                            checkedTrackColor = c.brand.copy(alpha = 0.35f)
                        )
                    )
                }
            }
            Spacer(Modifier.height(12.dp))
            Block {
                Text("О приложении", style = MaterialTheme.typography.titleSmall, color = c.textMain)
                Spacer(Modifier.height(8.dp))
                Text(
                    "MangaLicht 0.3.0 · клиент для manga licht. " +
                        "Каталог и форум работают на демо-данных, сетевой слой подключается без изменения экранов.",
                    style = MaterialTheme.typography.bodySmall,
                    color = c.textMuted
                )
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}
