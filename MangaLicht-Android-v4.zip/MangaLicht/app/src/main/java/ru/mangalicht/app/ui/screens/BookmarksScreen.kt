package ru.mangalicht.app.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import ru.mangalicht.app.data.MangaRepository
import ru.mangalicht.app.data.ReadingStatus
import ru.mangalicht.app.data.UserLibrary
import ru.mangalicht.app.ui.components.EmptyState
import ru.mangalicht.app.ui.components.MlTabRow
import ru.mangalicht.app.ui.components.TitleRow
import ru.mangalicht.app.ui.theme.ml

@Composable
fun BookmarksScreen(onOpenTitle: (String) -> Unit, onOpenCatalog: () -> Unit) {
    val c = ml
    var tab by rememberSaveable { mutableStateOf(0) }
    val tabs = remember { ReadingStatus.entries.map { it.label } + "Избранное" }

    val library = remember(tab, UserLibrary.statuses.size, UserLibrary.favorites.size) {
        if (tab == ReadingStatus.entries.size) MangaRepository.favorites()
        else MangaRepository.libraryOf(ReadingStatus.entries[tab])
    }
    val badges = remember(UserLibrary.statuses.size, UserLibrary.favorites.size) {
        ReadingStatus.entries.mapIndexed { index, status -> index to UserLibrary.countOf(status) }
            .toMap() + (ReadingStatus.entries.size to UserLibrary.favorites.size)
    }

    LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
        item(key = "header") {
            Column(Modifier.padding(horizontal = 16.dp)) {
                Spacer(Modifier.height(14.dp))
                Text("Закладки", style = MaterialTheme.typography.headlineSmall, color = c.textMain)
                Spacer(Modifier.height(2.dp))
                Text(
                    "Твои списки чтения хранятся на устройстве и синхронизируются после входа",
                    style = MaterialTheme.typography.bodySmall,
                    color = c.textMuted
                )
                Spacer(Modifier.height(8.dp))
            }
        }
        item(key = "tabs") {
            MlTabRow(tabs = tabs, selected = tab, badges = badges) { tab = it }
        }
        if (library.isEmpty()) {
            item(key = "empty") {
                EmptyState("Список пуст", "Добавляй тайтлы кнопкой «Добавить в список»")
            }
        } else {
            items(count = library.size, key = { library[it].id }) { index ->
                val title = library[index]
                val read = UserLibrary.readCount(title.id)
                TitleRow(
                    title = title,
                    secondary = "${title.type.label} · прочитано $read из ${title.chaptersCount}",
                    trailing = title.updatedAt,
                    onClick = { onOpenTitle(title.id) }
                )
            }
        }
    }
}
