package ru.mangalicht.app

import android.app.Application
import ru.mangalicht.app.data.UserLibrary

class MangaLichtApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        UserLibrary.init(this)
    }
}
