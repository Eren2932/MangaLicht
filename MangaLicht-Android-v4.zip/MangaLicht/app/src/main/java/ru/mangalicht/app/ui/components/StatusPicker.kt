package ru.mangalicht.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import ru.mangalicht.app.data.ReadingStatus
import ru.mangalicht.app.ui.theme.ml

/** Цвет статуса — тот же код, что в легенде статистики профиля. */
@Composable
fun statusColor(status: ReadingStatus): Color {
    val c = ml
    return when (status) {
        ReadingStatus.READING -> c.positive
        ReadingStatus.PLANNED -> Color(0xFFA855F7)
        ReadingStatus.COMPLETED -> c.accent
        ReadingStatus.POSTPONED -> c.yellow
        ReadingStatus.DROPPED -> c.brand
    }
}

/**
 * Выбор пользовательского списка: Читаю, В планах, Прочитано, Отложено, Брошено.
 * Используется и на странице тайтла, и в окне со списком глав.
 */
@Composable
fun StatusPickerDialog(
    current: ReadingStatus?,
    titleName: String,
    onDismiss: () -> Unit,
    onSelect: (ReadingStatus?) -> Unit
) {
    val c = ml
    Dialog(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(c.blockInner)
                .border(1.dp, c.border, RoundedCornerShape(16.dp))
                .padding(18.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Добавить в список", style = MaterialTheme.typography.titleMedium, color = c.textMain)
                    Spacer(Modifier.height(2.dp))
                    Text(
                        titleName,
                        style = MaterialTheme.typography.bodySmall,
                        color = c.textMuted,
                        maxLines = 1
                    )
                }
                Icon(
                    Icons.Filled.Close,
                    contentDescription = "Закрыть",
                    tint = c.textMuted,
                    modifier = Modifier
                        .size(22.dp)
                        .clickable(onClick = onDismiss)
                )
            }
            Spacer(Modifier.height(14.dp))
            ReadingStatus.entries.forEach { status ->
                val selected = status == current
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (selected) c.chip else Color.Transparent)
                        .clickable { onSelect(status) }
                        .padding(horizontal = 12.dp, vertical = 12.dp)
                ) {
                    Box(
                        Modifier
                            .size(10.dp)
                            .clip(RoundedCornerShape(50))
                            .background(statusColor(status))
                    )
                    Spacer(Modifier.width(12.dp))
                    Text(
                        status.label,
                        style = MaterialTheme.typography.bodyLarge,
                        color = c.textMain,
                        modifier = Modifier.weight(1f)
                    )
                    if (selected) {
                        Icon(Icons.Filled.Check, null, tint = c.brand, modifier = Modifier.size(18.dp))
                    }
                }
                Spacer(Modifier.height(2.dp))
            }
            if (current != null) {
                Spacer(Modifier.height(8.dp))
                Text(
                    "Убрать из списков",
                    style = MaterialTheme.typography.labelLarge,
                    color = c.brand,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .clickable { onSelect(null) }
                        .padding(vertical = 12.dp, horizontal = 12.dp)
                )
            }
        }
    }
}

/** Компактная строка со статусами — быстрый выбор без диалога. */
@Composable
fun StatusChipRow(
    current: ReadingStatus?,
    onSelect: (ReadingStatus?) -> Unit
) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        ReadingStatus.entries.forEach { status ->
            MlChip(
                text = status.label,
                selected = status == current,
                onClick = { onSelect(if (status == current) null else status) }
            )
        }
    }
}
