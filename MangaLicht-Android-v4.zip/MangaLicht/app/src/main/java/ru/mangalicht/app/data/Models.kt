package ru.mangalicht.app.data

enum class TitleType(val label: String) {
    MANGA("Манга"),
    MANHWA("Манхва"),
    MANHUA("Маньхуа"),
    COMIC("Комикс"),
    WEBTOON("Вебтун"),
    RUMANGA("Руманга"),
    RANOBE("Ранобэ"),
    OTHER("Другое")
}

enum class TitleStatus(val label: String) {
    ONGOING("Продолжается"),
    COMPLETED("Завершён"),
    FROZEN("Заморожен"),
    ANNOUNCE("Анонс")
}

/** Пользовательский статус тайтла — как на сайте в блоке «В список». */
enum class ReadingStatus(val label: String) {
    READING("Читаю"),
    PLANNED("В планах"),
    COMPLETED("Прочитано"),
    POSTPONED("Отложено"),
    DROPPED("Брошено");

    companion object {
        fun fromKey(key: String?): ReadingStatus? = entries.firstOrNull { it.name == key }
    }
}

data class Chapter(
    val id: String,
    val volume: Int,
    val number: String,
    val title: String,
    val pages: Int,
    val uploadedAt: String,
    val myRating: Double? = null
) {
    val displayName: String get() = "Том $volume · Глава $number"
}

data class MangaTitle(
    val id: String,
    val title: String,
    val originalTitle: String,
    val year: Int,
    val type: TitleType,
    val status: TitleStatus,
    val author: String,
    val artist: String,
    val country: String,
    val genres: List<String>,
    val tags: List<String>,
    val description: String,
    val rating: Double,
    val votes: Int,
    val views: Int,
    val updatedAt: String,
    val chapters: List<Chapter>,
    val ratingBreakdown: Map<Int, Int>,
    val listCounts: Map<ReadingStatus, Int>,
    val isNew: Boolean = false,
    val isPopular: Boolean = false
) {
    val chaptersCount: Int get() = chapters.size
    val readersCount: Int get() = listCounts.values.sum()
    val subtitle: String get() = "${type.label} · $year · $country"
}

data class BlogPost(
    val id: String,
    val titleId: String,
    val author: String,
    val date: String,
    val headline: String,
    val body: String,
    val likes: Int,
    val dislikes: Int,
    val comments: Int,
    val views: Int,
    val pinned: Boolean = false
)

data class CommentItem(
    val id: String,
    val titleId: String,
    val author: String,
    val role: String? = null,
    val date: String,
    val body: String,
    val likes: Int,
    val replies: Int
)

data class ReviewItem(
    val id: String,
    val titleId: String,
    val author: String,
    val date: String,
    val rating: Int,
    val headline: String,
    val body: String,
    val likes: Int
)

data class ForumTopic(
    val id: String,
    val author: String,
    val role: String? = null,
    val date: String,
    val category: String,
    val title: String,
    val likes: Int,
    val comments: Int,
    val views: Int
)

data class HistoryEntry(
    val titleId: String,
    val chapterLabel: String,
    val whenText: String
)

data class RatingEntry(
    val titleId: String,
    val rating: Int,
    val whenText: String
)
