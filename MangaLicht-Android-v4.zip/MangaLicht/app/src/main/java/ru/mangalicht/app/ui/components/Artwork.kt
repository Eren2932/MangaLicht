package ru.mangalicht.app.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs

/**
 * Процедурная обложка: пока нет сетевых картинок, каждая обложка
 * детерминированно генерируется из названия — цвет, наклон панелей, инициал.
 * Когда появится API, здесь подключается загрузка по coverUrl.
 */
@Composable
fun ProceduralCover(
    seed: String,
    label: String,
    modifier: Modifier = Modifier,
    corner: Int = 12
) {
    val palette = remember(seed) { coverPalette(seed) }
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(corner.dp))
            .background(Brush.linearGradient(palette.gradient))
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            // диагональные «панели» как в раскадровке
            drawRect(
                color = palette.stroke.copy(alpha = 0.16f),
                topLeft = Offset(-w * 0.1f, h * 0.62f),
                size = Size(w * 1.4f, h * 0.06f)
            )
            drawRect(
                color = palette.stroke.copy(alpha = 0.10f),
                topLeft = Offset(-w * 0.1f, h * 0.78f),
                size = Size(w * 1.4f, h * 0.04f)
            )
            drawCircle(
                color = palette.stroke.copy(alpha = 0.14f),
                radius = w * 0.42f,
                center = Offset(w * 0.78f, h * 0.24f)
            )
            drawCircle(
                color = Color.Black.copy(alpha = 0.22f),
                radius = w * 0.9f,
                center = Offset(w * 0.1f, h * 1.05f)
            )
        }
        Text(
            text = initials(label),
            color = Color.White.copy(alpha = 0.92f),
            fontSize = 34.sp,
            fontWeight = FontWeight.Black,
            textAlign = TextAlign.Center,
            modifier = Modifier.align(Alignment.Center)
        )
        Row(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(8.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(
                text = label.take(28),
                style = MaterialTheme.typography.labelSmall,
                color = Color.White.copy(alpha = 0.78f),
                maxLines = 2
            )
        }
    }
}

private data class CoverPalette(val gradient: List<Color>, val stroke: Color)

private fun coverPalette(seed: String): CoverPalette {
    val h = abs(seed.hashCode())
    val sets = listOf(
        listOf(Color(0xFF3B1B2C), Color(0xFF8E1F3A)),
        listOf(Color(0xFF1B2440), Color(0xFF2E5C8A)),
        listOf(Color(0xFF1E2A22), Color(0xFF2F6B4F)),
        listOf(Color(0xFF2B1F3D), Color(0xFF6A3AA0)),
        listOf(Color(0xFF3A2A17), Color(0xFF9A6A22)),
        listOf(Color(0xFF17232B), Color(0xFF215C6B)),
        listOf(Color(0xFF2C1616), Color(0xFF7C2222)),
        listOf(Color(0xFF201C2B), Color(0xFF4A4470))
    )
    val strokes = listOf(
        Color(0xFFF7C870), Color(0xFF7FB2FF), Color(0xFF7ADC92),
        Color(0xFFD8A6FF), Color(0xFFFFD79A), Color(0xFF8FE3F2),
        Color(0xFFFF9B9B), Color(0xFFCFCBFF)
    )
    val i = h % sets.size
    return CoverPalette(sets[i], strokes[i])
}

private fun initials(label: String): String {
    val words = label.split(' ', '-', ':').filter { it.isNotBlank() }
    return when {
        words.isEmpty() -> "?"
        words.size == 1 -> words[0].take(2).uppercase()
        else -> (words[0].take(1) + words[1].take(1)).uppercase()
    }
}
