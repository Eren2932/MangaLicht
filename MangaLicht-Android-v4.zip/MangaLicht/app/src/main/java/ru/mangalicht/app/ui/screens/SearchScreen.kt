package ru.mangalicht.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import ru.mangalicht.app.data.MangaRepository
import ru.mangalicht.app.ui.components.EmptyState
import ru.mangalicht.app.ui.components.MlSearchField
import ru.mangalicht.app.ui.components.TitleRow
import ru.mangalicht.app.ui.theme.ml

@Composable
fun SearchScreen(onBack: () -> Unit, onOpenTitle: (String) -> Unit) {
    val c = ml
    var query by rememberSaveable { mutableStateOf("") }
    val results by remember { derivedStateOf { MangaRepository.search(query) } }

    LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
        item(key = "bar") {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    Icons.AutoMirrored.Filled.ArrowBack,
                    "Назад",
                    tint = c.textMain,
                    modifier = Modifier
                        .size(24.dp)
                        .clickable(onClick = onBack)
                )
                Spacer(Modifier.width(10.dp))
                MlSearchField(
                    value = query,
                    placeholder = "Поиск тайтлов...",
                    modifier = Modifier.weight(1f)
                ) { query = it }
            }
        }
        if (query.isBlank()) {
            item(key = "hint") { EmptyState("Введите название", "Ищем по названию, автору и жанрам") }
        } else if (results.isEmpty()) {
            item(key = "empty") { EmptyState("Ничего не найдено") }
        } else {
            items(count = results.size, key = { results[it].id }) { index ->
                val title = results[index]
                TitleRow(
                    title = title,
                    secondary = "${title.subtitle} · ${title.chaptersCount} глав",
                    onClick = { onOpenTitle(title.id) }
                )
            }
        }
    }
}
