package ru.mangalicht.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import ru.mangalicht.app.ui.theme.ml

@Composable
fun AuthScreen(onBack: () -> Unit) {
    val c = ml
    var register by rememberSaveable { mutableStateOf(false) }
    var email by rememberSaveable { mutableStateOf("") }
    var login by rememberSaveable { mutableStateOf("") }
    var password by rememberSaveable { mutableStateOf("") }
    var passwordVisible by rememberSaveable { mutableStateOf(false) }

    Box(
        Modifier
            .fillMaxSize()
            .background(c.bgMain),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .padding(20.dp)
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(c.blockInner)
                .border(1.dp, c.border, RoundedCornerShape(16.dp))
                .padding(20.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    if (register) "Регистрация" else "Вход",
                    style = MaterialTheme.typography.titleLarge,
                    color = c.textMain,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.weight(1f)
                )
                Icon(
                    Icons.Filled.Close,
                    "Закрыть",
                    tint = c.textMuted,
                    modifier = Modifier
                        .size(22.dp)
                        .clickable(onClick = onBack)
                )
            }
            Spacer(Modifier.height(18.dp))

            if (register) {
                FieldLabel("Логин")
                AuthField(value = login, placeholder = "Ник на сайте") { login = it }
                Spacer(Modifier.height(14.dp))
            }

            FieldLabel("Email")
            AuthField(value = email, placeholder = "you@mail.ru") { email = it }
            Spacer(Modifier.height(14.dp))

            FieldLabel("Пароль")
            AuthField(
                value = password,
                placeholder = "••••••••",
                visual = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                trailing = {
                    Icon(
                        if (passwordVisible) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                        contentDescription = "Показать пароль",
                        tint = c.textMuted,
                        modifier = Modifier
                            .size(18.dp)
                            .clickable { passwordVisible = !passwordVisible }
                    )
                }
            ) { password = it }
            Spacer(Modifier.height(6.dp))
            Text(
                "Минимум 8 символов: заглавная, строчная, цифра, спецсимвол",
                style = MaterialTheme.typography.labelSmall,
                color = c.textGhost
            )

            if (!register) {
                Spacer(Modifier.height(10.dp))
                Text(
                    "Забыли пароль?",
                    style = MaterialTheme.typography.labelSmall,
                    color = c.brand,
                    textAlign = TextAlign.End,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            Spacer(Modifier.height(18.dp))
            PrimaryButton(if (register) "Создать аккаунт" else "Войти") { onBack() }
            Spacer(Modifier.height(10.dp))
            SecondaryButton("Войти через Яндекс ID") { }

            Spacer(Modifier.height(16.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center
            ) {
                Text(
                    if (register) "Уже есть аккаунт? " else "Нет аккаунта? ",
                    style = MaterialTheme.typography.labelMedium,
                    color = c.textMuted
                )
                Text(
                    if (register) "Войти" else "Зарегистрироваться",
                    style = MaterialTheme.typography.labelMedium,
                    color = c.brand,
                    modifier = Modifier.clickable { register = !register }
                )
            }
        }
    }
}

@Composable
private fun FieldLabel(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.labelSmall,
        color = ml.textMuted,
        modifier = Modifier.padding(bottom = 6.dp)
    )
}

@Composable
private fun AuthField(
    value: String,
    placeholder: String,
    visual: VisualTransformation = VisualTransformation.None,
    trailing: (@Composable () -> Unit)? = null,
    onValueChange: (String) -> Unit
) {
    val c = ml
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(c.bgMain)
            .border(1.dp, c.border, RoundedCornerShape(10.dp))
            .padding(horizontal = 12.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.weight(1f)) {
            if (value.isEmpty()) {
                Text(placeholder, style = MaterialTheme.typography.bodyMedium, color = c.textGhost)
            }
            BasicTextField(
                value = value,
                onValueChange = onValueChange,
                singleLine = true,
                visualTransformation = visual,
                textStyle = LocalTextStyle.current.copy(color = c.textMain),
                cursorBrush = SolidColor(c.brand),
                modifier = Modifier.fillMaxWidth()
            )
        }
        if (trailing != null) trailing()
    }
}

@Composable
private fun PrimaryButton(text: String, onClick: () -> Unit) {
    val c = ml
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(c.brand)
            .clickable(onClick = onClick)
            .padding(vertical = 15.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, style = MaterialTheme.typography.labelLarge, color = Color.White)
    }
}

@Composable
private fun SecondaryButton(text: String, onClick: () -> Unit) {
    val c = ml
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(c.bgMain)
            .border(1.dp, c.border, RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 15.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, style = MaterialTheme.typography.labelLarge, color = c.textMain)
    }
}
