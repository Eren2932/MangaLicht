package ru.mangalicht.app.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import ru.mangalicht.app.data.DemoData
import ru.mangalicht.app.data.MangaRepository
import ru.mangalicht.app.data.ReadingStatus
import ru.mangalicht.app.data.UserLibrary
import ru.mangalicht.app.ui.components.MlChip
import ru.mangalicht.app.ui.components.ProceduralCover
import ru.mangalicht.app.ui.components.RatingStars
import ru.mangalicht.app.ui.components.SectionHeader
import ru.mangalicht.app.ui.components.StatBar
import ru.mangalicht.app.ui.components.TitleRow
import ru.mangalicht.app.ui.components.formatCount
import ru.mangalicht.app.ui.components.statusColor
import ru.mangalicht.app.ui.theme.ml

@Composable
fun ProfileScreen(
    onOpenTitle: (String) -> Unit,
    onOpenSettings: () -> Unit,
    onOpenAuth: () -> Unit
) {
    val c = ml
    val history = remember { MangaRepository.history() }
    val rated = remember { MangaRepository.ratedTitles() }
    val counts = remember(UserLibrary.statuses.size) {
        ReadingStatus.entries.associateWith { UserLibrary.countOf(it) }
    }
    val totalTitles = counts.values.sum()
    val readChapters = UserLibrary.totalReadChapters()

    LazyColumn(contentPadding = PaddingValues(bottom = 28.dp)) {
        item(key = "top") {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(50))
                        .background(c.blockInner)
                        .border(1.dp, c.border, RoundedCornerShape(50))
                        .padding(horizontal = 14.dp, vertical = 11.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Filled.Search, null, tint = c.textMuted, modifier = Modifier.size(17.dp))
                    Spacer(Modifier.width(10.dp))
                    Text(
                        "Поиск пользователей",
                        style = MaterialTheme.typography.bodyMedium,
                        color = c.textGhost
                    )
                }
                Spacer(Modifier.width(12.dp))
                Icon(
                    Icons.Filled.Settings,
                    "Настройки",
                    tint = c.textMain,
                    modifier = Modifier
                        .size(23.dp)
                        .clickable(onClick = onOpenSettings)
                )
                Spacer(Modifier.width(14.dp))
                Icon(Icons.Filled.Notifications, "Уведомления", tint = c.textMain, modifier = Modifier.size(23.dp))
            }
        }

        item(key = "identity") {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    Modifier
                        .size(96.dp)
                        .clip(RoundedCornerShape(50))
                        .background(c.chip),
                    contentAlignment = Alignment.Center
                ) {
                    Text("SD", style = MaterialTheme.typography.headlineMedium, color = c.textMain)
                }
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("SabirDzh", style = MaterialTheme.typography.headlineSmall, color = c.textMain)
                    Spacer(Modifier.width(8.dp))
                    Box(
                        Modifier
                            .clip(RoundedCornerShape(50))
                            .border(1.dp, c.positive, RoundedCornerShape(50))
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text("2", style = MaterialTheme.typography.labelSmall, color = c.positive)
                    }
                }
                Text("Статус не установлен", style = MaterialTheme.typography.bodySmall, color = c.textMuted)
                Spacer(Modifier.height(4.dp))
                Text("онлайн", style = MaterialTheme.typography.labelSmall, color = c.positive)
                Spacer(Modifier.height(16.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    ProfileCounter(readChapters.toString(), "глав")
                    ProfileCounter(totalTitles.toString(), "тайтлов")
                    ProfileCounter(UserLibrary.favorites.size.toString(), "избранных")
                    ProfileCounter("1", "друг")
                }
                Spacer(Modifier.height(14.dp))
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(50))
                            .border(1.dp, c.brand, RoundedCornerShape(50))
                            .clickable(onClick = onOpenAuth)
                            .padding(vertical = 13.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("Войти в аккаунт", style = MaterialTheme.typography.labelLarge, color = c.brand)
                    }
                }
                Spacer(Modifier.height(18.dp))
            }
        }

        item(key = "stats") {
            Column(Modifier.padding(horizontal = 16.dp)) {
                Block {
                    Text("Статистика", style = MaterialTheme.typography.titleMedium, color = c.textMain)
                    Spacer(Modifier.height(14.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            ReadingStatus.entries.forEach { status ->
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(vertical = 4.dp)
                                ) {
                                    Box(
                                        Modifier
                                            .size(10.dp)
                                            .clip(RoundedCornerShape(3.dp))
                                            .background(statusColor(status))
                                    )
                                    Spacer(Modifier.width(8.dp))
                                    Text(
                                        status.label,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = c.textMuted,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Text(
                                        (counts[status] ?: 0).toString(),
                                        style = MaterialTheme.typography.labelLarge,
                                        color = c.textMain
                                    )
                                }
                            }
                        }
                        Spacer(Modifier.width(14.dp))
                        StatusDonut(counts)
                    }
                    Spacer(Modifier.height(14.dp))
                    Text(
                        "Прочитано глав: ${formatCount(readChapters)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = c.textMuted
                    )
                    Text(
                        "Время чтения: ~ ${readChapters * 4 / 60} ч ${readChapters * 4 % 60} мин",
                        style = MaterialTheme.typography.bodySmall,
                        color = c.textMuted
                    )
                }
                Spacer(Modifier.height(16.dp))
            }
        }

        item(key = "activity") {
            Column(Modifier.padding(horizontal = 16.dp)) {
                Block {
                    Text(
                        "Динамика чтения глав",
                        style = MaterialTheme.typography.titleMedium,
                        color = c.textMain
                    )
                    Spacer(Modifier.height(16.dp))
                    ActivityChart()
                }
                Spacer(Modifier.height(8.dp))
            }
        }

        item(key = "ratings_header") { SectionHeader("Оценки тайтлов") }
        items(count = rated.size, key = { "rate_${rated[it].first.id}" }) { index ->
            val (title, entry) = rated[index]
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onOpenTitle(title.id) }
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                ProceduralCover(
                    seed = title.id,
                    label = title.title,
                    modifier = Modifier.width(44.dp).height(60.dp),
                    corner = 8
                )
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        title.title,
                        style = MaterialTheme.typography.titleSmall,
                        color = c.textMain,
                        maxLines = 1
                    )
                    Spacer(Modifier.height(4.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RatingStars(entry.rating.toDouble(), starSize = 13)
                        Spacer(Modifier.width(8.dp))
                        Text(entry.whenText, style = MaterialTheme.typography.labelSmall, color = c.textGhost)
                    }
                }
            }
        }

        item(key = "history_header") {
            Spacer(Modifier.height(10.dp))
            SectionHeader("Прочитано недавно")
        }
        items(count = history.size, key = { "hist_${history[it].second.titleId}" }) { index ->
            val (title, entry) = history[index]
            TitleRow(
                title = title,
                secondary = "${entry.chapterLabel} · ${entry.whenText}",
                onClick = { onOpenTitle(title.id) }
            )
        }
    }
}

@Composable
private fun ProfileCounter(value: String, label: String) {
    val c = ml
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, style = MaterialTheme.typography.titleLarge, color = c.textMain)
        Text(label, style = MaterialTheme.typography.labelSmall, color = c.textMuted)
    }
}

@Composable
private fun StatusDonut(counts: Map<ReadingStatus, Int>) {
    val c = ml
    val total = counts.values.sum().coerceAtLeast(1)
    val colors = ReadingStatus.entries.map { statusColor(it) }
    val progress by animateFloatAsState(1f, tween(600), label = "donut")
    Box(Modifier.size(112.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(112.dp)) {
            val stroke = 18f
            var start = -90f
            val rect = Size(size.width - stroke, size.height - stroke)
            val offset = Offset(stroke / 2, stroke / 2)
            drawArc(
                color = c.chip,
                startAngle = 0f,
                sweepAngle = 360f,
                useCenter = false,
                topLeft = offset,
                size = rect,
                style = Stroke(width = stroke)
            )
            ReadingStatus.entries.forEachIndexed { index, status ->
                val value = counts[status] ?: 0
                if (value > 0) {
                    val sweep = 360f * value / total * progress
                    drawArc(
                        color = colors[index],
                        startAngle = start,
                        sweepAngle = sweep,
                        useCenter = false,
                        topLeft = offset,
                        size = rect,
                        style = Stroke(width = stroke)
                    )
                    start += sweep
                }
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                counts.values.sum().toString(),
                style = MaterialTheme.typography.titleLarge,
                color = c.textMain,
                fontWeight = FontWeight.Bold
            )
            Text("в списках", style = MaterialTheme.typography.labelSmall, color = c.textMuted)
        }
    }
}

@Composable
private fun ActivityChart() {
    val c = ml
    val data = DemoData.readingActivity
    val max = (data.maxOfOrNull { it.second } ?: 1).coerceAtLeast(1)
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.Bottom
    ) {
        data.forEach { (day, value) ->
            val fraction by animateFloatAsState(
                value.toFloat() / max,
                tween(600),
                label = "bar_$day"
            )
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    value.toString(),
                    style = MaterialTheme.typography.labelSmall,
                    color = if (value > 0) c.textMain else c.textGhost
                )
                Spacer(Modifier.height(4.dp))
                Box(
                    Modifier
                        .width(14.dp)
                        .height((6 + 64 * fraction).dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (value > 0) c.brand else c.brand.copy(alpha = 0.30f))
                )
                Spacer(Modifier.height(6.dp))
                Text(day, style = MaterialTheme.typography.labelSmall, color = c.textGhost)
            }
        }
    }
}
