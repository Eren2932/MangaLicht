package ru.mangalicht.app.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp

/** Кольцевая диаграмма статистики чтения. */
@Composable
fun DonutChart(
    values: List<Pair<Color, Int>>,
    modifier: Modifier = Modifier,
    strokeWidth: Float = 46f
) {
    val total = values.sumOf { it.second }.coerceAtLeast(1)
    val progress by animateFloatAsState(
        targetValue = 1f,
        animationSpec = tween(durationMillis = 620),
        label = "donutProgress"
    )
    Canvas(modifier) {
        var startAngle = -90f
        values.forEach { (color, value) ->
            val sweep = 360f * value / total * progress
            drawArc(
                color = color,
                startAngle = startAngle,
                sweepAngle = sweep,
                useCenter = false,
                topLeft = Offset(strokeWidth / 2f, strokeWidth / 2f),
                size = Size(size.width - strokeWidth, size.height - strokeWidth),
                style = Stroke(width = strokeWidth)
            )
            startAngle += sweep
        }
    }
}

@Composable
fun LegendRow(color: Color, label: String, value: Int) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(vertical = 5.dp)
    ) {
        Box(Modifier.size(11.dp).clip(RoundedCornerShape(3.dp)).background(color))
        Spacer(Modifier.width(9.dp))
        Text(
            label,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.width(6.dp))
        Text(value.toString(), style = MaterialTheme.typography.labelLarge)
    }
}

/** Столбчатая диаграмма активности чтения по дням. */
@Composable
fun ActivityChart(data: List<Pair<String, Int>>, modifier: Modifier = Modifier) {
    val max = (data.maxOfOrNull { it.second } ?: 0).coerceAtLeast(1)
    Row(
        modifier = modifier.height(180.dp),
        verticalAlignment = Alignment.Bottom,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        data.forEach { (day, value) ->
            val fraction by animateFloatAsState(
                targetValue = value.toFloat() / max,
                animationSpec = tween(durationMillis = 520),
                label = "barFraction"
            )
            Column(
                modifier = Modifier.weight(1f),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Bottom
            ) {
                Text(
                    value.toString(),
                    style = MaterialTheme.typography.labelSmall,
                    color = if (value == 0) MaterialTheme.colorScheme.onSurfaceVariant
                    else MaterialTheme.colorScheme.onSurface
                )
                Spacer(Modifier.height(6.dp))
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height((8f + 100f * fraction).dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(
                            if (value == 0) MaterialTheme.colorScheme.secondary.copy(alpha = 0.35f)
                            else MaterialTheme.colorScheme.secondary
                        )
                )
                Spacer(Modifier.height(10.dp))
                Text(
                    day,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.rotate(-42f)
                )
            }
        }
    }
}
