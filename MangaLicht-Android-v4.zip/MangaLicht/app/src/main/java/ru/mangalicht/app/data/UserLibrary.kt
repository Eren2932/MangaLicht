package ru.mangalicht.app.data

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.snapshots.SnapshotStateMap

/**
 * Локальное хранилище пользователя: статусы списков, избранное,
 * прочитанные главы, прогресс чтения, настройки читалки.
 *
 * Всё держится в snapshot-состоянии, поэтому UI обновляется мгновенно,
 * а на диск пишется через SharedPreferences.
 * При подключении настоящего API этот класс становится локальным кэшем.
 */
object UserLibrary {

    private const val PREFS = "mangalicht_user"
    private const val KEY_STATUS = "status_"
    private const val KEY_FAVORITE = "favorites"
    private const val KEY_READ = "read_chapters"
    private const val KEY_PROGRESS = "progress_"
    private const val KEY_RATING = "rating_"
    private const val KEY_DARK = "dark_theme"
    private const val KEY_READER_MODE = "reader_mode"
    private const val KEY_READER_KEEP_UI = "reader_keep_ui"

    private var prefs: SharedPreferences? = null

    val statuses: SnapshotStateMap<String, ReadingStatus> = mutableStateMapOf()
    val favorites: SnapshotStateMap<String, Boolean> = mutableStateMapOf()
    val readChapters: SnapshotStateMap<String, Boolean> = mutableStateMapOf()
    val progress: SnapshotStateMap<String, String> = mutableStateMapOf()
    val ratings: SnapshotStateMap<String, Int> = mutableStateMapOf()

    val darkTheme = mutableStateOf(true)
    /** 0 — вертикальная лента, 1 — постранично. */
    val readerMode = mutableStateOf(0)
    val readerKeepUi = mutableStateOf(false)

    fun init(context: Context) {
        if (prefs != null) return
        val p = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        prefs = p

        darkTheme.value = p.getBoolean(KEY_DARK, true)
        readerMode.value = p.getInt(KEY_READER_MODE, 0)
        readerKeepUi.value = p.getBoolean(KEY_READER_KEEP_UI, false)

        p.getStringSet(KEY_FAVORITE, emptySet())?.forEach { favorites[it] = true }
        p.getStringSet(KEY_READ, emptySet())?.forEach { readChapters[it] = true }

        p.all.forEach { (key, value) ->
            when {
                key.startsWith(KEY_STATUS) && value is String ->
                    ReadingStatus.fromKey(value)?.let { statuses[key.removePrefix(KEY_STATUS)] = it }
                key.startsWith(KEY_PROGRESS) && value is String ->
                    progress[key.removePrefix(KEY_PROGRESS)] = value
                key.startsWith(KEY_RATING) && value is Int ->
                    ratings[key.removePrefix(KEY_RATING)] = value
            }
        }

        // Демонстрационное наполнение при первом запуске, чтобы экраны не были пустыми.
        if (statuses.isEmpty() && favorites.isEmpty()) {
            setStatus("t1", ReadingStatus.READING)
            setStatus("t11", ReadingStatus.READING)
            setStatus("t2", ReadingStatus.PLANNED)
            setStatus("t4", ReadingStatus.PLANNED)
            setStatus("t6", ReadingStatus.COMPLETED)
            setStatus("t14", ReadingStatus.COMPLETED)
            setStatus("t15", ReadingStatus.POSTPONED)
            setStatus("t9", ReadingStatus.DROPPED)
            toggleFavorite("t1")
            toggleFavorite("t11")
            setProgress("t1", "ch_54")
            setProgress("t11", "ch_41")
            DemoData.myRatings.forEach { setRating(it.titleId, it.rating) }
            markRead("t1", "ch_54", true)
            markRead("t1", "ch_53", true)
            markRead("t1", "ch_52", true)
        }
    }

    // --- статусы ---

    fun statusOf(titleId: String): ReadingStatus? = statuses[titleId]

    fun setStatus(titleId: String, status: ReadingStatus?) {
        val editor = prefs?.edit()
        if (status == null) {
            statuses.remove(titleId)
            editor?.remove(KEY_STATUS + titleId)
        } else {
            statuses[titleId] = status
            editor?.putString(KEY_STATUS + titleId, status.name)
        }
        editor?.apply()
    }

    fun titlesWithStatus(status: ReadingStatus): List<String> =
        statuses.filterValues { it == status }.keys.toList()

    fun countOf(status: ReadingStatus): Int = statuses.count { it.value == status }

    // --- избранное ---

    fun isFavorite(titleId: String): Boolean = favorites[titleId] == true

    fun toggleFavorite(titleId: String) {
        if (favorites[titleId] == true) favorites.remove(titleId) else favorites[titleId] = true
        prefs?.edit()?.putStringSet(KEY_FAVORITE, favorites.keys.toSet())?.apply()
    }

    // --- прочитанные главы ---

    private fun chapterKey(titleId: String, chapterId: String) = "$titleId:$chapterId"

    fun isChapterRead(titleId: String, chapterId: String): Boolean =
        readChapters[chapterKey(titleId, chapterId)] == true

    fun markRead(titleId: String, chapterId: String, read: Boolean) {
        val key = chapterKey(titleId, chapterId)
        if (read) readChapters[key] = true else readChapters.remove(key)
        prefs?.edit()?.putStringSet(KEY_READ, readChapters.keys.toSet())?.apply()
    }

    fun readCount(titleId: String): Int = readChapters.keys.count { it.startsWith("$titleId:") }

    fun totalReadChapters(): Int = readChapters.size

    // --- прогресс ---

    fun progressOf(titleId: String): String? = progress[titleId]

    fun setProgress(titleId: String, chapterId: String) {
        progress[titleId] = chapterId
        prefs?.edit()?.putString(KEY_PROGRESS + titleId, chapterId)?.apply()
    }

    // --- оценки ---

    fun ratingOf(titleId: String): Int? = ratings[titleId]

    fun setRating(titleId: String, value: Int) {
        ratings[titleId] = value
        prefs?.edit()?.putInt(KEY_RATING + titleId, value)?.apply()
    }

    // --- настройки ---

    fun setDarkTheme(value: Boolean) {
        darkTheme.value = value
        prefs?.edit()?.putBoolean(KEY_DARK, value)?.apply()
    }

    fun setReaderMode(value: Int) {
        readerMode.value = value
        prefs?.edit()?.putInt(KEY_READER_MODE, value)?.apply()
    }

    fun setReaderKeepUi(value: Boolean) {
        readerKeepUi.value = value
        prefs?.edit()?.putBoolean(KEY_READER_KEEP_UI, value)?.apply()
    }
}
