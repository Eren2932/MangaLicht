package ru.mangalicht.app.ui

import androidx.compose.animation.AnimatedContentTransitionScope
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Forum
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.navigation.NavDestination
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import ru.mangalicht.app.ui.screens.AuthScreen
import ru.mangalicht.app.ui.screens.BookmarksScreen
import ru.mangalicht.app.ui.screens.CatalogScreen
import ru.mangalicht.app.ui.screens.DetailsScreen
import ru.mangalicht.app.ui.screens.ForumScreen
import ru.mangalicht.app.ui.screens.HomeScreen
import ru.mangalicht.app.ui.screens.ProfileScreen
import ru.mangalicht.app.ui.screens.ReaderScreen
import ru.mangalicht.app.ui.screens.SearchScreen
import ru.mangalicht.app.ui.screens.SettingsScreen
import ru.mangalicht.app.ui.theme.ml

object Routes {
    const val HOME = "home"
    const val CATALOG = "catalog"
    const val FORUM = "forum"
    const val BOOKMARKS = "bookmarks"
    const val PROFILE = "profile"
    const val SEARCH = "search"
    const val SETTINGS = "settings"
    const val AUTH = "auth"
    const val DETAILS = "details/{titleId}"
    const val READER = "reader/{titleId}/{chapterId}"

    fun details(titleId: String) = "details/$titleId"
    fun reader(titleId: String, chapterId: String) = "reader/$titleId/$chapterId"
}

private data class TabItem(val route: String, val label: String, val icon: ImageVector)

private val tabs = listOf(
    TabItem(Routes.HOME, "Главная", Icons.Filled.Home),
    TabItem(Routes.CATALOG, "Каталог", Icons.Filled.Explore),
    TabItem(Routes.FORUM, "Форум", Icons.Filled.Forum),
    TabItem(Routes.BOOKMARKS, "Закладки", Icons.Filled.Bookmark),
    TabItem(Routes.PROFILE, "Профиль", Icons.Filled.Person)
)

/** Экраны без нижней панели: читалка, тайтл, авторизация, поиск, настройки. */
private val fullScreenRoutes = setOf(
    Routes.DETAILS, Routes.READER, Routes.AUTH, Routes.SEARCH, Routes.SETTINGS
)

@Composable
fun MangaLichtApp() {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = backStackEntry?.destination
    val showBottomBar = currentDestination?.route?.let { it !in fullScreenRoutes } ?: true
    val c = ml

    Scaffold(
        containerColor = c.bgMain,
        bottomBar = {
            if (showBottomBar) {
                MlBottomBar(navController, currentDestination)
            }
        }
    ) { innerPadding ->
        Box(
            Modifier
                .fillMaxSize()
                .background(c.bgMain)
                .padding(bottom = if (showBottomBar) innerPadding.calculateBottomPadding() else 0.dp)
        ) {
            AppNavHost(navController)
        }
    }
}

@Composable
private fun MlBottomBar(navController: NavHostController, current: NavDestination?) {
    val c = ml
    NavigationBar(
        containerColor = c.block,
        contentColor = c.textMuted,
        tonalElevation = 0.dp
    ) {
        tabs.forEach { tab ->
            val selected = current?.hierarchy()?.any { it.route == tab.route } == true
            NavigationBarItem(
                selected = selected,
                onClick = {
                    if (!selected) {
                        navController.navigate(tab.route) {
                            popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                            launchSingleTop = true
                            restoreState = true
                        }
                    }
                },
                icon = { Icon(tab.icon, contentDescription = tab.label) },
                label = { Text(tab.label) },
                alwaysShowLabel = true,
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = c.brand,
                    selectedTextColor = c.brand,
                    indicatorColor = c.brand.copy(alpha = 0.14f),
                    unselectedIconColor = c.textMuted,
                    unselectedTextColor = c.textMuted
                )
            )
        }
    }
}

/** Сравнение по иерархии графа, а не по строке маршрута. */
private fun NavDestination.hierarchy(): Sequence<NavDestination> =
    generateSequence(this) { it.parent }

private const val FAST = 130
private const val PUSH = 180

@Composable
private fun AppNavHost(navController: NavHostController) {
    NavHost(
        navController = navController,
        startDestination = Routes.HOME,
        enterTransition = { fadeIn(tween(FAST)) },
        exitTransition = { fadeOut(tween(FAST)) },
        popEnterTransition = { fadeIn(tween(FAST)) },
        popExitTransition = { fadeOut(tween(FAST)) }
    ) {
        composable(Routes.HOME) {
            HomeScreen(
                onOpenTitle = { navController.navigate(Routes.details(it)) },
                onOpenCatalog = { navController.navigate(Routes.CATALOG) },
                onOpenSearch = { navController.navigate(Routes.SEARCH) },
                onOpenReader = { titleId, chapterId ->
                    navController.navigate(Routes.reader(titleId, chapterId))
                }
            )
        }
        composable(Routes.CATALOG) {
            CatalogScreen(
                onOpenTitle = { navController.navigate(Routes.details(it)) }
            )
        }
        composable(Routes.FORUM) { ForumScreen() }
        composable(Routes.BOOKMARKS) {
            BookmarksScreen(
                onOpenTitle = { navController.navigate(Routes.details(it)) },
                onOpenCatalog = { navController.navigate(Routes.CATALOG) }
            )
        }
        composable(Routes.PROFILE) {
            ProfileScreen(
                onOpenTitle = { navController.navigate(Routes.details(it)) },
                onOpenSettings = { navController.navigate(Routes.SETTINGS) },
                onOpenAuth = { navController.navigate(Routes.AUTH) }
            )
        }
        composable(Routes.SEARCH) {
            SearchScreen(
                onBack = { navController.popBackStack() },
                onOpenTitle = { navController.navigate(Routes.details(it)) }
            )
        }
        composable(Routes.SETTINGS) {
            SettingsScreen(onBack = { navController.popBackStack() })
        }
        composable(Routes.AUTH) {
            AuthScreen(onBack = { navController.popBackStack() })
        }
        composable(
            route = Routes.DETAILS,
            enterTransition = {
                slideIntoContainer(
                    AnimatedContentTransitionScope.SlideDirection.Left,
                    tween(PUSH)
                ) + fadeIn(tween(PUSH))
            },
            exitTransition = { fadeOut(tween(FAST)) },
            popExitTransition = {
                slideOutOfContainer(
                    AnimatedContentTransitionScope.SlideDirection.Right,
                    tween(PUSH)
                ) + fadeOut(tween(PUSH))
            }
        ) { entry ->
            val titleId = entry.arguments?.getString("titleId").orEmpty()
            DetailsScreen(
                titleId = titleId,
                onBack = { navController.popBackStack() },
                onOpenTitle = { navController.navigate(Routes.details(it)) },
                onRead = { chapterId -> navController.navigate(Routes.reader(titleId, chapterId)) }
            )
        }
        composable(
            route = Routes.READER,
            enterTransition = { scaleIn(tween(PUSH), initialScale = 0.97f) + fadeIn(tween(PUSH)) },
            popExitTransition = { scaleOut(tween(PUSH), targetScale = 0.97f) + fadeOut(tween(FAST)) }
        ) { entry ->
            ReaderScreen(
                titleId = entry.arguments?.getString("titleId").orEmpty(),
                chapterId = entry.arguments?.getString("chapterId").orEmpty(),
                onBack = { navController.popBackStack() },
                onOpenChapter = { titleId, chapterId ->
                    navController.navigate(Routes.reader(titleId, chapterId)) {
                        popUpTo(Routes.READER) { inclusive = true }
                    }
                }
            )
        }
    }
}
