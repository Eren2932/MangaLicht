package ru.mangalicht.app.data

/**
 * Демонстрационные данные. Полностью заменяются сетевым слоем:
 * структуры повторяют то, что отдаёт сайт MangaLicht.
 */
object DemoData {

    val genres = listOf(
        "Сёнэн", "Сёдзё", "Сэйнэн", "Дзёсэй", "Боевик", "Приключения", "Фэнтези",
        "Фантастика", "Научная фантастика", "Киберпанк", "Постапокалипсис", "Романтика",
        "Драма", "Комедия", "Мистика", "Хоррор", "Детектив", "Психология", "Триллер",
        "Спорт", "Школа", "Исекай", "Магия", "Меха", "Гарем", "Повседневность",
        "Трагедия", "Сверхъестественное", "Историческое"
    )

    val sorts = listOf("Новые", "Больше просмотров", "Меньше просмотров", "Высокий рейтинг", "Низкий рейтинг", "По названию")

    val forumCategories = listOf(
        "Все категории", "Баги и проблемы", "Предложения для сайта", "Поиск тайтлов",
        "Поиск кадров", "Обсуждение Манги", "Обсуждение Аниме", "Обсуждение Ранобэ",
        "Видеоигры", "Переводчикам", "Как переводить мангу", "Как рисовать мангу",
        "Общение", "Другое"
    )

    private fun chapters(count: Int, perVolume: Int = 12, basePages: Int = 18): List<Chapter> =
        (count downTo 1).map { n ->
            val volume = ((n - 1) / perVolume) + 1
            Chapter(
                id = "ch_$n",
                volume = volume,
                number = n.toString(),
                title = when (n % 5) {
                    0 -> "Тень на пороге"
                    1 -> "Первый шаг"
                    2 -> "Голос из разлома"
                    3 -> "Долг крови"
                    else -> "Ночная смена"
                },
                pages = basePages + (n * 7) % 19,
                uploadedAt = when {
                    n == count -> "сегодня"
                    n == count - 1 -> "2 дн назад"
                    n == count - 2 -> "3 дн назад"
                    n > count - 8 -> "${count - n + 1} дн назад"
                    else -> "${(count - n) / 4 + 1} нед назад"
                },
                myRating = if (n % 4 == 0) 4.5 else null
            )
        }

    private fun breakdown(five: Int, four: Int, three: Int, two: Int, one: Int) =
        mapOf(5 to five, 4 to four, 3 to three, 2 to two, 1 to one)

    private fun counts(reading: Int, planned: Int, done: Int, postponed: Int, dropped: Int) = mapOf(
        ReadingStatus.READING to reading,
        ReadingStatus.PLANNED to planned,
        ReadingStatus.COMPLETED to done,
        ReadingStatus.POSTPONED to postponed,
        ReadingStatus.DROPPED to dropped
    )

    val titles: List<MangaTitle> = listOf(
        MangaTitle(
            id = "t1",
            title = "Ночная смена в мире разломов",
            originalTitle = "Night Shift",
            year = 2026,
            type = TitleType.WEBTOON,
            status = TitleStatus.ONGOING,
            author = "Varfolomeev",
            artist = "Varfolomeev",
            country = "Россия",
            genres = listOf("Хоррор", "Мистика", "Боевик"),
            tags = listOf("Разломы", "Выживание", "Сильный герой"),
            description = "Обычная работа охранника превращается в выживание, когда на закрытый объект приходят сущности из разломов. Каждая смена — новая попытка дожить до утра, а каждый выход в коридор становится решением, от которого зависит вся команда.",
            rating = 4.8, votes = 1569, views = 184_320, updatedAt = "сегодня",
            chapters = chapters(54, basePages = 18),
            ratingBreakdown = breakdown(1000, 500, 67, 2, 0),
            listCounts = counts(1000, 250, 250, 62, 6),
            isNew = true, isPopular = true
        ),
        MangaTitle(
            id = "t2",
            title = "Тень последнего клинка",
            originalTitle = "Shadow of the Last Blade",
            year = 2026,
            type = TitleType.MANGA,
            status = TitleStatus.ONGOING,
            author = "ADmoral",
            artist = "KaMa",
            country = "Россия",
            genres = listOf("Боевик", "Фэнтези", "Драма"),
            tags = listOf("Месть", "Школа меча", "Политика"),
            description = "Наследник забытой школы меча возвращается в город, где его семью объявили предателями. Он готов пройти через всех, кто подписал тот приговор, но чем ближе правда, тем сильнее сомнение: а был ли враг вообще снаружи.",
            rating = 4.6, votes = 902, views = 121_440, updatedAt = "2 дн назад",
            chapters = chapters(37),
            ratingBreakdown = breakdown(600, 250, 40, 8, 4),
            listCounts = counts(640, 190, 120, 30, 12),
            isNew = true, isPopular = true
        ),
        MangaTitle(
            id = "t3",
            title = "Поколение Нова",
            originalTitle = "Generation of Nova",
            year = 2024,
            type = TitleType.MANGA,
            status = TitleStatus.ONGOING,
            author = "Raven",
            artist = "Raven",
            country = "Россия",
            genres = listOf("Фантастика", "Приключения", "Меха"),
            tags = listOf("Космос", "Академия", "Пилоты"),
            description = "Первый набор пилотов новой станции узнаёт, что программа обучения — лишь фильтр для отбора тех, кто выдержит контакт с ядром «Нова».",
            rating = 4.3, votes = 411, views = 68_900, updatedAt = "5 дн назад",
            chapters = chapters(28),
            ratingBreakdown = breakdown(210, 140, 45, 10, 6),
            listCounts = counts(300, 120, 90, 24, 9),
            isPopular = true
        ),
        MangaTitle(
            id = "t4",
            title = "Ярче звёзд",
            originalTitle = "Brighter Than Stars",
            year = 2026,
            type = TitleType.MANHWA,
            status = TitleStatus.ONGOING,
            author = "KaMa",
            artist = "KaMa",
            country = "Россия",
            genres = listOf("Романтика", "Драма", "Повседневность"),
            tags = listOf("Идолы", "Первая любовь"),
            description = "Две девушки из конкурирующих групп подписывают контракт, который запрещает им общаться. Они всё равно находят способ.",
            rating = 4.5, votes = 688, views = 74_100, updatedAt = "неделю назад",
            chapters = chapters(22),
            ratingBreakdown = breakdown(400, 200, 60, 20, 8),
            listCounts = counts(420, 160, 130, 28, 11),
            isNew = true, isPopular = true
        ),
        MangaTitle(
            id = "t5",
            title = "Дневник космического пирата",
            originalTitle = "Space Pirate Diary",
            year = 2025,
            type = TitleType.MANGA,
            status = TitleStatus.ONGOING,
            author = "InRed",
            artist = "InRed",
            country = "Россия",
            genres = listOf("Приключения", "Фантастика", "Комедия"),
            tags = listOf("Пираты", "Экипаж", "Юмор"),
            description = "Капитан ведёт судовой журнал, в котором честно пишет, сколько раз команда чуть не погибла из-за его же идей.",
            rating = 4.2, votes = 355, views = 52_300, updatedAt = "3 дн назад",
            chapters = chapters(19),
            ratingBreakdown = breakdown(180, 120, 40, 10, 5),
            listCounts = counts(260, 90, 70, 18, 7),
            isPopular = true
        ),
        MangaTitle(
            id = "t6",
            title = "Каменное сердце",
            originalTitle = "Stone Heart",
            year = 2023,
            type = TitleType.MANGA,
            status = TitleStatus.COMPLETED,
            author = "KrоMa",
            artist = "KrоMa",
            country = "Россия",
            genres = listOf("Мистика", "Драма", "Сверхъестественное"),
            tags = listOf("Проклятие", "Семья"),
            description = "Проклятие рода делает каждого наследника холоднее предыдущего. Младшая дочь решает оборвать линию на себе.",
            rating = 5.0, votes = 240, views = 41_700, updatedAt = "2 мес назад",
            chapters = chapters(48),
            ratingBreakdown = breakdown(230, 8, 2, 0, 0),
            listCounts = counts(120, 200, 310, 20, 4)
        ),
        MangaTitle(
            id = "t7",
            title = "Следы вероломства",
            originalTitle = "Traces of Betrayal",
            year = 2024,
            type = TitleType.COMIC,
            status = TitleStatus.ONGOING,
            author = "Jago",
            artist = "Jago",
            country = "Россия",
            genres = listOf("Детектив", "Триллер", "Психология"),
            tags = listOf("Расследование", "Город"),
            description = "Следователь ищет того, кто оставляет на месте преступления страницы из старых комиксов.",
            rating = 4.2, votes = 298, views = 38_150, updatedAt = "неделю назад",
            chapters = chapters(31),
            ratingBreakdown = breakdown(160, 100, 28, 6, 4),
            listCounts = counts(210, 88, 64, 15, 6),
            isPopular = true
        ),
        MangaTitle(
            id = "t8",
            title = "Как нас зовут?",
            originalTitle = "What Is Our Name?",
            year = 2026,
            type = TitleType.MANGA,
            status = TitleStatus.ONGOING,
            author = "tenKa",
            artist = "tenKa",
            country = "Россия",
            genres = listOf("Мистика", "Школа", "Психология"),
            tags = listOf("Память", "Класс"),
            description = "Класс просыпается утром и понимает, что никто не помнит собственного имени, а в журнале стоят чужие фамилии.",
            rating = 4.1, votes = 176, views = 29_400, updatedAt = "4 дн назад",
            chapters = chapters(14),
            ratingBreakdown = breakdown(90, 55, 20, 8, 3),
            listCounts = counts(150, 70, 40, 12, 5),
            isNew = true
        ),
        MangaTitle(
            id = "t9",
            title = "Измени этот мир",
            originalTitle = "Change Da World",
            year = 2026,
            type = TitleType.MANHUA,
            status = TitleStatus.FROZEN,
            author = "CrusaderC",
            artist = "CrusaderC",
            country = "Россия",
            genres = listOf("Исекай", "Фэнтези", "Комедия"),
            tags = listOf("Попаданец", "Система"),
            description = "Герой получает интерфейс изменения реальности с одним ограничением: каждая правка мира стирает один его день.",
            rating = 2.3, votes = 64, views = 18_700, updatedAt = "мес назад",
            chapters = chapters(9),
            ratingBreakdown = breakdown(10, 12, 18, 14, 10),
            listCounts = counts(60, 40, 18, 22, 26)
        ),
        MangaTitle(
            id = "t10",
            title = "На грани",
            originalTitle = "On the Edge",
            year = 2026,
            type = TitleType.COMIC,
            status = TitleStatus.ONGOING,
            author = "KaMa",
            artist = "KaMa",
            country = "Россия",
            genres = listOf("Романтика", "Драма"),
            tags = listOf("Взросление", "Город"),
            description = "Две подруги переезжают в общую квартиру и впервые честно говорят о том, чего боятся.",
            rating = 4.7, votes = 512, views = 61_050, updatedAt = "2 дн назад",
            chapters = chapters(25),
            ratingBreakdown = breakdown(340, 130, 30, 8, 4),
            listCounts = counts(330, 140, 96, 22, 8),
            isNew = true
        ),
        MangaTitle(
            id = "t11",
            title = "Кай Болл",
            originalTitle = "Kai Ball",
            year = 2026,
            type = TitleType.MANGA,
            status = TitleStatus.ONGOING,
            author = "ADmoral",
            artist = "ADmoral",
            country = "Россия",
            genres = listOf("Спорт", "Сёнэн", "Комедия"),
            tags = listOf("Турнир", "Команда"),
            description = "Уличная команда без тренера выходит на официальный турнир и ломает представление о правилах игры.",
            rating = 4.8, votes = 604, views = 70_800, updatedAt = "сегодня",
            chapters = chapters(41),
            ratingBreakdown = breakdown(430, 130, 30, 8, 6),
            listCounts = counts(380, 150, 110, 26, 10),
            isNew = true, isPopular = true
        ),
        MangaTitle(
            id = "t12",
            title = "Хельга, хозяйка кров",
            originalTitle = "Helga",
            year = 2026,
            type = TitleType.RUMANGA,
            status = TitleStatus.ANNOUNCE,
            author = "Olga Rover",
            artist = "Olga Rover",
            country = "Россия",
            genres = listOf("Фэнтези", "Историческое", "Драма"),
            tags = listOf("Север", "Кровь"),
            description = "Наследница северного дома принимает право крови, которое до неё не выдержал ни один мужчина рода.",
            rating = 0.0, votes = 0, views = 4_120, updatedAt = "анонс",
            chapters = emptyList(),
            ratingBreakdown = breakdown(0, 0, 0, 0, 0),
            listCounts = counts(0, 210, 0, 0, 0),
            isNew = true
        ),
        MangaTitle(
            id = "t13",
            title = "Insomnia Twilight",
            originalTitle = "Insomnia Twilight",
            year = 2026,
            type = TitleType.OTHER,
            status = TitleStatus.ONGOING,
            author = "Skyler",
            artist = "Skyler",
            country = "Россия",
            genres = listOf("Мистика", "Психология", "Сверхъестественное"),
            tags = listOf("Сны", "Бессонница"),
            description = "Тот, кто не спит семь суток, начинает видеть чужие сны наяву — и отвечать за то, что в них происходит.",
            rating = 5.0, votes = 138, views = 22_900, updatedAt = "6 дн назад",
            chapters = chapters(17),
            ratingBreakdown = breakdown(130, 6, 2, 0, 0),
            listCounts = counts(140, 80, 55, 10, 3)
        ),
        MangaTitle(
            id = "t14",
            title = "Дьявольский любовник",
            originalTitle = "Devil's Lover",
            year = 2019,
            type = TitleType.COMIC,
            status = TitleStatus.COMPLETED,
            author = "KrоMa",
            artist = "KrоMa",
            country = "Россия",
            genres = listOf("Романтика", "Мистика", "Драма"),
            tags = listOf("Демон", "Контракт"),
            description = "Контракт с демоном заключается на год. Проблема в том, что год у демонов считается иначе.",
            rating = 5.0, votes = 402, views = 58_600, updatedAt = "год назад",
            chapters = chapters(60),
            ratingBreakdown = breakdown(380, 18, 3, 1, 0),
            listCounts = counts(90, 180, 420, 16, 5)
        ),
        MangaTitle(
            id = "t15",
            title = "ШигоНичиджо",
            originalTitle = "Shigo Nichijou",
            year = 2026,
            type = TitleType.MANGA,
            status = TitleStatus.ONGOING,
            author = "Moon-Chiiie",
            artist = "Moon-Chiiie",
            country = "Россия",
            genres = listOf("Повседневность", "Комедия", "Сэйнэн"),
            tags = listOf("Работа", "Быт"),
            description = "Рабочие будни в мире, где сверхъестественное давно стало частью офисного регламента.",
            rating = 3.5, votes = 121, views = 26_400, updatedAt = "неделю назад",
            chapters = chapters(21),
            ratingBreakdown = breakdown(50, 40, 20, 8, 3),
            listCounts = counts(160, 70, 50, 14, 6),
            isPopular = true
        ),
        MangaTitle(
            id = "t16",
            title = "Снова мертв",
            originalTitle = "Dead Again",
            year = 2025,
            type = TitleType.MANGA,
            status = TitleStatus.ONGOING,
            author = "Jago",
            artist = "Jago",
            country = "Россия",
            genres = listOf("Хоррор", "Триллер", "Постапокалипсис"),
            tags = listOf("Петля", "Город мёртвых"),
            description = "Каждая смерть возвращает его на тот же перрон, но город вокруг с каждым разом всё меньше похож на прежний.",
            rating = 5.0, votes = 214, views = 44_800, updatedAt = "3 дн назад",
            chapters = chapters(33),
            ratingBreakdown = breakdown(200, 10, 3, 1, 0),
            listCounts = counts(230, 96, 74, 15, 6),
            isNew = true
        )
    )

    val blogPosts: List<BlogPost> = listOf(
        BlogPost("b1", "t1", "Varfolomeev", "16 авг. 2026, 09:50", "Закреплённый пост",
            "Глава 54 уже на сайте. Дальше выкладываем по вторникам и субботам, редакция вычитывает главы заранее, поэтому задержек быть не должно.",
            likes = 1024, dislikes = 0, comments = 500, views = 1200, pinned = true),
        BlogPost("b2", "t1", "Varfolomeev", "12 авг. 2026, 18:20", "Работа над томом 5",
            "Финальные страницы тома почти готовы. Показываю кадр без текста, чтобы не спойлерить сцену на крыше.",
            likes = 640, dislikes = 2, comments = 120, views = 880),
        BlogPost("b3", "t2", "ADmoral", "10 авг. 2026, 21:05", "Смена шрифта в диалогах",
            "Поменяли шрифт реплик: на телефонах старый читался хуже. Если где-то текст выходит за баллон — пишите в комментарии.",
            likes = 310, dislikes = 4, comments = 64, views = 520)
    )

    val comments: List<CommentItem> = listOf(
        CommentItem("c1", "t1", "SabirDzh", null, "сегодня в 00:29", "Атмосфера в последних главах вывозит всё. Сцена в лифте — топ.", 42, 5),
        CommentItem("c2", "t1", "tenKa", "модератор", "вчера в 21:40", "Напоминаю: спойлеры прячем под тег, иначе комментарий уйдёт в скрытые.", 18, 1),
        CommentItem("c3", "t1", "CrusaderC", null, "2 дн назад", "Рисовка стала заметно чище, чем в первом томе.", 27, 3),
        CommentItem("c4", "t2", "Jago", null, "3 дн назад", "Главный герой наконец перестал быть святым, и это лучшее решение автора.", 33, 2)
    )

    val reviews: List<ReviewItem> = listOf(
        ReviewItem("r1", "t1", "SabirDzh", "10 авг. 2026", 5, "Лучший хоррор площадки",
            "Автор держит напряжение за счёт бытовых деталей, а не скримеров. К 30-й главе появляется внятная логика разломов, и перечитывать становится интереснее, чем читать впервые.", 88),
        ReviewItem("r2", "t1", "Moon-Chiiie", "2 авг. 2026", 4, "Сильно, но местами затянуто",
            "Арка с общежитием могла быть короче на пять глав. В остальном претензий нет: персонажи живые, финал арки честный.", 34),
        ReviewItem("r3", "t2", "Skyler", "28 июл. 2026", 5, "Меч и политика",
            "Редкий случай, когда интриги читаются интереснее боёв. Автор не боится убивать нужных сюжету людей.", 51)
    )

    val forumTopics: List<ForumTopic> = listOf(
        ForumTopic("f1", "varfolomeev", "ВЛАДЕЛЕЦ", "16 авг. 2026, 09:50", "Общение", "Рекомендую к прочтению!", 3, 0, 4),
        ForumTopic("f2", "varfolomeev", "ВЛАДЕЛЕЦ", "11 авг. 2026, 18:20", "Поиск кадров", "Ищем менеджера/ссмщика", 0, 0, 2),
        ForumTopic("f3", "CrusaderC", null, "8 авг. 2026, 14:27", "Общение", "Худшая руманга — обсуждаем честно", 0, 4, 3),
        ForumTopic("f4", "tenKa", "модератор", "6 авг. 2026, 11:02", "Баги и проблемы", "Бета-тест приложения: пишите баги сюда", 12, 8, 46),
        ForumTopic("f5", "Jago", null, "4 авг. 2026, 19:15", "Поиск тайтлов", "Ищу тайтл про охранника и разломы", 5, 6, 31),
        ForumTopic("f6", "KaMa", null, "1 авг. 2026, 10:44", "Как рисовать мангу", "Как ставить свет в ночных сценах", 22, 14, 118),
        ForumTopic("f7", "Raven", null, "29 июл. 2026, 16:30", "Предложения для сайта", "Нужны коллекции с общим доступом", 17, 9, 77)
    )

    val history: List<HistoryEntry> = listOf(
        HistoryEntry("t1", "Глава 54", "2 ч назад"),
        HistoryEntry("t11", "Глава 41", "сегодня в 00:29"),
        HistoryEntry("t2", "Глава 30", "10 авг. в 21:05"),
        HistoryEntry("t16", "Глава 12", "10 авг. в 19:42"),
        HistoryEntry("t13", "Глава 4", "10 авг. в 01:39")
    )

    val myRatings: List<RatingEntry> = listOf(
        RatingEntry("t1", 5, "10 авг. в 20:09"),
        RatingEntry("t11", 5, "10 авг. в 20:09"),
        RatingEntry("t9", 1, "13 июн. в 17:22"),
        RatingEntry("t14", 5, "25 янв. в 16:33"),
        RatingEntry("t6", 5, "29 нояб. 2025 в 15:17")
    )

    /** Прочитано глав по дням недели — для графика в профиле. */
    val readingActivity: List<Pair<String, Int>> = listOf(
        "09.08" to 0, "10.08" to 5, "11.08" to 2, "12.08" to 0,
        "13.08" to 3, "14.08" to 1, "15.08" to 0, "16.08" to 4
    )
}
