package ru.mangalicht.app.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.Layout
import androidx.compose.ui.layout.Placeable
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import ru.mangalicht.app.ui.theme.ml

/** Блок-контейнер в стилистике сайта: тёмная плашка с тонкой рамкой. */
@Composable
fun MlBlock(
    modifier: Modifier = Modifier,
    padding: Int = 14,
    content: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit
) {
    val c = ml
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(c.blockInner)
            .border(1.dp, c.border, RoundedCornerShape(12.dp))
            .padding(padding.dp),
        content = content
    )
}

@Composable
fun MlChip(
    text: String,
    selected: Boolean = false,
    enabled: Boolean = true,
    onClick: () -> Unit
) {
    val c = ml
    val bg by animateColorAsState(
        if (selected) c.chipSelected else c.chip,
        tween(120), label = "chipBg"
    )
    val fg by animateColorAsState(
        when {
            selected -> Color.White
            enabled -> c.textMuted
            else -> c.textGhost
        },
        tween(120), label = "chipFg"
    )
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(bg)
            .border(1.dp, if (selected) bg else c.border, RoundedCornerShape(50))
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        Text(text, style = MaterialTheme.typography.labelMedium, color = fg, maxLines = 1)
    }
}

@Composable
fun MlTag(text: String, color: Color? = null) {
    val c = ml
    val tint = color ?: c.chip
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(tint)
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Text(
            text,
            style = MaterialTheme.typography.labelSmall,
            color = if (color != null) Color.White else c.textMuted,
            maxLines = 1
        )
    }
}

@Composable
fun SectionHeader(
    title: String,
    actionText: String? = null,
    onAction: (() -> Unit)? = null
) {
    val c = ml
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            title,
            style = MaterialTheme.typography.titleLarge,
            color = c.textMain,
            modifier = Modifier.weight(1f)
        )
        if (onAction != null) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .clickable(onClick = onAction)
                    .padding(horizontal = 6.dp, vertical = 4.dp)
            ) {
                if (actionText != null) {
                    Text(actionText, style = MaterialTheme.typography.labelMedium, color = c.textMuted)
                }
                Icon(
                    Icons.Filled.KeyboardArrowRight,
                    contentDescription = null,
                    tint = c.textMuted,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

@Composable
fun RatingStars(rating: Double, starSize: Int = 14, showValue: Boolean = false) {
    val c = ml
    Row(verticalAlignment = Alignment.CenterVertically) {
        repeat(5) { index ->
            Icon(
                Icons.Filled.Star,
                contentDescription = null,
                tint = if (index < rating.toInt()) c.yellow else c.textGhost,
                modifier = Modifier.size(starSize.dp)
            )
        }
        if (showValue) {
            Spacer(Modifier.width(6.dp))
            Text(
                formatRating(rating),
                style = MaterialTheme.typography.labelMedium,
                color = c.textMuted
            )
        }
    }
}

@Composable
fun RatingBadge(rating: Double) {
    val c = ml
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(Color.Black.copy(alpha = 0.68f))
            .padding(horizontal = 6.dp, vertical = 3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Filled.Star, null, tint = c.yellow, modifier = Modifier.size(11.dp))
        Spacer(Modifier.width(3.dp))
        Text(
            if (rating <= 0.0) "—" else formatRating(rating),
            style = MaterialTheme.typography.labelSmall,
            color = Color.White,
            fontWeight = FontWeight.SemiBold
        )
    }
}

/** Полоса распределения оценок / статистики. */
@Composable
fun StatBar(value: Int, max: Int, color: Color, height: Int = 8) {
    val c = ml
    val fraction by animateFloatAsState(
        targetValue = if (max <= 0) 0.001f else (value.toFloat() / max).coerceIn(0.001f, 1f),
        animationSpec = tween(420),
        label = "statBar"
    )
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(height.dp)
            .clip(RoundedCornerShape(50))
            .background(c.chip)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth(fraction)
                .height(height.dp)
                .clip(RoundedCornerShape(50))
                .background(color)
        )
    }
}

/** Табы в стилистике сайта: текст с подчёркиванием активного пункта. */
@Composable
fun MlTabRow(
    tabs: List<String>,
    selected: Int,
    badges: Map<Int, Int> = emptyMap(),
    onSelect: (Int) -> Unit
) {
    val c = ml
    LazyRow(
        modifier = Modifier
            .fillMaxWidth()
            .background(c.bgMain),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        items(count = tabs.size, key = { tabs[it] }) { index ->
            val active = index == selected
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .clickable { onSelect(index) }
                    .padding(horizontal = 10.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(vertical = 12.dp)
                ) {
                    Text(
                        tabs[index],
                        style = MaterialTheme.typography.labelLarge,
                        color = if (active) c.textMain else c.textMuted
                    )
                    val badge = badges[index]
                    if (badge != null && badge > 0) {
                        Spacer(Modifier.width(6.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(50))
                                .background(if (active) c.brand else c.chip)
                                .padding(horizontal = 6.dp, vertical = 1.dp)
                        ) {
                            Text(
                                badge.toString(),
                                style = MaterialTheme.typography.labelSmall,
                                color = if (active) Color.White else c.textMuted
                            )
                        }
                    }
                }
                Box(
                    Modifier
                        .height(2.dp)
                        .width(if (active) 100.dp else 0.dp)
                        .background(c.brand)
                )
            }
        }
    }
}

@Composable
fun MlSearchField(
    value: String,
    placeholder: String,
    modifier: Modifier = Modifier,
    onValueChange: (String) -> Unit
) {
    val c = ml
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(c.blockInner)
            .border(1.dp, c.border, RoundedCornerShape(12.dp))
            .padding(horizontal = 12.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Filled.Search, null, tint = c.textMuted, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(10.dp))
        Box(Modifier.weight(1f)) {
            if (value.isEmpty()) {
                Text(placeholder, style = MaterialTheme.typography.bodyMedium, color = c.textGhost)
            }
            BasicTextField(
                value = value,
                onValueChange = onValueChange,
                singleLine = true,
                textStyle = LocalTextStyle.current.copy(
                    color = c.textMain,
                    fontSize = MaterialTheme.typography.bodyMedium.fontSize
                ),
                cursorBrush = SolidColor(c.brand),
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
fun EmptyState(title: String, subtitle: String? = null) {
    val c = ml
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 24.dp, vertical = 48.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(title, style = MaterialTheme.typography.titleMedium, color = c.textMuted)
        if (subtitle != null) {
            Spacer(Modifier.height(6.dp))
            Text(
                subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = c.textGhost,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

fun formatRating(value: Double): String {
    if (value <= 0.0) return "—"
    val rounded = (value * 10).toInt()
    return "${rounded / 10}.${rounded % 10}"
}

fun formatCount(value: Int): String {
    val s = value.toString()
    val sb = StringBuilder()
    s.forEachIndexed { i, ch ->
        if (i > 0 && (s.length - i) % 3 == 0) sb.append(' ')
        sb.append(ch)
    }
    return sb.toString()
}

/**
 * Стабильная замена FlowRow: переносит элементы на новую строку,
 * когда они не влезают по ширине. Написана на Layout, без экспериментальных API.
 */
@Composable
fun MlFlowRow(
    modifier: Modifier = Modifier,
    horizontalGap: Dp = 8.dp,
    verticalGap: Dp = 8.dp,
    content: @Composable () -> Unit
) {
    Layout(modifier = modifier, content = content) { measurables, constraints ->
        val hGap = horizontalGap.roundToPx()
        val vGap = verticalGap.roundToPx()
        val maxRowWidth = if (constraints.maxWidth == Int.MAX_VALUE) Int.MAX_VALUE else constraints.maxWidth
        val itemConstraints = constraints.copy(minWidth = 0, minHeight = 0)
        val placeables = measurables.map { it.measure(itemConstraints) }

        val rows = mutableListOf<List<Placeable>>()
        var currentRow = mutableListOf<Placeable>()
        var currentWidth = 0
        placeables.forEach { placeable ->
            val gap = if (currentRow.isEmpty()) 0 else hGap
            if (currentRow.isNotEmpty() && currentWidth + gap + placeable.width > maxRowWidth) {
                rows.add(currentRow)
                currentRow = mutableListOf()
                currentWidth = 0
            }
            currentWidth += (if (currentRow.isEmpty()) 0 else hGap) + placeable.width
            currentRow.add(placeable)
        }
        if (currentRow.isNotEmpty()) rows.add(currentRow)

        val rowHeights = rows.map { row -> row.maxOfOrNull { it.height } ?: 0 }
        val contentHeight = rowHeights.sum() + if (rows.size > 1) vGap * (rows.size - 1) else 0
        val widestRow = rows.maxOfOrNull { row ->
            row.sumOf { it.width } + if (row.size > 1) hGap * (row.size - 1) else 0
        } ?: 0
        val layoutWidth = if (constraints.maxWidth == Int.MAX_VALUE) {
            widestRow.coerceAtLeast(constraints.minWidth)
        } else {
            constraints.maxWidth
        }
        val layoutHeight = contentHeight.coerceAtLeast(constraints.minHeight).let {
            if (constraints.maxHeight == Int.MAX_VALUE) it else it.coerceAtMost(constraints.maxHeight)
        }

        layout(layoutWidth, layoutHeight) {
            var y = 0
            rows.forEachIndexed { index, row ->
                var x = 0
                row.forEach { placeable ->
                    placeable.placeRelative(x, y)
                    x += placeable.width + hGap
                }
                y += rowHeights[index] + vGap
            }
        }
    }
}
