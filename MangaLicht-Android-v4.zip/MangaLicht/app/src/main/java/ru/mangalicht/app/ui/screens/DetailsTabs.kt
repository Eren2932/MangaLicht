package ru.mangalicht.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.SwapVert
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import ru.mangalicht.app.data.Chapter
import ru.mangalicht.app.data.MangaRepository
import ru.mangalicht.app.data.MangaTitle
import ru.mangalicht.app.data.ReadingStatus
import ru.mangalicht.app.data.UserLibrary
import ru.mangalicht.app.ui.components.CarouselCard
import ru.mangalicht.app.ui.components.EmptyState
import ru.mangalicht.app.ui.components.MlFlowRow
import ru.mangalicht.app.ui.components.MlChip
import ru.mangalicht.app.ui.components.MlTag
import ru.mangalicht.app.ui.components.RatingStars
import ru.mangalicht.app.ui.components.StatBar
import ru.mangalicht.app.ui.components.formatCount
import ru.mangalicht.app.ui.components.formatRating
import ru.mangalicht.app.ui.components.statusColor
import ru.mangalicht.app.ui.theme.ml

/* ------------------------------- Статистика ------------------------------- */

internal fun LazyListScope.statsTab(title: MangaTitle, onOpenTitle: (String) -> Unit) {
    item(key = "stats_rating") {
        val c = ml
        Column(Modifier.padding(16.dp)) {
            Block {
                Text("Оценка тайтла", style = MaterialTheme.typography.titleSmall, color = c.textMain)
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RatingStars(title.rating, starSize = 20)
                    Spacer(Modifier.width(10.dp))
                    Text(
                        formatRating(title.rating),
                        style = MaterialTheme.typography.titleMedium,
                        color = c.textMain
                    )
                    Text(
                        " / 5 · ${formatCount(title.votes)} оценок",
                        style = MaterialTheme.typography.labelSmall,
                        color = c.textMuted
                    )
                }
                Spacer(Modifier.height(14.dp))
                val max = (title.ratingBreakdown.values.maxOrNull() ?: 1).coerceAtLeast(1)
                (5 downTo 1).forEach { star ->
                    val value = title.ratingBreakdown[star] ?: 0
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(vertical = 3.dp)
                    ) {
                        Text(
                            star.toString(),
                            style = MaterialTheme.typography.labelSmall,
                            color = c.textMuted,
                            modifier = Modifier.width(10.dp)
                        )
                        Icon(Icons.Filled.Star, null, tint = c.yellow, modifier = Modifier.size(12.dp))
                        Spacer(Modifier.width(8.dp))
                        Box(Modifier.weight(1f)) { StatBar(value, max, c.yellow) }
                        Spacer(Modifier.width(8.dp))
                        Text(
                            formatCount(value),
                            style = MaterialTheme.typography.labelSmall,
                            color = c.textMuted,
                            modifier = Modifier.width(44.dp)
                        )
                    }
                }
            }
        }
    }

    item(key = "stats_lists") {
        val c = ml
        Column(Modifier.padding(horizontal = 16.dp)) {
            Block {
                Text(
                    "В списках у ${formatCount(title.readersCount)} читателей",
                    style = MaterialTheme.typography.titleSmall,
                    color = c.textMain
                )
                Spacer(Modifier.height(10.dp))
                ReadingStatus.entries.forEach { status ->
                    val value = title.listCounts[status] ?: 0
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(vertical = 4.dp)
                    ) {
                        Box(
                            Modifier
                                .size(8.dp)
                                .clip(RoundedCornerShape(50))
                                .background(statusColor(status))
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            status.label,
                            style = MaterialTheme.typography.labelMedium,
                            color = c.textMuted,
                            modifier = Modifier.width(88.dp)
                        )
                        Box(Modifier.weight(1f)) {
                            StatBar(
                                value,
                                title.readersCount.coerceAtLeast(1),
                                statusColor(status),
                                height = 7
                            )
                        }
                        Spacer(Modifier.width(8.dp))
                        Text(
                            formatCount(value),
                            style = MaterialTheme.typography.labelSmall,
                            color = c.textMuted,
                            modifier = Modifier.width(44.dp)
                        )
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
        }
    }

    item(key = "stats_similar") {
        val c = ml
        val similar = MangaRepository.similarTo(title)
        Column {
            Text(
                "Похожие тайтлы",
                style = MaterialTheme.typography.titleMedium,
                color = c.textMain,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
            )
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(count = similar.size, key = { similar[it].id }) { index ->
                    val item = similar[index]
                    CarouselCard(item) { onOpenTitle(item.id) }
                }
            }
        }
    }
}

/* --------------------------------- Главы --------------------------------- */

internal fun LazyListScope.chaptersTab(
    title: MangaTitle,
    chapters: List<Chapter>,
    descending: Boolean,
    status: ReadingStatus?,
    onToggleSort: () -> Unit,
    onStatusSelect: (ReadingStatus?) -> Unit,
    onOpenChapter: (String) -> Unit
) {
    item(key = "chapters_status") {
        val c = ml
        Column(Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
            Text("Мой список", style = MaterialTheme.typography.titleSmall, color = c.textMain)
            Spacer(Modifier.height(8.dp))
            MlFlowRow(horizontalGap = 8.dp, verticalGap = 8.dp) {
                ReadingStatus.entries.forEach { item ->
                    MlChip(item.label, selected = item == status) {
                        onStatusSelect(if (item == status) null else item)
                    }
                }
            }
        }
    }

    item(key = "chapters_toolbar") {
        val c = ml
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "Главы",
                style = MaterialTheme.typography.titleMedium,
                color = c.textMain
            )
            Spacer(Modifier.width(8.dp))
            Text(
                "всего ${title.chaptersCount}",
                style = MaterialTheme.typography.labelSmall,
                color = c.textMuted,
                modifier = Modifier.weight(1f)
            )
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .clickable(onClick = onToggleSort)
                    .padding(horizontal = 8.dp, vertical = 6.dp)
            ) {
                Icon(Icons.Filled.SwapVert, null, tint = c.textMuted, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text(
                    if (descending) "Новые" else "Старые",
                    style = MaterialTheme.typography.labelSmall,
                    color = c.textMuted
                )
            }
            Icon(
                Icons.Filled.Download,
                contentDescription = "Скачать",
                tint = c.textMuted,
                modifier = Modifier
                    .padding(start = 6.dp)
                    .size(18.dp)
            )
        }
    }

    if (chapters.isEmpty()) {
        item(key = "chapters_empty") {
            EmptyState("Главы ещё не загружены", "Тайтл в статусе «${title.status.label}»")
        }
        return
    }

    items(count = chapters.size, key = { chapters[it].id }) { index ->
        ChapterRow(
            titleId = title.id,
            chapter = chapters[index],
            onOpen = { onOpenChapter(chapters[index].id) }
        )
    }
}

@Composable
private fun ChapterRow(titleId: String, chapter: Chapter, onOpen: () -> Unit) {
    val c = ml
    val read = UserLibrary.isChapterRead(titleId, chapter.id)
    val current = UserLibrary.progressOf(titleId) == chapter.id
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(if (current) c.brand.copy(alpha = 0.10f) else Color.Transparent)
            .clickable(onClick = onOpen)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            chapter.number,
            style = MaterialTheme.typography.titleMedium,
            color = if (read) c.textGhost else c.brand,
            modifier = Modifier.width(38.dp)
        )
        Column(Modifier.weight(1f)) {
            Text(
                "Глава ${chapter.number}",
                style = MaterialTheme.typography.titleSmall,
                color = if (read) c.textMuted else c.textMain,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(2.dp))
            Text(
                "${chapter.pages} стр. · ${chapter.uploadedAt} · Том ${chapter.volume}",
                style = MaterialTheme.typography.labelSmall,
                color = c.textGhost,
                maxLines = 1
            )
        }
        if (chapter.myRating != null) {
            Icon(Icons.Filled.Star, null, tint = c.yellow, modifier = Modifier.size(13.dp))
            Spacer(Modifier.width(3.dp))
            Text(
                formatRating(chapter.myRating),
                style = MaterialTheme.typography.labelSmall,
                color = c.textMuted
            )
            Spacer(Modifier.width(10.dp))
        }
        Box(
            modifier = Modifier
                .size(30.dp)
                .clip(RoundedCornerShape(50))
                .background(if (read) c.positive.copy(alpha = 0.18f) else c.chip)
                .clickable { UserLibrary.markRead(titleId, chapter.id, !read) },
            contentAlignment = Alignment.Center
        ) {
            Icon(
                if (read) Icons.Filled.Check else Icons.Filled.Visibility,
                contentDescription = if (read) "Прочитано" else "Отметить прочитанной",
                tint = if (read) c.positive else c.textMuted,
                modifier = Modifier.size(15.dp)
            )
        }
    }
    Box(Modifier.fillMaxWidth().height(1.dp).background(c.border))
}

/* ---------------------------------- Блог ---------------------------------- */

internal fun LazyListScope.blogTab(title: MangaTitle) {
    val posts = MangaRepository.blogOf(title.id)
    if (posts.isEmpty()) {
        item(key = "blog_empty") { EmptyState("Записей пока нет") }
        return
    }
    items(count = posts.size, key = { posts[it].id }) { index ->
        val post = posts[index]
        val c = ml
        Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
            Block {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (post.pinned) {
                        Icon(Icons.Filled.PushPin, null, tint = c.brand, modifier = Modifier.size(14.dp))
                        Spacer(Modifier.width(6.dp))
                    }
                    Text(
                        post.headline,
                        style = MaterialTheme.typography.titleSmall,
                        color = c.textMain,
                        modifier = Modifier.weight(1f)
                    )
                    Text(post.date, style = MaterialTheme.typography.labelSmall, color = c.textGhost)
                }
                Spacer(Modifier.height(8.dp))
                Text(post.body, style = MaterialTheme.typography.bodySmall, color = c.textMuted)
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(post.author, style = MaterialTheme.typography.labelSmall, color = c.textMuted)
                    Spacer(Modifier.weight(1f))
                    MetricIcon(Icons.Filled.ThumbUp, formatCount(post.likes))
                    Spacer(Modifier.width(12.dp))
                    MetricIcon(Icons.Filled.ChatBubbleOutline, formatCount(post.comments))
                    Spacer(Modifier.width(12.dp))
                    MetricIcon(Icons.Filled.Visibility, formatCount(post.views))
                }
            }
        }
    }
}

/* ------------------------------ Комментарии ------------------------------ */

internal fun LazyListScope.commentsTab(title: MangaTitle) {
    val comments = MangaRepository.commentsOf(title.id)
    item(key = "comments_hint") {
        val c = ml
        Text(
            "Комментарии · ${comments.size}",
            style = MaterialTheme.typography.titleMedium,
            color = c.textMain,
            modifier = Modifier.padding(16.dp)
        )
    }
    items(count = comments.size, key = { comments[it].id }) { index ->
        val comment = comments[index]
        val c = ml
        Column(Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
            Block {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier
                            .size(30.dp)
                            .clip(RoundedCornerShape(50))
                            .background(c.chip),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            comment.author.take(1).uppercase(),
                            style = MaterialTheme.typography.labelMedium,
                            color = c.textMain
                        )
                    }
                    Spacer(Modifier.width(10.dp))
                    Text(comment.author, style = MaterialTheme.typography.titleSmall, color = c.textMain)
                    if (comment.role != null) {
                        Spacer(Modifier.width(6.dp))
                        MlTag(comment.role.uppercase(), c.brand)
                    }
                    Spacer(Modifier.weight(1f))
                    Text(comment.date, style = MaterialTheme.typography.labelSmall, color = c.textGhost)
                }
                Spacer(Modifier.height(8.dp))
                Text(comment.body, style = MaterialTheme.typography.bodyMedium, color = c.textMuted)
                Spacer(Modifier.height(8.dp))
                Row {
                    MetricIcon(Icons.Filled.ThumbUp, comment.likes.toString())
                    Spacer(Modifier.width(14.dp))
                    MetricIcon(Icons.Filled.ChatBubbleOutline, comment.replies.toString())
                }
            }
        }
    }
}

/* -------------------------------- Рецензии -------------------------------- */

internal fun LazyListScope.reviewsTab(title: MangaTitle) {
    val reviews = MangaRepository.reviewsOf(title.id)
    if (reviews.isEmpty()) {
        item(key = "reviews_empty") { EmptyState("Рецензий пока нет") }
        return
    }
    items(count = reviews.size, key = { reviews[it].id }) { index ->
        val review = reviews[index]
        val c = ml
        Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
            Block {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        review.headline,
                        style = MaterialTheme.typography.titleSmall,
                        color = c.textMain,
                        modifier = Modifier.weight(1f)
                    )
                    RatingStars(review.rating.toDouble(), starSize = 13)
                }
                Spacer(Modifier.height(8.dp))
                Text(review.body, style = MaterialTheme.typography.bodyMedium, color = c.textMuted)
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "${review.author} · ${review.date}",
                        style = MaterialTheme.typography.labelSmall,
                        color = c.textGhost,
                        modifier = Modifier.weight(1f)
                    )
                    MetricIcon(Icons.Filled.ThumbUp, review.likes.toString())
                }
            }
        }
    }
}

/* -------------------------------- Утилиты -------------------------------- */

@Composable
internal fun MetricIcon(icon: androidx.compose.ui.graphics.vector.ImageVector, value: String) {
    val c = ml
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = c.textGhost, modifier = Modifier.size(14.dp))
        Spacer(Modifier.width(4.dp))
        Text(value, style = MaterialTheme.typography.labelSmall, color = c.textGhost)
    }
}

@Composable
internal fun Block(content: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit) {
    val c = ml
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(c.blockInner)
            .border(1.dp, c.border, RoundedCornerShape(12.dp))
            .padding(14.dp),
        content = content
    )
}
