# MangaLicht Android

Нативная мобильная база MangaLicht на Kotlin и Jetpack Compose. Проект содержит главную, каталог, популярное, форум, профиль, карточку тайтла и демонстрационный просмотр. Данные пока локальные; сетевой слой подготовлен зависимостями Retrofit/OkHttp.

## Сборка APK через GitHub Actions

1. Создайте пустой GitHub-репозиторий.
2. Загрузите **содержимое** этой папки в корень репозитория.
3. Откройте `Actions` → `Build Android APK` → `Run workflow`.
4. После сборки скачайте artifact `MangaLicht-debug-apk`.

Workflow использует Gradle 8.9, JDK 17 и собирает `app-debug.apk` без необходимости хранить Gradle Wrapper JAR.

## Открытие в Android Studio

Откройте корневую папку проекта. Android Studio предложит синхронизировать Gradle. Если IDE требует wrapper, выполните локально `gradle wrapper --gradle-version 8.9` или используйте встроенный Gradle IDE.

## Подключение backend

Замените `MockMangaRepository` реализацией `RemoteMangaRepository`, добавьте DTO/API-интерфейсы Retrofit и настройте base URL. UI и навигацию переделывать не потребуется.

## Идентификаторы

- Application ID: `ru.mangalicht.app`
- Min SDK: 26
- Target/Compile SDK: 35
- Version: 0.1.0
