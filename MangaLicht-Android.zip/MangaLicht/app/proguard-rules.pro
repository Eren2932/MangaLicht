# MangaLicht release rules. Add API DTO keep rules when a backend is connected.
