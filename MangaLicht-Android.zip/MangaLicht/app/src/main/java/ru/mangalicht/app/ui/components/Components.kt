package ru.mangalicht.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ru.mangalicht.app.data.TitleItem
import ru.mangalicht.app.ui.theme.*

private val cardGradients = listOf(
    listOf(Color(0xFF182848), Color(0xFF4B6CB7)), listOf(Color(0xFF42275A), Color(0xFF734B6D)),
    listOf(Color(0xFF0F2027), Color(0xFF2C5364)), listOf(Color(0xFF3E2723), Color(0xFF8D6E63)),
    listOf(Color(0xFF232526), Color(0xFF414345)), listOf(Color(0xFF134E5E), Color(0xFF71B280))
)

@Composable
fun TitleArtwork(item: TitleItem, modifier: Modifier = Modifier, large: Boolean = false) {
    val colors = cardGradients[item.paletteSeed % cardGradients.size]
    Box(
        modifier.clip(RoundedCornerShape(if (large) 20.dp else 12.dp))
            .background(Brush.linearGradient(colors)).padding(12.dp)
    ) {
        Text(item.title.take(1), color = Color.White.copy(.12f), fontSize = if (large) 150.sp else 76.sp,
            fontWeight = FontWeight.Black, modifier = Modifier.align(Alignment.CenterEnd))
        Surface(color = Color.Black.copy(.52f), shape = RoundedCornerShape(8.dp), modifier = Modifier.align(Alignment.TopEnd)) {
            Text(item.status, color = Color.White, fontSize = 10.sp, modifier = Modifier.padding(horizontal = 7.dp, vertical = 4.dp))
        }
        Row(Modifier.align(Alignment.BottomStart), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.PlayArrow, null, tint = Color.White, modifier = Modifier.size(15.dp))
            Text(item.duration, color = Color.White, fontSize = 11.sp)
        }
    }
}

@Composable
fun MangaCard(item: TitleItem, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Column(modifier.clickable(onClick = onClick)) {
        Box {
            TitleArtwork(item, Modifier.fillMaxWidth().aspectRatio(1.48f))
            if (item.rating != null) Surface(color = Grey850.copy(.82f), shape = RoundedCornerShape(7.dp), modifier = Modifier.padding(7.dp)) {
                Row(Modifier.padding(horizontal = 6.dp, vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Star, null, tint = Color(0xFFFFD600), modifier = Modifier.size(12.dp))
                    Spacer(Modifier.width(3.dp)); Text("%.1f".format(item.rating), fontSize = 10.sp, color = White)
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        Text(item.title.uppercase(), style = MaterialTheme.typography.titleMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
        Spacer(Modifier.height(3.dp))
        Text("${item.genre} · ${item.year} · ${item.episodes} серия", style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun FilterPill(text: String, selected: Boolean, onClick: () -> Unit) {
    FilterChip(selected = selected, onClick = onClick, label = { Text(text) }, shape = RoundedCornerShape(50),
        colors = FilterChipDefaults.filterChipColors(selectedContainerColor = MaterialTheme.colorScheme.primary.copy(.14f),
            selectedLabelColor = MaterialTheme.colorScheme.primary),
        border = FilterChipDefaults.filterChipBorder(enabled = true, selected = selected,
            borderColor = MaterialTheme.colorScheme.outline.copy(.45f), selectedBorderColor = MaterialTheme.colorScheme.primary))
}

@Composable
fun SectionHeader(title: String, action: String? = null, onAction: () -> Unit = {}) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        Text(title, style = MaterialTheme.typography.titleLarge)
        if (action != null) TextButton(onClick = onAction) { Text(action) }
    }
}
