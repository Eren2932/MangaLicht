package ru.mangalicht.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import ru.mangalicht.app.data.sampleTitles
import ru.mangalicht.app.ui.components.FilterPill
import ru.mangalicht.app.ui.components.MangaCard

@Composable
fun PopularScreen(padding: PaddingValues, openDetails: (Int) -> Unit) {
    var selected by remember { mutableStateOf("По рейтингу") }
    val filters = listOf("По рейтингу", "По просмотрам", "Новые", "Онгоинг")
    val data = when (selected) { "По рейтингу" -> sampleTitles.sortedByDescending { it.rating ?: 0.0 }; "Новые" -> sampleTitles.reversed(); else -> sampleTitles }
    LazyVerticalGrid(GridCells.Adaptive(155.dp), Modifier.fillMaxSize().padding(padding), contentPadding = PaddingValues(16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(20.dp)) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            Column { Text("Популярное", style = MaterialTheme.typography.headlineMedium); Text("Лучшие истории по рейтингу и просмотрам", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(10.dp)); LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) { items(filters) { f -> FilterPill(f, selected == f) { selected = f } } } }
        }
        items(data, key = { it.id }) { MangaCard(it, { openDetails(it.id) }) }
    }
}
