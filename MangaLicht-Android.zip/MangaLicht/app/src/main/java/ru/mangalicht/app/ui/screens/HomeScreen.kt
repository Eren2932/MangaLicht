package ru.mangalicht.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.NotificationsNone
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import ru.mangalicht.app.data.sampleTitles
import ru.mangalicht.app.ui.components.MangaCard
import ru.mangalicht.app.ui.components.SectionHeader

@Composable
fun HomeScreen(padding: PaddingValues, openCatalog: () -> Unit, openDetails: (Int) -> Unit) {
    Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState())) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Manga", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.tertiary)
            Text("Licht", style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.weight(1f)); IconButton(onClick = {}) { Icon(Icons.Default.NotificationsNone, "Уведомления") }
        }
        Box(Modifier.padding(horizontal = 16.dp).fillMaxWidth().height(390.dp).background(
            Brush.verticalGradient(listOf(Color(0xFF253047), Color(0xFF090A0D))), RoundedCornerShape(20.dp)).padding(22.dp)) {
            Column(Modifier.align(Alignment.BottomStart)) {
                Text("НОВИНКА НЕДЕЛИ", color = MaterialTheme.colorScheme.tertiary, style = MaterialTheme.typography.labelLarge)
                Spacer(Modifier.height(10.dp)); Text("ТЫ — МЕНТ В ЭПОХУ БЕСПРЕДЕЛА", style = MaterialTheme.typography.headlineLarge, color = Color.White)
                Spacer(Modifier.height(12.dp)); Text("Новые серии появляются автоматически. Смотри истории в удобном мобильном формате.",
                    style = MaterialTheme.typography.bodyMedium, color = Color.White.copy(.72f))
                Spacer(Modifier.height(18.dp)); Row {
                    Button(onClick = { openDetails(1) }) { Icon(Icons.Default.PlayArrow, null); Spacer(Modifier.width(6.dp)); Text("Смотреть") }
                    Spacer(Modifier.width(10.dp)); OutlinedButton(onClick = openCatalog) { Text("Каталог") }
                }
            }
        }
        Surface(Modifier.padding(16.dp).fillMaxWidth(), color = MaterialTheme.colorScheme.tertiary.copy(.09f),
            shape = RoundedCornerShape(16.dp), border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.tertiary.copy(.35f))) {
            Column(Modifier.padding(18.dp)) {
                Text("РОЗЫГРЫШ", color = MaterialTheme.colorScheme.tertiary, style = MaterialTheme.typography.labelLarge)
                Text("Участвуй в розыгрыше MangaLicht", style = MaterialTheme.typography.titleLarge)
                Text("Следи за новостями проекта в Telegram-канале.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Column(Modifier.padding(bottom = 24.dp)) {
            Box(Modifier.padding(horizontal = 16.dp)) { SectionHeader("Новые анимации", "Смотреть все", openCatalog) }
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                sampleTitles.take(6).forEach { item -> Box(Modifier.width(260.dp)) { MangaCard(item, { openDetails(item.id) }) } }
            }
        }
    }
}
