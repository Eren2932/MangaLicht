package ru.mangalicht.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import ru.mangalicht.app.data.sampleTitles

@Composable
fun ReaderScreen(id: Int, back: () -> Unit) {
    val item = sampleTitles.firstOrNull { it.id == id } ?: sampleTitles.first()
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        Box(Modifier.fillMaxWidth().aspectRatio(16f / 9f).align(Alignment.Center).background(Brush.linearGradient(listOf(Color(0xFF172033), Color(0xFF090A0D)))), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) { Surface(shape = androidx.compose.foundation.shape.CircleShape, color = MaterialTheme.colorScheme.primary) { Icon(Icons.Default.PlayArrow, null, Modifier.padding(20.dp).size(34.dp), tint = Color.White) }; Spacer(Modifier.height(18.dp)); Text("Демонстрационный просмотр", color = Color.White, style = MaterialTheme.typography.titleLarge); Text("Видео появится после подключения API", color = Color.White.copy(.62f)) }
        }
        Row(Modifier.fillMaxWidth().statusBarsPadding().padding(12.dp), verticalAlignment = Alignment.CenterVertically) { IconButton(onClick = back) { Icon(Icons.Default.ArrowBack, "Назад", tint = Color.White) }; Text(item.title, color = Color.White, maxLines = 1, modifier = Modifier.weight(1f), textAlign = TextAlign.Start) }
        Surface(Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(16.dp), color = Color(0xFF18181B), shape = RoundedCornerShape(14.dp)) { Text("Серия 1 · ${item.duration}", Modifier.padding(horizontal = 18.dp, vertical = 12.dp), color = Color.White) }
    }
}
