package ru.mangalicht.app.ui

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.*
import ru.mangalicht.app.ui.screens.*

private data class Tab(val route: String, val label: String, val selected: ImageVector, val idle: ImageVector)
private val tabs = listOf(
    Tab("home", "Главная", Icons.Filled.Home, Icons.Outlined.Home),
    Tab("catalog", "Каталог", Icons.Filled.GridView, Icons.Outlined.GridView),
    Tab("popular", "Лучшее", Icons.Filled.Star, Icons.Outlined.Star),
    Tab("forum", "Форум", Icons.Filled.Forum, Icons.Outlined.Forum),
    Tab("profile", "Профиль", Icons.Filled.Person, Icons.Outlined.Person)
)

@Composable
fun MangaLichtApp() {
    val nav = rememberNavController()
    val entry = nav.currentBackStackEntryAsState().value
    val route = entry?.destination?.route.orEmpty()
    val detail = route.startsWith("details") || route.startsWith("reader")
    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            if (!detail) NavigationBar {
                tabs.forEach { tab ->
                    val selected = route == tab.route
                    NavigationBarItem(selected = selected, onClick = {
                        nav.navigate(tab.route) {
                            popUpTo(nav.graph.findStartDestination().id) { saveState = true }
                            launchSingleTop = true; restoreState = true
                        }
                    }, icon = { Icon(if (selected) tab.selected else tab.idle, tab.label) }, label = { Text(tab.label) })
                }
            }
        }
    ) { padding ->
        NavHost(navController = nav, startDestination = "home", modifier = Modifier.fillMaxSize()) {
            composable("home") { HomeScreen(padding, { nav.navigate("catalog") }, { nav.navigate("details/$it") }) }
            composable("catalog") { CatalogScreen(padding) { nav.navigate("details/$it") } }
            composable("popular") { PopularScreen(padding) { nav.navigate("details/$it") } }
            composable("forum") { ForumScreen(padding) }
            composable("profile") { ProfileScreen(padding) }
            composable("details/{id}") { back ->
                DetailsScreen(back.arguments?.getString("id")?.toIntOrNull() ?: 1, nav::popBackStack) { nav.navigate("reader/$it") }
            }
            composable("reader/{id}") { back -> ReaderScreen(back.arguments?.getString("id")?.toIntOrNull() ?: 1, nav::popBackStack) }
        }
    }
}
