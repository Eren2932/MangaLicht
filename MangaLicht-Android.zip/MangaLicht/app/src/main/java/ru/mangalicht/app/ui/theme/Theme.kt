package ru.mangalicht.app.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val DarkColors = darkColorScheme(
    primary = Accent,
    onPrimary = White,
    secondary = Grey600,
    tertiary = BrandRose,
    background = Black,
    onBackground = White,
    surface = Grey800,
    onSurface = White,
    surfaceVariant = Grey700,
    onSurfaceVariant = Grey100,
    outline = Grey600,
    error = BrandRose
)
private val LightColors = lightColorScheme(
    primary = AccentLight,
    onPrimary = White,
    secondary = Grey50,
    tertiary = Color(0xFFC41E3A),
    background = White,
    onBackground = Black,
    surface = Grey50,
    onSurface = Black,
    surfaceVariant = White,
    onSurfaceVariant = Grey800,
    outline = Grey300
)

@Composable
fun MangaLichtTheme(darkTheme: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    val colors = if (darkTheme) DarkColors else LightColors
    val view = LocalView.current
    if (!view.isInEditMode) {
        val window = (view.context as Activity).window
        WindowCompat.getInsetsController(window, view).apply {
            isAppearanceLightStatusBars = !darkTheme
            isAppearanceLightNavigationBars = !darkTheme
        }
    }
    MaterialTheme(colorScheme = colors, typography = AppTypography, content = content)
}
