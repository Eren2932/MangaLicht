package ru.mangalicht.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import ru.mangalicht.app.data.sampleTopics
import ru.mangalicht.app.ui.components.FilterPill

@Composable
fun ForumScreen(padding: PaddingValues) {
    var selected by remember { mutableStateOf("Все") }
    val categories = listOf("Все", "Общение", "Новости", "Обсуждения", "Предложения", "Помощь")
    LazyColumn(Modifier.fillMaxSize().padding(padding), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { Text("Форум", style = MaterialTheme.typography.headlineMedium); Text("Общение сообщества", color = MaterialTheme.colorScheme.onSurfaceVariant) }
            Button(onClick = {}) { Icon(Icons.Default.Add, null); Text("Тема") }
        } }
        item { androidx.compose.foundation.lazy.LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) { items(categories.size) { i -> FilterPill(categories[i], selected == categories[i]) { selected = categories[i] } } } }
        items(sampleTopics) { topic -> Card(shape = RoundedCornerShape(14.dp)) { Column(Modifier.padding(16.dp)) {
            Text(topic.title, style = MaterialTheme.typography.titleMedium); Spacer(Modifier.height(5.dp)); Text("${topic.category} · ${topic.author} · ${topic.age}", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(12.dp)); Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Outlined.ChatBubbleOutline, null, Modifier.size(16.dp)); Text(" ${topic.comments}"); Spacer(Modifier.width(18.dp)); Icon(Icons.Outlined.Visibility, null, Modifier.size(17.dp)); Text(" ${topic.views}") }
        } } }
    }
}
