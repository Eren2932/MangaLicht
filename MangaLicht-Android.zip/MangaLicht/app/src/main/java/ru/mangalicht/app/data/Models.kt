package ru.mangalicht.app.data

data class TitleItem(
    val id: Int,
    val title: String,
    val description: String,
    val genre: String,
    val year: Int,
    val episodes: Int,
    val duration: String,
    val rating: Double?,
    val status: String = "Онгоинг",
    val imageUrl: String? = null,
    val paletteSeed: Int
)

data class ForumTopic(
    val id: Int,
    val title: String,
    val category: String,
    val author: String,
    val age: String,
    val comments: Int,
    val views: Int
)
