package ru.mangalicht.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun ProfileScreen(padding: PaddingValues) {
    Column(Modifier.fillMaxSize().padding(padding).padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(18.dp)); Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primary.copy(.15f), modifier = Modifier.size(88.dp)) {
            Box(contentAlignment = Alignment.Center) { Icon(Icons.Outlined.Person, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(42.dp)) }
        }
        Spacer(Modifier.height(18.dp)); Text("Личный кабинет", style = MaterialTheme.typography.headlineMedium)
        Text("Войди, чтобы синхронизировать историю и избранное", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(24.dp)); Button(onClick = {}, Modifier.fillMaxWidth().height(52.dp)) { Text("Войти") }
        Spacer(Modifier.height(10.dp)); OutlinedButton(onClick = {}, Modifier.fillMaxWidth().height(52.dp)) { Text("Создать аккаунт") }
        Spacer(Modifier.height(30.dp))
        Card(shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) { Column {
            ProfileRow(Icons.Outlined.BookmarkBorder, "Избранное", "Сохранённые истории")
            HorizontalDivider(); ProfileRow(Icons.Outlined.History, "История", "Продолжить просмотр")
            HorizontalDivider(); ProfileRow(Icons.Outlined.Settings, "Настройки", "Тема, загрузки и данные")
        } }
        Spacer(Modifier.weight(1f)); Text("MangaLicht 0.1.0", color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable private fun ProfileRow(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, subtitle: String) {
    Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) { Icon(icon, null); Spacer(Modifier.width(14.dp)); Column { Text(title, style = MaterialTheme.typography.titleMedium); Text(subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium) } }
}
