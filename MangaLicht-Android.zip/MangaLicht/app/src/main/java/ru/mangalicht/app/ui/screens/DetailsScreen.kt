package ru.mangalicht.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import ru.mangalicht.app.data.sampleTitles
import ru.mangalicht.app.ui.components.TitleArtwork

@Composable
fun DetailsScreen(id: Int, back: () -> Unit, watch: (Int) -> Unit) {
    val item = sampleTitles.firstOrNull { it.id == id } ?: sampleTitles.first()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 30.dp)) {
        Box { TitleArtwork(item, Modifier.fillMaxWidth().height(390.dp), large = true); IconButton(onClick = back, modifier = Modifier.statusBarsPadding().padding(10.dp)) { Surface(shape = androidx.compose.foundation.shape.CircleShape, color = MaterialTheme.colorScheme.background.copy(.75f)) { Icon(Icons.Default.ArrowBack, "Назад", Modifier.padding(10.dp)) } } }
        Column(Modifier.padding(20.dp)) {
            Text(item.title, style = MaterialTheme.typography.headlineMedium); Spacer(Modifier.height(8.dp)); Text("${item.genre} · ${item.year} · ${item.status}", color = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(16.dp)); Text(item.description, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(22.dp)); Row { Button(onClick = { watch(item.id) }, Modifier.weight(1f).height(52.dp)) { Icon(Icons.Default.PlayArrow, null); Text(" Смотреть") }; Spacer(Modifier.width(10.dp)); OutlinedButton(onClick = {}, Modifier.height(52.dp)) { Icon(Icons.Outlined.BookmarkBorder, "В избранное") } }
            Spacer(Modifier.height(28.dp)); Text("Серии", style = MaterialTheme.typography.titleLarge); Spacer(Modifier.height(10.dp))
            Card(onClick = { watch(item.id) }, modifier = Modifier.fillMaxWidth()) { Row(Modifier.padding(16.dp)) { Text("1", color = MaterialTheme.colorScheme.primary); Spacer(Modifier.width(14.dp)); Column { Text("Первая серия", style = MaterialTheme.typography.titleMedium); Text(item.duration, color = MaterialTheme.colorScheme.onSurfaceVariant) } } }
        }
    }
}
