package ru.mangalicht.app.ui.theme

import androidx.compose.ui.graphics.Color

val Black = Color(0xFF000000)
val Grey850 = Color(0xFF101013)
val Grey800 = Color(0xFF18181B)
val Grey700 = Color(0xFF303136)
val Grey600 = Color(0xFF484A51)
val Grey500 = Color(0xFF60636C)
val Grey300 = Color(0xFF93969F)
val Grey100 = Color(0xFFC9CBCF)
val Grey50 = Color(0xFFE4E5E7)
val White = Color(0xFFFFFFFF)
val Accent = Color(0xFF0085FF)
val AccentLight = Color(0xFF168FFF)
val BrandRose = Color(0xFFE4334A)
val Positive = Color(0xFF40DD8F)
val Yellow = Color(0xFFF7C870)
