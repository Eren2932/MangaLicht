package ru.mangalicht.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import ru.mangalicht.app.data.sampleTitles
import ru.mangalicht.app.ui.components.MangaCard

@Composable
fun CatalogScreen(padding: PaddingValues, openDetails: (Int) -> Unit) {
    var query by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf("Все") }
    val data = sampleTitles.filter { it.title.contains(query, true) && (filter == "Все" || it.status == filter) }
    LazyVerticalGrid(columns = GridCells.Adaptive(155.dp), modifier = Modifier.fillMaxSize().padding(padding),
        contentPadding = PaddingValues(16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(20.dp)) {
        item(span = { androidx.compose.foundation.lazy.grid.GridItemSpan(maxLineSpan) }) {
            Column {
                Text("Каталог", style = MaterialTheme.typography.headlineMedium)
                Text("Все истории MangaLicht", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(14.dp))
                OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth(), placeholder = { Text("Название или жанр") },
                    leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true)
                Spacer(Modifier.height(10.dp)); SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                    listOf("Все", "Онгоинг").forEachIndexed { index, text -> SegmentedButton(selected = filter == text, onClick = { filter = text },
                        shape = SegmentedButtonDefaults.itemShape(index, 2)) { Text(text) } }
                }
            }
        }
        items(data, key = { it.id }) { MangaCard(it, { openDetails(it.id) }) }
        if (data.isEmpty()) item(span = { androidx.compose.foundation.lazy.grid.GridItemSpan(maxLineSpan) }) {
            Text("Ничего не найдено", modifier = Modifier.padding(vertical = 48.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
