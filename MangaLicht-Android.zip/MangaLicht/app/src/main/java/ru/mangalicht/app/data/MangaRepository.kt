package ru.mangalicht.app.data

interface MangaRepository {
    suspend fun titles(): List<TitleItem>
    suspend fun topics(): List<ForumTopic>
}

class MockMangaRepository : MangaRepository {
    override suspend fun titles() = sampleTitles
    override suspend fun topics() = sampleTopics
}

val sampleTitles = listOf(
    TitleItem(1, "Ты — мент в эпоху беспредела", "История человека, которому предстоит сделать выбор в мире без простых ответов.", "Факт без жалости", 2026, 1, "40 мин", null, paletteSeed = 1),
    TitleItem(2, "Я был мужем-монстром", "Возвращение в прошлое превращается в борьбу за новую жизнь.", "Webtoon Stories", 2026, 1, "114 мин", 5.0, paletteSeed = 2),
    TitleItem(3, "Я испортил 999 свиданий", "Неожиданная романтическая история с иронией и драмой.", "Webtoon Stories", 2026, 1, "52 мин", 5.0, paletteSeed = 3),
    TitleItem(4, "Женщина-викинг", "Рожденная в эпоху, где сила решает всё.", "Факт без жалости", 2026, 1, "41 мин", 1.0, paletteSeed = 4),
    TitleItem(5, "Разводила на крипте", "Цена одной ошибки в мире больших обещаний.", "Факт без жалости", 2026, 1, "38 мин", null, paletteSeed = 5),
    TitleItem(6, "Должник, за которым пришли коллекторы", "Один вечер меняет правила игры.", "Факт без жалости", 2026, 1, "35 мин", null, paletteSeed = 6),
    TitleItem(7, "Прораб", "Когда стройка становится историей всей жизни.", "Обратная сторона", 2026, 1, "29 мин", null, paletteSeed = 7),
    TitleItem(8, "Дроппер, который думал, что это лёгкие деньги", "История о последствиях быстрого заработка.", "Факт без жалости", 2026, 1, "33 мин", null, paletteSeed = 8),
    TitleItem(9, "Тот, кто живёт на теплотрассе", "Суровая драма о человеческом достоинстве.", "Факт без жалости", 2026, 1, "35 мин", null, paletteSeed = 9),
    TitleItem(10, "Четвёртый богатырь", "Мрачное приключение в знакомом мире.", "Факт без жалости", 2026, 1, "35 мин", null, paletteSeed = 10)
)

val sampleTopics = listOf(
    ForumTopic(1, "Бета-тест нового приложения", "Новости проекта", "MangaLicht", "сегодня", 14, 128),
    ForumTopic(2, "Какие истории добавить в каталог?", "Предложения", "reader_01", "2 ч назад", 8, 64),
    ForumTopic(3, "Обсуждение новинки недели", "Обсуждения", "Jago", "вчера", 21, 305),
    ForumTopic(4, "Помощь и ответы на вопросы", "Помощь", "team", "3 дн назад", 5, 92)
)
