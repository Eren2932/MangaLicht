package ru.mangalicht.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import ru.mangalicht.app.ui.icons.MlIcons
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.lazy.items
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.window.Dialog
import ru.mangalicht.app.data.UserLibrary
import ru.mangalicht.app.data.DemoData
import ru.mangalicht.app.data.MangaRepository
import ru.mangalicht.app.ui.components.EmptyState
import ru.mangalicht.app.ui.components.MlChip
import ru.mangalicht.app.ui.components.MlSearchField
import ru.mangalicht.app.ui.components.MlTag
import ru.mangalicht.app.ui.theme.ml

@Composable
fun ForumScreen(onOpenAuth: () -> Unit) {
    val c = ml
    var category by rememberSaveable { mutableStateOf(DemoData.forumCategories.first()) }
    var query by rememberSaveable { mutableStateOf("") }
    var composing by rememberSaveable { mutableStateOf(false) }
    val topics by remember {
        derivedStateOf { MangaRepository.forumTopics(category, query) }
    }

    if (composing) {
        NewTopicDialog(
            onDismiss = { composing = false },
            onOpenAuth = {
                composing = false
                onOpenAuth()
            },
            onCreate = { newCategory, newTitle ->
                MangaRepository.addTopic(
                    category = newCategory,
                    title = newTitle,
                    author = UserLibrary.account.value?.name ?: "Гость"
                )
                category = newCategory
                query = ""
                composing = false
            }
        )
    }

    Box(Modifier.fillMaxWidth()) {
        LazyColumn(contentPadding = PaddingValues(bottom = 90.dp)) {
            item(key = "header") {
                Column(Modifier.padding(horizontal = 16.dp)) {
                    Spacer(Modifier.height(14.dp))
                    Text("Форум", style = MaterialTheme.typography.headlineSmall, color = c.textMain)
                    Spacer(Modifier.height(2.dp))
                    Text(
                        "Общение сообщества MangaLicht",
                        style = MaterialTheme.typography.bodySmall,
                        color = c.textMuted
                    )
                    Spacer(Modifier.height(12.dp))
                    MlSearchField(value = query, placeholder = "Поиск тем...") { query = it }
                    Spacer(Modifier.height(10.dp))
                }
            }
            item(key = "categories") {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(count = DemoData.forumCategories.size, key = { DemoData.forumCategories[it] }) { index ->
                        val item = DemoData.forumCategories[index]
                        MlChip(item, selected = item == category) { category = item }
                    }
                }
                Spacer(Modifier.height(8.dp))
            }

            if (topics.isEmpty()) {
                item(key = "empty") { EmptyState("Тем пока нет", "Начни обсуждение первым") }
            } else {
                items(count = topics.size, key = { topics[it].id }) { index ->
                    val topic = topics[index]
                    Column(Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
                        Block {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    Modifier
                                        .size(32.dp)
                                        .clip(RoundedCornerShape(50))
                                        .background(c.chip),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        topic.author.take(1).uppercase(),
                                        style = MaterialTheme.typography.labelMedium,
                                        color = c.textMain
                                    )
                                }
                                Spacer(Modifier.width(10.dp))
                                Text(
                                    topic.author,
                                    style = MaterialTheme.typography.titleSmall,
                                    color = c.textMain
                                )
                                if (topic.role != null) {
                                    Spacer(Modifier.width(6.dp))
                                    MlTag(topic.role.uppercase(), c.brand)
                                }
                                Spacer(Modifier.weight(1f))
                                Text(
                                    topic.date,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = c.textGhost
                                )
                            }
                            Spacer(Modifier.height(10.dp))
                            MlTag(topic.category, c.brand.copy(alpha = 0.85f))
                            Spacer(Modifier.height(8.dp))
                            Text(
                                topic.title,
                                style = MaterialTheme.typography.titleMedium,
                                color = c.textMain
                            )
                            Spacer(Modifier.height(10.dp))
                            Row {
                                MetricIcon(Icons.Filled.ThumbUp, topic.likes.toString())
                                Spacer(Modifier.width(14.dp))
                                MetricIcon(MlIcons.ChatBubbleOutline, topic.comments.toString())
                                Spacer(Modifier.width(14.dp))
                                MetricIcon(MlIcons.Visibility, topic.views.toString())
                            }
                        }
                    }
                }
            }
        }

        Row(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(20.dp)
                .clip(RoundedCornerShape(50))
                .background(c.brand)
                .clickable { composing = true }
                .padding(horizontal = 18.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Filled.Add, null, tint = Color.White, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text("Создать тему", style = MaterialTheme.typography.labelLarge, color = Color.White)
        }
    }
}

@Composable
private fun NewTopicDialog(
    onDismiss: () -> Unit,
    onOpenAuth: () -> Unit,
    onCreate: (String, String) -> Unit
) {
    val c = ml
    val account = UserLibrary.account.value
    val categories = remember { DemoData.forumCategories.filter { it != "Все" } }
    var selected by remember { mutableStateOf(categories.firstOrNull().orEmpty()) }
    var title by remember { mutableStateOf("") }
    val valid = title.trim().length >= 6 && selected.isNotBlank()

    Dialog(onDismissRequest = onDismiss) {
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(c.block)
                .padding(20.dp)
        ) {
            Text("Новая тема", style = MaterialTheme.typography.titleLarge, color = c.textMain)
            Spacer(Modifier.height(4.dp))
            Text(
                if (account == null) {
                    "Тема появится в списке на этом устройстве. Войдите, чтобы публиковать под своим ником."
                } else {
                    "Публикуем от имени ${account.name}."
                },
                style = MaterialTheme.typography.bodySmall,
                color = c.textMuted
            )

            Spacer(Modifier.height(16.dp))
            Text("Раздел", style = MaterialTheme.typography.labelSmall, color = c.textMuted)
            Spacer(Modifier.height(8.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(categories, key = { it }) { item ->
                    MlChip(
                        text = item,
                        selected = item == selected,
                        onClick = { selected = item }
                    )
                }
            }

            Spacer(Modifier.height(16.dp))
            Text("Заголовок", style = MaterialTheme.typography.labelSmall, color = c.textMuted)
            Spacer(Modifier.height(8.dp))
            Box(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(c.bgMain)
                    .padding(horizontal = 12.dp, vertical = 13.dp)
            ) {
                if (title.isEmpty()) {
                    Text(
                        "О чём хотите поговорить?",
                        style = MaterialTheme.typography.bodyMedium,
                        color = c.textGhost
                    )
                }
                BasicTextField(
                    value = title,
                    onValueChange = { if (it.length <= 90) title = it },
                    singleLine = true,
                    textStyle = MaterialTheme.typography.bodyMedium.copy(color = c.textMain),
                    cursorBrush = SolidColor(c.brand),
                    modifier = Modifier.fillMaxWidth()
                )
            }
            Spacer(Modifier.height(6.dp))
            Text(
                if (title.trim().length < 6) "Минимум 6 символов" else "${title.length} / 90",
                style = MaterialTheme.typography.labelSmall,
                color = if (title.trim().length < 6) c.textGhost else c.textMuted
            )

            Spacer(Modifier.height(20.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(
                    Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(50))
                        .clickable(onClick = if (account == null) onOpenAuth else onDismiss)
                        .padding(vertical = 13.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        if (account == null) "Войти" else "Отмена",
                        style = MaterialTheme.typography.labelLarge,
                        color = c.textMuted
                    )
                }
                Box(
                    Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(50))
                        .background(if (valid) c.brand else c.chip)
                        .clickable(enabled = valid) { onCreate(selected, title) }
                        .padding(vertical = 13.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "Опубликовать",
                        style = MaterialTheme.typography.labelLarge,
                        color = if (valid) Color.White else c.textGhost
                    )
                }
            }
        }
    }
}
