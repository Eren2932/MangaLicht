package ru.mangalicht.app.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import ru.mangalicht.app.data.UserLibrary
import ru.mangalicht.app.ui.icons.MlIcons
import ru.mangalicht.app.ui.theme.ml

private val EMAIL_RE = Regex("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$")

private data class PasswordRule(val label: String, val ok: Boolean)

private fun passwordRules(value: String) = listOf(
    PasswordRule("не короче 8 символов", value.length >= 8),
    PasswordRule("заглавная и строчная буквы", value.any { it.isUpperCase() } && value.any { it.isLowerCase() }),
    PasswordRule("хотя бы одна цифра", value.any { it.isDigit() }),
    PasswordRule("спецсимвол (!@#\$%…)", value.any { !it.isLetterOrDigit() })
)

@Composable
fun AuthScreen(onBack: () -> Unit) {
    val c = ml
    val scope = rememberCoroutineScope()
    val keyboard = LocalSoftwareKeyboardController.current

    var register by rememberSaveable { mutableStateOf(false) }
    var login by rememberSaveable { mutableStateOf("") }
    var email by rememberSaveable { mutableStateOf("") }
    var password by rememberSaveable { mutableStateOf("") }
    var passwordVisible by rememberSaveable { mutableStateOf(false) }
    var touched by rememberSaveable { mutableStateOf(false) }
    var busy by rememberSaveable { mutableStateOf(false) }
    var recovery by rememberSaveable { mutableStateOf(false) }
    var recoverySent by rememberSaveable { mutableStateOf(false) }

    val rules = passwordRules(password)
    val strength = rules.count { it.ok }

    val emailError = when {
        !touched || email.isBlank() -> null
        !EMAIL_RE.matches(email.trim()) -> "Похоже, в адресе опечатка"
        else -> null
    }
    val loginError = when {
        !touched || !register || login.isBlank() -> null
        login.trim().length < 3 -> "Минимум 3 символа"
        else -> null
    }
    val passwordError = when {
        !touched || password.isBlank() -> null
        register && strength < 4 -> "Пароль не проходит требования"
        !register && password.length < 8 -> "Минимум 8 символов"
        else -> null
    }

    val formValid = EMAIL_RE.matches(email.trim()) &&
        (if (register) login.trim().length >= 3 && strength == 4 else password.length >= 8)

    fun submit() {
        touched = true
        if (!formValid || busy) return
        keyboard?.hide()
        busy = true
        scope.launch {
            // Здесь будет вызов API сайта. Пока подтверждаем вход локально,
            // чтобы состояние «гость / авторизован» было настоящим, а не декором.
            delay(500)
            val name = if (register) login.trim() else email.trim().substringBefore('@')
            UserLibrary.signIn(name = name, email = email)
            busy = false
            onBack()
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(c.bgMain)
    ) {
        // Фирменное свечение вместо плоского фона.
        Box(
            Modifier
                .fillMaxSize()
                .background(
                    Brush.radialGradient(
                        colors = listOf(c.brand.copy(alpha = 0.22f), Color.Transparent),
                        center = Offset(0.15f, 0f),
                        radius = 900f
                    )
                )
        )
        Box(
            Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(Color.Transparent, c.bgMain)
                    )
                )
        )

        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
        ) {
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Spacer(Modifier.weight(1f))
                Icon(
                    Icons.Filled.Close,
                    "Закрыть",
                    tint = c.textMuted,
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .clickable(onClick = onBack)
                        .padding(8.dp)
                        .size(22.dp)
                )
            }

            Spacer(Modifier.height(12.dp))
            Row {
                Text(
                    "Manga",
                    style = MaterialTheme.typography.displaySmall,
                    color = c.textMain
                )
                Text(
                    "Licht",
                    style = MaterialTheme.typography.displaySmall,
                    color = c.brand
                )
            }
            Spacer(Modifier.height(6.dp))
            Text(
                text = if (register) {
                    "Создайте аккаунт — закладки, прогресс и оценки будут жить с вами."
                } else {
                    "С возвращением. Продолжим с той главы, где остановились."
                },
                style = MaterialTheme.typography.bodyMedium,
                color = c.textMuted
            )

            Spacer(Modifier.height(22.dp))
            Segmented(
                register = register,
                onChange = {
                    register = it
                    touched = false
                    recovery = false
                }
            )

            Spacer(Modifier.height(20.dp))
            Column(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(c.block)
                    .border(1.dp, c.border, RoundedCornerShape(18.dp))
                    .padding(18.dp)
            ) {
                if (register) {
                    AuthField(
                        label = "Ник на сайте",
                        value = login,
                        placeholder = "MangaLichtFan",
                        leading = Icons.Filled.Person,
                        error = loginError,
                        keyboardType = KeyboardType.Text,
                        imeAction = ImeAction.Next,
                        onValueChange = { login = it }
                    )
                    Spacer(Modifier.height(14.dp))
                }

                AuthField(
                    label = "Email",
                    value = email,
                    placeholder = "you@mail.ru",
                    leading = Icons.Filled.Email,
                    error = emailError,
                    keyboardType = KeyboardType.Email,
                    imeAction = ImeAction.Next,
                    onValueChange = { email = it }
                )
                Spacer(Modifier.height(14.dp))

                AuthField(
                    label = "Пароль",
                    value = password,
                    placeholder = "••••••••",
                    leading = null,
                    error = passwordError,
                    keyboardType = KeyboardType.Password,
                    imeAction = ImeAction.Done,
                    visual = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                    onImeAction = { submit() },
                    trailing = {
                        Icon(
                            if (passwordVisible) MlIcons.VisibilityOff else MlIcons.Visibility,
                            contentDescription = if (passwordVisible) "Скрыть пароль" else "Показать пароль",
                            tint = c.textMuted,
                            modifier = Modifier
                                .clip(RoundedCornerShape(50))
                                .clickable { passwordVisible = !passwordVisible }
                                .padding(4.dp)
                                .size(19.dp)
                        )
                    },
                    onValueChange = { password = it }
                )

                AnimatedVisibility(visible = register) {
                    Column {
                        Spacer(Modifier.height(12.dp))
                        StrengthMeter(strength)
                        Spacer(Modifier.height(10.dp))
                        rules.forEach { rule ->
                            Row(
                                Modifier.padding(vertical = 2.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                val tint by animateColorAsState(
                                    if (rule.ok) c.positive else c.textGhost,
                                    tween(160),
                                    label = "ruleTint"
                                )
                                Icon(
                                    Icons.Filled.Check,
                                    null,
                                    tint = tint,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    rule.label,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = tint
                                )
                            }
                        }
                    }
                }

                if (!register) {
                    Spacer(Modifier.height(12.dp))
                    Text(
                        text = if (recovery) "Свернуть" else "Забыли пароль?",
                        style = MaterialTheme.typography.labelMedium,
                        color = c.brand,
                        textAlign = TextAlign.End,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                recovery = !recovery
                                recoverySent = false
                            }
                    )
                    AnimatedVisibility(visible = recovery) {
                        Column(
                            Modifier
                                .padding(top = 12.dp)
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(c.blockInner)
                                .padding(14.dp)
                        ) {
                            if (recoverySent) {
                                Text(
                                    "Запрос на восстановление подготовлен для ${email.trim()}. " +
                                        "Письмо уйдёт, как только приложение подключится к API сайта.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = c.textMuted
                                )
                            } else {
                                Text(
                                    "Укажите email выше и подтвердите — мы отправим ссылку для сброса пароля.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = c.textMuted
                                )
                                Spacer(Modifier.height(12.dp))
                                Box(
                                    Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(50))
                                        .border(1.dp, c.border, RoundedCornerShape(50))
                                        .clickable(enabled = EMAIL_RE.matches(email.trim())) {
                                            recoverySent = true
                                        }
                                        .padding(vertical = 11.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        "Отправить ссылку",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = if (EMAIL_RE.matches(email.trim())) c.textMain else c.textGhost
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(Modifier.height(20.dp))
                PrimaryButton(
                    text = if (register) "Создать аккаунт" else "Войти",
                    enabled = formValid,
                    busy = busy,
                    onClick = { submit() }
                )
                Spacer(Modifier.height(10.dp))
                Box(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(50))
                        .clickable(onClick = onBack)
                        .padding(vertical = 13.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "Продолжить как гость",
                        style = MaterialTheme.typography.labelLarge,
                        color = c.textMuted
                    )
                }
            }

            Spacer(Modifier.height(18.dp))
            Text(
                text = "Аккаунт подтверждается на этом устройстве. Синхронизация с сайтом " +
                    "включится вместе с серверным API.",
                style = MaterialTheme.typography.labelSmall,
                color = c.textGhost,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp)
            )
            Spacer(Modifier.height(28.dp))
        }
    }
}

@Composable
private fun Segmented(register: Boolean, onChange: (Boolean) -> Unit) {
    val c = ml
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(50))
            .background(c.blockInner)
            .border(1.dp, c.border, RoundedCornerShape(50))
            .padding(4.dp)
    ) {
        SegmentedItem("Вход", !register, Modifier.weight(1f)) { onChange(false) }
        SegmentedItem("Регистрация", register, Modifier.weight(1f)) { onChange(true) }
    }
}

@Composable
private fun SegmentedItem(
    text: String,
    selected: Boolean,
    modifier: Modifier,
    onClick: () -> Unit
) {
    val c = ml
    val bg by animateColorAsState(
        if (selected) c.brand else Color.Transparent,
        tween(160),
        label = "segBg"
    )
    val fg by animateColorAsState(
        if (selected) Color.White else c.textMuted,
        tween(160),
        label = "segFg"
    )
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(50))
            .background(bg)
            .clickable(onClick = onClick)
            .padding(vertical = 11.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text,
            style = MaterialTheme.typography.labelLarge,
            color = fg,
            maxLines = 1
        )
    }
}

@Composable
private fun StrengthMeter(strength: Int) {
    val c = ml
    val color = when (strength) {
        0, 1 -> c.negative
        2 -> c.yellow
        3 -> c.brand
        else -> c.positive
    }
    Column {
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            repeat(4) { index ->
                val filled = index < strength
                val fraction by animateFloatAsState(
                    if (filled) 1f else 0f,
                    tween(200),
                    label = "strength"
                )
                Box(
                    Modifier
                        .weight(1f)
                        .height(4.dp)
                        .clip(RoundedCornerShape(50))
                        .background(c.border)
                ) {
                    Box(
                        Modifier
                            .fillMaxWidth(fraction)
                            .height(4.dp)
                            .clip(RoundedCornerShape(50))
                            .background(color)
                    )
                }
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(
            text = when (strength) {
                0 -> "Придумайте пароль"
                1 -> "Слабый пароль"
                2 -> "Средний пароль"
                3 -> "Почти надёжный"
                else -> "Надёжный пароль"
            },
            style = MaterialTheme.typography.labelSmall,
            color = color
        )
    }
}

@Composable
private fun AuthField(
    label: String,
    value: String,
    placeholder: String,
    leading: ImageVector?,
    error: String?,
    keyboardType: KeyboardType,
    imeAction: ImeAction,
    visual: VisualTransformation = VisualTransformation.None,
    trailing: (@Composable () -> Unit)? = null,
    onImeAction: () -> Unit = {},
    onValueChange: (String) -> Unit
) {
    val c = ml
    val interaction = remember { MutableInteractionSource() }
    val focused by interaction.collectIsFocusedAsState()
    val borderColor by animateColorAsState(
        targetValue = when {
            error != null -> c.negative
            focused -> c.brand
            else -> c.border
        },
        animationSpec = tween(150),
        label = "fieldBorder"
    )

    Column {
        Text(
            label,
            style = MaterialTheme.typography.labelSmall,
            color = if (error != null) c.negative else c.textMuted,
            modifier = Modifier.padding(bottom = 6.dp)
        )
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(c.bgMain)
                .border(1.dp, borderColor, RoundedCornerShape(12.dp))
                .padding(horizontal = 12.dp, vertical = 13.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (leading != null) {
                Icon(leading, null, tint = c.textGhost, modifier = Modifier.size(17.dp))
                Spacer(Modifier.width(10.dp))
            }
            Box(Modifier.weight(1f)) {
                if (value.isEmpty()) {
                    Text(
                        placeholder,
                        style = MaterialTheme.typography.bodyMedium,
                        color = c.textGhost,
                        maxLines = 1
                    )
                }
                BasicTextField(
                    value = value,
                    onValueChange = onValueChange,
                    singleLine = true,
                    visualTransformation = visual,
                    interactionSource = interaction,
                    keyboardOptions = KeyboardOptions(keyboardType = keyboardType, imeAction = imeAction),
                    keyboardActions = KeyboardActions(onDone = { onImeAction() }, onGo = { onImeAction() }),
                    textStyle = MaterialTheme.typography.bodyMedium.copy(color = c.textMain),
                    cursorBrush = SolidColor(c.brand),
                    modifier = Modifier.fillMaxWidth()
                )
            }
            if (trailing != null) trailing()
        }
        if (error != null) {
            Spacer(Modifier.height(5.dp))
            Text(error, style = MaterialTheme.typography.labelSmall, color = c.negative)
        }
    }
}

@Composable
private fun PrimaryButton(
    text: String,
    enabled: Boolean,
    busy: Boolean,
    onClick: () -> Unit
) {
    val c = ml
    val bg by animateColorAsState(
        if (enabled) c.brand else c.chip,
        tween(180),
        label = "btnBg"
    )
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(50))
            .background(bg)
            .clickable(enabled = !busy, onClick = onClick)
            .padding(vertical = 15.dp),
        contentAlignment = Alignment.Center
    ) {
        if (busy) {
            CircularProgressIndicator(
                color = Color.White,
                strokeWidth = 2.dp,
                modifier = Modifier.size(18.dp)
            )
        } else {
            Text(
                text,
                style = MaterialTheme.typography.labelLarge,
                color = if (enabled) Color.White else c.textGhost,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}
