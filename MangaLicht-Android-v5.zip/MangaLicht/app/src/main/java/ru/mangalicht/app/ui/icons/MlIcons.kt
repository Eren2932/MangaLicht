package ru.mangalicht.app.ui.icons

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.PathBuilder
import androidx.compose.ui.graphics.vector.PathData
import androidx.compose.ui.unit.dp

/**
 * Собственный набор иконок MangaLicht.
 *
 * Существует ровно по одной причине: зависимость
 * `androidx.compose.material:material-icons-extended` весит около 30 МБ
 * векторных ресурсов и без R8 целиком попадает в debug-APK. Проекту из неё
 * нужны были 12 глифов, поэтому они нарисованы здесь вручную — в одном
 * геометрическом стиле, в сетке 24x24, как и Material-иконки.
 *
 * Остальные иконки берутся из `material-icons-core`, который и так приходит
 * транзитивно вместе с material3.
 */
object MlIcons {

    val Bookmark: ImageVector by lazy {
        icon("Bookmark") {
            moveTo(6f, 3f); horizontalLineTo(18f); verticalLineTo(21f)
            lineTo(12f, 18f); lineTo(6f, 21f); close()
        }
    }

    val BookmarkBorder: ImageVector by lazy {
        icon("BookmarkBorder", PathFillType.EvenOdd) {
            moveTo(6f, 3f); horizontalLineTo(18f); verticalLineTo(21f)
            lineTo(12f, 18f); lineTo(6f, 21f); close()
            moveTo(8f, 5f); verticalLineTo(17.8f); lineTo(12f, 15.8f)
            lineTo(16f, 17.8f); verticalLineTo(5f); close()
        }
    }

    val ChatBubbleOutline: ImageVector by lazy {
        icon("ChatBubbleOutline", PathFillType.EvenOdd) {
            moveTo(3f, 3f); horizontalLineTo(21f); verticalLineTo(17f)
            horizontalLineTo(8.5f); lineTo(3f, 21.5f); close()
            moveTo(5f, 5f); horizontalLineTo(19f); verticalLineTo(15f)
            horizontalLineTo(7.8f); lineTo(5f, 17.3f); close()
        }
    }

    val Forum: ImageVector by lazy {
        icon("Forum", PathFillType.EvenOdd) {
            moveTo(3f, 3f); horizontalLineTo(21f); verticalLineTo(16f)
            horizontalLineTo(9f); lineTo(4f, 20.5f); verticalLineTo(16f)
            horizontalLineTo(3f); close()
            moveTo(6.9f, 8.4f); horizontalLineTo(9.1f); verticalLineTo(10.6f)
            horizontalLineTo(6.9f); close()
            moveTo(10.9f, 8.4f); horizontalLineTo(13.1f); verticalLineTo(10.6f)
            horizontalLineTo(10.9f); close()
            moveTo(14.9f, 8.4f); horizontalLineTo(17.1f); verticalLineTo(10.6f)
            horizontalLineTo(14.9f); close()
        }
    }

    val Download: ImageVector by lazy {
        icon("Download") {
            moveTo(11f, 3f); horizontalLineTo(13f); verticalLineTo(12.2f)
            horizontalLineTo(16.6f); lineTo(12f, 17.4f); lineTo(7.4f, 12.2f)
            horizontalLineTo(11f); close()
            moveTo(4f, 19f); horizontalLineTo(20f); verticalLineTo(21f)
            horizontalLineTo(4f); close()
        }
    }

    val Explore: ImageVector by lazy {
        icon("Explore", PathFillType.EvenOdd) {
            moveTo(12f, 2f)
            arcTo(10f, 10f, 0f, true, true, 12f, 22f)
            arcTo(10f, 10f, 0f, true, true, 12f, 2f)
            close()
            moveTo(12f, 4f)
            arcTo(8f, 8f, 0f, true, false, 12f, 20f)
            arcTo(8f, 8f, 0f, true, false, 12f, 4f)
            close()
            moveTo(16.2f, 7.8f); lineTo(13.4f, 13.4f); lineTo(7.8f, 16.2f)
            lineTo(10.6f, 10.6f); close()
        }
    }

    val FilterList: ImageVector by lazy {
        icon("FilterList") {
            moveTo(3f, 5f); horizontalLineTo(21f); verticalLineTo(7.2f)
            horizontalLineTo(3f); close()
            moveTo(6f, 10.9f); horizontalLineTo(18f); verticalLineTo(13.1f)
            horizontalLineTo(6f); close()
            moveTo(9.6f, 16.8f); horizontalLineTo(14.4f); verticalLineTo(19f)
            horizontalLineTo(9.6f); close()
        }
    }

    val MenuBook: ImageVector by lazy {
        icon("MenuBook") {
            moveTo(2f, 5f); lineTo(11.1f, 7.2f); verticalLineTo(20.4f)
            lineTo(2f, 18.2f); close()
            moveTo(22f, 5f); lineTo(12.9f, 7.2f); verticalLineTo(20.4f)
            lineTo(22f, 18.2f); close()
        }
    }

    val PushPin: ImageVector by lazy {
        icon("PushPin") {
            moveTo(12f, 3f)
            arcTo(4.6f, 4.6f, 0f, true, true, 12f, 12.2f)
            arcTo(4.6f, 4.6f, 0f, true, true, 12f, 3f)
            close()
            moveTo(10.9f, 12.4f); horizontalLineTo(13.1f); verticalLineTo(21.5f)
            horizontalLineTo(10.9f); close()
        }
    }

    val SwapVert: ImageVector by lazy {
        icon("SwapVert") {
            moveTo(6.4f, 2.4f); lineTo(10.6f, 7.6f); horizontalLineTo(7.5f)
            verticalLineTo(16.4f); horizontalLineTo(5.3f); verticalLineTo(7.6f)
            horizontalLineTo(2.2f); close()
            moveTo(17.6f, 21.6f); lineTo(13.4f, 16.4f); horizontalLineTo(16.5f)
            verticalLineTo(7.6f); horizontalLineTo(18.7f); verticalLineTo(16.4f)
            horizontalLineTo(21.8f); close()
        }
    }

    val Visibility: ImageVector by lazy {
        icon("Visibility", PathFillType.EvenOdd) {
            moveTo(12f, 5f)
            curveTo(6.5f, 5f, 2.7f, 8.6f, 1f, 12f)
            curveTo(2.7f, 15.4f, 6.5f, 19f, 12f, 19f)
            curveTo(17.5f, 19f, 21.3f, 15.4f, 23f, 12f)
            curveTo(21.3f, 8.6f, 17.5f, 5f, 12f, 5f)
            close()
            moveTo(12f, 9f)
            arcTo(3f, 3f, 0f, true, true, 12f, 15f)
            arcTo(3f, 3f, 0f, true, true, 12f, 9f)
            close()
        }
    }

    val VisibilityOff: ImageVector by lazy {
        icon("VisibilityOff", PathFillType.EvenOdd) {
            moveTo(12f, 5f)
            curveTo(6.5f, 5f, 2.7f, 8.6f, 1f, 12f)
            curveTo(2.7f, 15.4f, 6.5f, 19f, 12f, 19f)
            curveTo(17.5f, 19f, 21.3f, 15.4f, 23f, 12f)
            curveTo(21.3f, 8.6f, 17.5f, 5f, 12f, 5f)
            close()
            moveTo(12f, 9f)
            arcTo(3f, 3f, 0f, true, true, 12f, 15f)
            arcTo(3f, 3f, 0f, true, true, 12f, 9f)
            close()
            moveTo(4.2f, 2.6f); lineTo(21.4f, 19.8f); lineTo(19.8f, 21.4f)
            lineTo(2.6f, 4.2f); close()
        }
    }
}

private fun icon(
    name: String,
    fillType: PathFillType = PathFillType.NonZero,
    block: PathBuilder.() -> Unit
): ImageVector = ImageVector.Builder(
    name = name,
    defaultWidth = 24.dp,
    defaultHeight = 24.dp,
    viewportWidth = 24f,
    viewportHeight = 24f
).apply {
    addPath(
        pathData = PathData(block),
        pathFillType = fillType,
        fill = SolidColor(Color.Black)
    )
}.build()
