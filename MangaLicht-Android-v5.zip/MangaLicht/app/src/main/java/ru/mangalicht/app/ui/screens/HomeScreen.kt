package ru.mangalicht.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import ru.mangalicht.app.data.MangaRepository
import ru.mangalicht.app.data.UserLibrary
import ru.mangalicht.app.ui.components.HorizontalTitleCarousel
import ru.mangalicht.app.ui.components.MlChip
import ru.mangalicht.app.ui.components.SectionHeader
import ru.mangalicht.app.ui.components.TitleRow
import ru.mangalicht.app.ui.theme.ml

@Composable
fun HomeScreen(
    onOpenTitle: (String) -> Unit,
    onOpenCatalog: () -> Unit,
    onOpenSearch: () -> Unit,
    onOpenReader: (String, String) -> Unit
) {
    val c = ml
    val popular = remember { MangaRepository.popular() }
    val fresh = remember { MangaRepository.fresh() }
    val updates = remember { MangaRepository.updates() }
    val genres = remember { ru.mangalicht.app.data.DemoData.genres.take(12) }
    val continueReading = remember(UserLibrary.progress.size) {
        UserLibrary.progress.keys.mapNotNull { id ->
            MangaRepository.byId(id)?.let { title ->
                val chapter = title.chapters.firstOrNull { it.id == UserLibrary.progress[id] }
                if (chapter == null) null else title to chapter
            }
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxWidth(),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        item(key = "topbar") { HomeTopBar(onOpenSearch = onOpenSearch, onOpenTitle = onOpenTitle) }

        item(key = "genres") {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item(key = "tg") { MlChip("Наш телеграм", selected = false, onClick = onOpenCatalog) }
                items(count = genres.size, key = { genres[it] }) { index ->
                    MlChip(genres[index]) { onOpenCatalog() }
                }
            }
        }

        item(key = "telegram") {
            Spacer(Modifier.height(8.dp))
            TelegramCard()
        }

        if (continueReading.isNotEmpty()) {
            item(key = "continue_header") {
                Spacer(Modifier.height(14.dp))
                SectionHeader("Продолжить чтение")
            }
            items(
                count = continueReading.size,
                key = { "continue_${continueReading[it].first.id}" }
            ) { index ->
                val (title, chapter) = continueReading[index]
                TitleRow(
                    title = title,
                    secondary = "Глава ${chapter.number} · ${chapter.pages} стр.",
                    trailing = "продолжить",
                    onClick = { onOpenReader(title.id, chapter.id) }
                )
            }
        }

        item(key = "popular_header") {
            Spacer(Modifier.height(14.dp))
            SectionHeader("Популярное", "Смотреть все", onOpenCatalog)
        }
        item(key = "popular") { HorizontalTitleCarousel(popular, onOpenTitle) }

        item(key = "fresh_header") {
            Spacer(Modifier.height(18.dp))
            SectionHeader("Новинки", "Весь каталог", onOpenCatalog)
        }
        item(key = "fresh") { HorizontalTitleCarousel(fresh, onOpenTitle) }

        item(key = "updates_header") {
            Spacer(Modifier.height(18.dp))
            SectionHeader("Обновления")
        }
        items(count = updates.size, key = { "upd_${updates[it].id}" }) { index ->
            val title = updates[index]
            val last = title.chapters.firstOrNull()
            TitleRow(
                title = title,
                secondary = if (last == null) title.subtitle
                else "Глава ${last.number} · ${last.pages} стр.",
                trailing = title.updatedAt,
                onClick = { onOpenTitle(title.id) }
            )
        }

        item(key = "footer") {
            Spacer(Modifier.height(20.dp))
            Text(
                "© 2026 Manga Licht. Сделано фанатами для фанатов",
                style = MaterialTheme.typography.labelSmall,
                color = c.textGhost,
                modifier = Modifier.padding(horizontal = 16.dp)
            )
        }
    }
}

@Composable
private fun HomeTopBar(onOpenSearch: () -> Unit, onOpenTitle: (String) -> Unit) {
    val c = ml
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            buildAnnotatedString {
                withStyle(SpanStyle(color = c.brand, fontWeight = FontWeight.Black)) { append("Manga") }
                withStyle(SpanStyle(color = c.textMain, fontWeight = FontWeight.Black)) { append("Licht") }
            },
            style = MaterialTheme.typography.headlineSmall,
            modifier = Modifier.weight(1f)
        )
        Icon(
            Icons.Filled.Search,
            contentDescription = "Поиск",
            tint = c.textMain,
            modifier = Modifier
                .size(26.dp)
                .clickable(onClick = onOpenSearch)
        )
        Spacer(Modifier.width(18.dp))
        NotificationsBell(onOpenTitle = onOpenTitle)
    }
}

/**
 * Колокольчик показывает реальные обновления из репозитория,
 * а не декоративную иконку.
 */
@Composable
private fun NotificationsBell(onOpenTitle: (String) -> Unit) {
    val c = ml
    var expanded by remember { mutableStateOf(false) }
    val updates = remember { MangaRepository.updates().take(6) }

    Box {
        Box {
            Icon(
                Icons.Filled.Notifications,
                contentDescription = "Уведомления",
                tint = c.textMain,
                modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .clickable { expanded = true }
                    .padding(3.dp)
                    .size(24.dp)
            )
            if (updates.isNotEmpty()) {
                Box(
                    Modifier
                        .align(Alignment.TopEnd)
                        .size(8.dp)
                        .clip(RoundedCornerShape(50))
                        .background(c.brand)
                )
            }
        }
        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false },
            modifier = Modifier.background(c.block)
        ) {
            if (updates.isEmpty()) {
                DropdownMenuItem(
                    text = {
                        Text(
                            "Пока ничего нового",
                            style = MaterialTheme.typography.bodySmall,
                            color = c.textMuted
                        )
                    },
                    onClick = { expanded = false }
                )
            } else {
                updates.forEach { title ->
                    DropdownMenuItem(
                        text = {
                            Column {
                                Text(
                                    title.title,
                                    style = MaterialTheme.typography.titleSmall,
                                    color = c.textMain,
                                    maxLines = 1
                                )
                                Text(
                                    "${title.chapters.size} глав · ${title.updatedAt}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = c.textMuted
                                )
                            }
                        },
                        onClick = {
                            expanded = false
                            onOpenTitle(title.id)
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun TelegramCard() {
    val c = ml
    val context = LocalContext.current
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(c.blockInner)
            .border(1.dp, c.positive.copy(alpha = 0.55f), RoundedCornerShape(12.dp))
            .padding(14.dp)
    ) {
        Text("Розыгрыш в Telegram", style = MaterialTheme.typography.titleSmall, color = c.textMain)
        Spacer(Modifier.height(6.dp))
        Text(
            "Подпишись на канал @mangalichtzero и нажми «Я в деле» в посте розыгрыша. " +
                "Все условия участия указаны в самом посте.",
            style = MaterialTheme.typography.bodySmall,
            color = c.textMuted
        )
        Spacer(Modifier.height(12.dp))
        Row(
            modifier = Modifier
                .clip(RoundedCornerShape(50))
                .background(c.brand)
                .clickable { openUrl(context, "https://t.me/mangalichtzero") }
                .padding(horizontal = 14.dp, vertical = 9.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Filled.Send, null, tint = androidx.compose.ui.graphics.Color.White, modifier = Modifier.size(15.dp))
            Spacer(Modifier.width(8.dp))
            Text(
                "Открыть Telegram",
                style = MaterialTheme.typography.labelMedium,
                color = androidx.compose.ui.graphics.Color.White
            )
        }
    }
}

/** Открывает внешнюю ссылку, не падая, если обработчика в системе нет. */
internal fun openUrl(context: android.content.Context, url: String) {
    runCatching {
        context.startActivity(
            android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(url))
        )
    }
}
