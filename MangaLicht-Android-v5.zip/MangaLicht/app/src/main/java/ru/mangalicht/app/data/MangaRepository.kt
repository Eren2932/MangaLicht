package ru.mangalicht.app.data

import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.snapshots.SnapshotStateList

/**
 * Единая точка доступа к данным. Сейчас отдаёт локальные демо-данные,
 * позже те же методы реализует сетевой источник (Retrofit + кэш).
 */
object MangaRepository {

    fun all(): List<MangaTitle> = DemoData.titles

    fun byId(id: String?): MangaTitle? = DemoData.titles.firstOrNull { it.id == id }

    fun popular(): List<MangaTitle> =
        DemoData.titles.filter { it.isPopular }.sortedByDescending { it.rating }

    fun fresh(): List<MangaTitle> = DemoData.titles.filter { it.isNew }

    fun updates(): List<MangaTitle> =
        DemoData.titles.filter { it.chapters.isNotEmpty() }.sortedBy { it.updatedAt.length }

    fun similarTo(title: MangaTitle): List<MangaTitle> =
        DemoData.titles
            .filter { it.id != title.id }
            .sortedByDescending { candidate -> candidate.genres.count { it in title.genres } }
            .take(6)

    fun blogOf(titleId: String): List<BlogPost> {
        val own = DemoData.blogPosts.filter { it.titleId == titleId }
        val result = if (own.isNotEmpty()) own else DemoData.blogPosts
        return result.sortedByDescending { it.pinned }
    }

    fun commentsOf(titleId: String): List<CommentItem> {
        val own = DemoData.comments.filter { it.titleId == titleId }
        return if (own.isNotEmpty()) own else DemoData.comments
    }

    fun reviewsOf(titleId: String): List<ReviewItem> {
        val own = DemoData.reviews.filter { it.titleId == titleId }
        return if (own.isNotEmpty()) own else DemoData.reviews
    }

    /**
     * Темы, созданные пользователем на устройстве. Живут в snapshot-списке,
     * поэтому форум обновляется сразу после отправки.
     */
    val userTopics: SnapshotStateList<ForumTopic> = mutableStateListOf()

    fun addTopic(category: String, title: String, author: String): ForumTopic {
        val topic = ForumTopic(
            id = "u${System.currentTimeMillis()}",
            author = author,
            role = null,
            date = "только что",
            category = category,
            title = title.trim(),
            likes = 0,
            comments = 0,
            views = 1
        )
        userTopics.add(0, topic)
        return topic
    }

    fun forumTopics(category: String, query: String): List<ForumTopic> =
        (userTopics + DemoData.forumTopics).filter { topic ->
            (category == "Все категории" || topic.category == category) &&
                (query.isBlank() || topic.title.contains(query, ignoreCase = true))
        }

    fun search(query: String): List<MangaTitle> {
        if (query.isBlank()) return emptyList()
        return DemoData.titles.filter {
            it.title.contains(query, true) ||
                it.originalTitle.contains(query, true) ||
                it.author.contains(query, true) ||
                it.genres.any { g -> g.contains(query, true) }
        }
    }

    fun catalog(
        query: String = "",
        sort: String = "Новые",
        genres: Set<String> = emptySet(),
        statuses: Set<TitleStatus> = emptySet(),
        types: Set<TitleType> = emptySet()
    ): List<MangaTitle> {
        val filtered = DemoData.titles.filter { title ->
            (query.isBlank() || title.title.contains(query, true) || title.originalTitle.contains(query, true)) &&
                (genres.isEmpty() || title.genres.any { it in genres }) &&
                (statuses.isEmpty() || title.status in statuses) &&
                (types.isEmpty() || title.type in types)
        }
        return when (sort) {
            "Больше просмотров" -> filtered.sortedByDescending { it.views }
            "Меньше просмотров" -> filtered.sortedBy { it.views }
            "Высокий рейтинг" -> filtered.sortedByDescending { it.rating }
            "Низкий рейтинг" -> filtered.sortedBy { it.rating }
            "По названию" -> filtered.sortedBy { it.title }
            else -> filtered.sortedByDescending { it.year * 100 + if (it.isNew) 50 else 0 }
        }
    }

    fun libraryOf(status: ReadingStatus): List<MangaTitle> =
        UserLibrary.titlesWithStatus(status).mapNotNull { byId(it) }

    fun favorites(): List<MangaTitle> = UserLibrary.favorites.keys.mapNotNull { byId(it) }

    fun history(): List<Pair<MangaTitle, HistoryEntry>> =
        DemoData.history.mapNotNull { entry -> byId(entry.titleId)?.let { it to entry } }

    fun ratedTitles(): List<Pair<MangaTitle, RatingEntry>> =
        DemoData.myRatings.mapNotNull { entry -> byId(entry.titleId)?.let { it to entry } }
}
