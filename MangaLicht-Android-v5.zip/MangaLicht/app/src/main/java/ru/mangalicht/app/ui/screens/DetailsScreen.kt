package ru.mangalicht.app.ui.screens

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import ru.mangalicht.app.ui.icons.MlIcons
import ru.mangalicht.app.data.Chapter
import ru.mangalicht.app.data.MangaRepository
import ru.mangalicht.app.data.MangaTitle
import ru.mangalicht.app.data.ReadingStatus
import ru.mangalicht.app.data.UserLibrary
import ru.mangalicht.app.ui.components.CarouselCard
import ru.mangalicht.app.ui.components.EmptyState
import ru.mangalicht.app.ui.components.MlFlowRow
import ru.mangalicht.app.ui.components.MlChip
import ru.mangalicht.app.ui.components.MlSearchField
import ru.mangalicht.app.ui.components.MlTabRow
import ru.mangalicht.app.ui.components.MlTag
import ru.mangalicht.app.ui.components.ProceduralCover
import ru.mangalicht.app.ui.components.RatingStars
import ru.mangalicht.app.ui.components.StatBar
import ru.mangalicht.app.ui.components.StatusPickerDialog
import ru.mangalicht.app.ui.components.formatCount
import ru.mangalicht.app.ui.components.formatRating
import ru.mangalicht.app.ui.components.statusColor
import ru.mangalicht.app.ui.theme.ml

private val detailTabs = listOf("Статистика", "Главы", "Блог", "Комментарии", "Рецензии")

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun DetailsScreen(
    titleId: String,
    onBack: () -> Unit,
    onOpenTitle: (String) -> Unit,
    onRead: (String) -> Unit
) {
    val c = ml
    val title = remember(titleId) { MangaRepository.byId(titleId) }
    if (title == null) {
        Column(Modifier.fillMaxWidth().padding(top = 40.dp)) {
            BackButton(onBack)
            EmptyState("Тайтл не найден")
        }
        return
    }

    var tab by rememberSaveable(titleId) { mutableStateOf(1) }
    var descriptionExpanded by rememberSaveable(titleId) { mutableStateOf(false) }
    var chaptersDescending by rememberSaveable(titleId) { mutableStateOf(true) }
    var statusDialog by remember { mutableStateOf(false) }

    val status = UserLibrary.statusOf(title.id)
    val progressChapterId = UserLibrary.progressOf(title.id)
    val chapters = remember(title.id, chaptersDescending) {
        if (chaptersDescending) title.chapters else title.chapters.reversed()
    }
    val badges = remember(title.id) {
        mapOf(1 to title.chaptersCount, 3 to MangaRepository.commentsOf(title.id).size)
    }

    LazyColumn(
        modifier = Modifier.fillMaxWidth(),
        contentPadding = PaddingValues(bottom = 28.dp)
    ) {
        item(key = "head") {
            TitleHeader(
                title = title,
                status = status,
                hasProgress = progressChapterId != null,
                onBack = onBack,
                onRead = {
                    val chapter = title.chapters.firstOrNull { it.id == progressChapterId }
                        ?: title.chapters.lastOrNull()
                    if (chapter != null) onRead(chapter.id)
                },
                onStatusClick = { statusDialog = true }
            )
        }

        item(key = "description") {
            Column(Modifier.padding(horizontal = 16.dp)) {
                Text("Описание", style = MaterialTheme.typography.titleMedium, color = c.textMain)
                Spacer(Modifier.height(6.dp))
                Text(
                    title.description,
                    style = MaterialTheme.typography.bodyMedium,
                    color = c.textMuted,
                    maxLines = if (descriptionExpanded) 40 else 3,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    if (descriptionExpanded) "Свернуть" else "Читать полностью",
                    style = MaterialTheme.typography.labelMedium,
                    color = c.brand,
                    modifier = Modifier
                        .padding(top = 6.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .clickable { descriptionExpanded = !descriptionExpanded }
                        .padding(vertical = 4.dp)
                )
                Spacer(Modifier.height(10.dp))
            }
        }

        // Табы под описанием — как на сайте, только липкие для удобства на телефоне.
        stickyHeader(key = "tabs") {
            Column(Modifier.background(c.bgMain)) {
                MlTabRow(tabs = detailTabs, selected = tab, badges = badges) { tab = it }
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(1.dp)
                        .background(c.border)
                )
            }
        }

        when (tab) {
            0 -> statsTab(title, onOpenTitle)
            1 -> chaptersTab(
                title = title,
                chapters = chapters,
                descending = chaptersDescending,
                status = status,
                onToggleSort = { chaptersDescending = !chaptersDescending },
                onStatusSelect = { UserLibrary.setStatus(title.id, it) },
                onOpenChapter = onRead
            )
            2 -> blogTab(title)
            3 -> commentsTab(title)
            else -> reviewsTab(title)
        }
    }

    if (statusDialog) {
        StatusPickerDialog(
            current = status,
            titleName = title.title,
            onDismiss = { statusDialog = false },
            onSelect = {
                UserLibrary.setStatus(title.id, it)
                statusDialog = false
            }
        )
    }
}

@Composable
private fun BackButton(onBack: () -> Unit) {
    val c = ml
    Box(
        modifier = Modifier
            .padding(12.dp)
            .size(40.dp)
            .clip(RoundedCornerShape(50))
            .background(c.blockInner)
            .clickable(onClick = onBack),
        contentAlignment = Alignment.Center
    ) {
        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Назад", tint = c.textMain, modifier = Modifier.size(20.dp))
    }
}

@Composable
private fun TitleHeader(
    title: MangaTitle,
    status: ReadingStatus?,
    hasProgress: Boolean,
    onBack: () -> Unit,
    onRead: () -> Unit,
    onStatusClick: () -> Unit
) {
    val context = LocalContext.current
    val c = ml
    Column {
        BackButton(onBack)
        Row(Modifier.padding(horizontal = 16.dp)) {
            ProceduralCover(
                seed = title.id,
                label = title.title,
                modifier = Modifier
                    .width(112.dp)
                    .height(158.dp)
            )
            Spacer(Modifier.width(14.dp))
            Column {
                Text(
                    title.title,
                    style = MaterialTheme.typography.headlineSmall,
                    color = c.textMain
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    title.originalTitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = c.textMuted
                )
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Star, null, tint = c.brand, modifier = Modifier.size(15.dp))
                    Spacer(Modifier.width(4.dp))
                    Text(
                        formatRating(title.rating),
                        style = MaterialTheme.typography.labelLarge,
                        color = c.textMain
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        "${title.type.label} · ${title.year}",
                        style = MaterialTheme.typography.labelMedium,
                        color = c.textMuted
                    )
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    "Автор: ${title.author}",
                    style = MaterialTheme.typography.labelSmall,
                    color = c.textMuted
                )
                Text(
                    "${formatCount(title.views)} просмотров",
                    style = MaterialTheme.typography.labelSmall,
                    color = c.textGhost
                )
            }
        }

        Spacer(Modifier.height(12.dp))
        MlFlowRow(
            modifier = Modifier.padding(horizontal = 16.dp),
            horizontalGap = 8.dp,
            verticalGap = 8.dp
        ) {
            MlTag(if (title.status == ru.mangalicht.app.data.TitleStatus.ONGOING) "Онгоинг" else title.status.label, c.brand)
            title.genres.forEach { MlTag(it) }
        }

        Spacer(Modifier.height(14.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(12.dp))
                    .background(c.brand)
                    .clickable(onClick = onRead)
                    .padding(vertical = 15.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(MlIcons.MenuBook, null, tint = Color.White, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text(
                    if (hasProgress) "Продолжить чтение" else "Начать читать",
                    style = MaterialTheme.typography.labelLarge,
                    color = Color.White
                )
            }
            IconSquare(
                icon = if (UserLibrary.isFavorite(title.id)) MlIcons.Bookmark else MlIcons.BookmarkBorder,
                tint = if (UserLibrary.isFavorite(title.id)) c.brand else c.textMain
            ) { UserLibrary.toggleFavorite(title.id) }
            IconSquare(icon = Icons.Filled.Share, tint = c.textMain) {
                shareTitle(context, title.title, title.id)
            }
        }

        Spacer(Modifier.height(10.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(c.blockInner)
                .border(1.dp, if (status != null) statusColor(status) else c.border, RoundedCornerShape(12.dp))
                .clickable(onClick = onStatusClick)
                .padding(horizontal = 14.dp, vertical = 13.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (status != null) {
                Box(
                    Modifier
                        .size(10.dp)
                        .clip(RoundedCornerShape(50))
                        .background(statusColor(status))
                )
                Spacer(Modifier.width(10.dp))
            }
            Text(
                status?.label ?: "Добавить в список",
                style = MaterialTheme.typography.labelLarge,
                color = if (status != null) c.textMain else c.textMuted,
                modifier = Modifier.weight(1f)
            )
            Text(
                "изменить",
                style = MaterialTheme.typography.labelSmall,
                color = c.textGhost
            )
        }
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
private fun IconSquare(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    tint: Color,
    onClick: () -> Unit
) {
    val c = ml
    Box(
        modifier = Modifier
            .size(50.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(c.blockInner)
            .border(1.dp, c.border, RoundedCornerShape(12.dp))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(20.dp))
    }
}

/** Системный «Поделиться» со ссылкой на тайтл. */
private fun shareTitle(context: android.content.Context, name: String, titleId: String) {
    val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(android.content.Intent.EXTRA_SUBJECT, name)
        putExtra(
            android.content.Intent.EXTRA_TEXT,
            "$name — читаю на MangaLicht\nhttps://mangalicht.ru/manga/$titleId"
        )
    }
    runCatching {
        context.startActivity(
            android.content.Intent.createChooser(intent, "Поделиться тайтлом")
        )
    }
}
