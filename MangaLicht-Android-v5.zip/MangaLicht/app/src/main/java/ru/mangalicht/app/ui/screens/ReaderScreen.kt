package ru.mangalicht.app.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.KeyboardArrowLeft
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import ru.mangalicht.app.data.MangaRepository
import ru.mangalicht.app.data.UserLibrary
import ru.mangalicht.app.ui.components.EmptyState
import ru.mangalicht.app.ui.components.MlChip
import ru.mangalicht.app.ui.components.ProceduralCover
import ru.mangalicht.app.ui.theme.ml

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ReaderScreen(
    titleId: String,
    chapterId: String,
    onBack: () -> Unit,
    onOpenChapter: (String, String) -> Unit
) {
    val c = ml
    val title = remember(titleId) { MangaRepository.byId(titleId) }
    val chapter = remember(titleId, chapterId) {
        title?.chapters?.firstOrNull { it.id == chapterId } ?: title?.chapters?.firstOrNull()
    }

    if (title == null || chapter == null) {
        Column(Modifier.fillMaxSize().background(c.bgMain)) {
            EmptyState("Глава недоступна")
        }
        return
    }

    // Читалка рисуется под системные панели, поэтому вставки разводим руками.
    val topInset = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val bottomInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()

    var uiVisible by remember { mutableStateOf(true) }
    var settingsVisible by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()
    val pagerState = rememberPagerState(pageCount = { chapter.pages })
    val mode = UserLibrary.readerMode.value
    val keepUi = UserLibrary.readerKeepUi.value

    // Индекс главы для перехода вперёд/назад (главы отсортированы от новых к старым).
    val chapterIndex = remember(title.id, chapter.id) {
        title.chapters.indexOfFirst { it.id == chapter.id }
    }
    val nextChapter = title.chapters.getOrNull(chapterIndex - 1)
    val prevChapter = title.chapters.getOrNull(chapterIndex + 1)

    val currentPage by remember(mode) {
        derivedStateOf {
            if (mode == 0) listState.firstVisibleItemIndex + 1 else pagerState.currentPage + 1
        }
    }

    LaunchedEffect(title.id, chapter.id) {
        UserLibrary.setProgress(title.id, chapter.id)
        UserLibrary.markRead(title.id, chapter.id, true)
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) { if (!keepUi) uiVisible = !uiVisible }
    ) {
        if (mode == 0) {
            LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(top = topInset + 56.dp, bottom = bottomInset + 84.dp)
            ) {
                items(count = chapter.pages, key = { "p_$it" }) { index ->
                    ReaderPage(
                        seed = "${title.id}_${chapter.id}_$index",
                        label = "Страница ${index + 1}"
                    )
                }
                item(key = "chapter_end") {
                    ChapterEnd(
                        hasNext = nextChapter != null,
                        onNext = { nextChapter?.let { onOpenChapter(title.id, it.id) } }
                    )
                }
            }
        } else {
            HorizontalPager(
                state = pagerState,
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(top = topInset, bottom = bottomInset)
            ) { index ->
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    ReaderPage(
                        seed = "${title.id}_${chapter.id}_$index",
                        label = "Страница ${index + 1}"
                    )
                }
            }
        }

        AnimatedVisibility(
            visible = uiVisible || keepUi,
            enter = slideInVertically { -it } + fadeIn(),
            exit = slideOutVertically { -it } + fadeOut(),
            modifier = Modifier.align(Alignment.TopCenter)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.Black.copy(alpha = 0.88f))
                    .padding(top = topInset)
                    .padding(horizontal = 12.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    Icons.AutoMirrored.Filled.ArrowBack,
                    "Назад",
                    tint = Color.White,
                    modifier = Modifier
                        .size(24.dp)
                        .clickable(onClick = onBack)
                )
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        title.title,
                        style = MaterialTheme.typography.labelLarge,
                        color = Color.White,
                        maxLines = 1
                    )
                    Text(
                        "Глава ${chapter.number} · ${chapter.pages} стр.",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White.copy(alpha = 0.65f)
                    )
                }
                Icon(
                    Icons.Filled.Settings,
                    "Настройки чтения",
                    tint = Color.White,
                    modifier = Modifier
                        .size(22.dp)
                        .clickable { settingsVisible = !settingsVisible }
                )
            }
        }

        AnimatedVisibility(
            visible = uiVisible || keepUi,
            enter = slideInVertically { it } + fadeIn(),
            exit = slideOutVertically { it } + fadeOut(),
            modifier = Modifier.align(Alignment.BottomCenter)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.Black.copy(alpha = 0.88f))
                    .padding(bottom = bottomInset)
                    .padding(horizontal = 12.dp, vertical = 10.dp)
            ) {
                if (settingsVisible) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        MlChip("Лента", selected = mode == 0) { UserLibrary.setReaderMode(0) }
                        MlChip("Постранично", selected = mode == 1) { UserLibrary.setReaderMode(1) }
                        MlChip("Панели всегда", selected = keepUi) {
                            UserLibrary.setReaderKeepUi(!keepUi)
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    NavArrow(
                        icon = Icons.Filled.KeyboardArrowLeft,
                        enabled = prevChapter != null
                    ) { prevChapter?.let { onOpenChapter(title.id, it.id) } }
                    Text(
                        "$currentPage / ${chapter.pages}",
                        style = MaterialTheme.typography.labelMedium,
                        color = Color.White,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.weight(1f)
                    )
                    NavArrow(
                        icon = Icons.Filled.KeyboardArrowRight,
                        enabled = nextChapter != null
                    ) { nextChapter?.let { onOpenChapter(title.id, it.id) } }
                }
                Spacer(Modifier.height(8.dp))
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(3.dp)
                        .clip(RoundedCornerShape(50))
                        .background(Color.White.copy(alpha = 0.18f))
                ) {
                    Box(
                        Modifier
                            .fillMaxWidth(currentPage.toFloat() / chapter.pages.coerceAtLeast(1))
                            .height(3.dp)
                            .clip(RoundedCornerShape(50))
                            .background(c.brand)
                    )
                }
            }
        }
    }
}

@Composable
private fun ReaderPage(seed: String, label: String) {
    ProceduralCover(
        seed = seed,
        label = label,
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(0.68f),
        corner = 0
    )
}

@Composable
private fun ChapterEnd(hasNext: Boolean, onNext: () -> Unit) {
    val c = ml
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            "Глава прочитана",
            style = MaterialTheme.typography.titleMedium,
            color = Color.White
        )
        Spacer(Modifier.height(12.dp))
        if (hasNext) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(c.brand)
                    .clickable(onClick = onNext)
                    .padding(horizontal = 22.dp, vertical = 14.dp)
            ) {
                Text(
                    "Следующая глава",
                    style = MaterialTheme.typography.labelLarge,
                    color = Color.White
                )
            }
        } else {
            Text(
                "Это последняя доступная глава",
                style = MaterialTheme.typography.bodySmall,
                color = Color.White.copy(alpha = 0.6f)
            )
        }
    }
}

@Composable
private fun NavArrow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    enabled: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .size(38.dp)
            .clip(RoundedCornerShape(50))
            .background(Color.White.copy(alpha = if (enabled) 0.12f else 0.05f))
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            icon,
            null,
            tint = Color.White.copy(alpha = if (enabled) 1f else 0.3f),
            modifier = Modifier.size(20.dp)
        )
    }
}
