package ru.mangalicht.app.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.listSaver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import ru.mangalicht.app.ui.icons.MlIcons
import ru.mangalicht.app.data.DemoData
import ru.mangalicht.app.data.MangaRepository
import ru.mangalicht.app.data.TitleStatus
import ru.mangalicht.app.data.TitleType
import ru.mangalicht.app.ui.components.EmptyState
import ru.mangalicht.app.ui.components.MlFlowRow
import ru.mangalicht.app.ui.components.MlChip
import ru.mangalicht.app.ui.components.MlSearchField
import ru.mangalicht.app.ui.components.TitleCard
import ru.mangalicht.app.ui.theme.ml

@Composable
fun CatalogScreen(onOpenTitle: (String) -> Unit) {
    val c = ml
    var query by rememberSaveable { mutableStateOf("") }
    var sort by rememberSaveable { mutableStateOf(DemoData.sorts.first()) }
    var filtersOpen by rememberSaveable { mutableStateOf(false) }
    var allGenres by rememberSaveable { mutableStateOf(false) }
    val genres = rememberSaveable(saver = stringSetSaver()) { mutableStateOf(setOf()) }
    val statuses = rememberSaveable(saver = stringSetSaver()) { mutableStateOf(setOf()) }
    val types = rememberSaveable(saver = stringSetSaver()) { mutableStateOf(setOf()) }

    val results by remember {
        derivedStateOf {
            MangaRepository.catalog(
                query = query,
                sort = sort,
                genres = genres.value,
                statuses = statuses.value.mapNotNull { name ->
                    TitleStatus.entries.firstOrNull { it.name == name }
                }.toSet(),
                types = types.value.mapNotNull { name ->
                    TitleType.entries.firstOrNull { it.name == name }
                }.toSet()
            )
        }
    }
    val activeFilters = genres.value.size + statuses.value.size + types.value.size

    LazyVerticalGrid(
        columns = GridCells.Fixed(3),
        contentPadding = PaddingValues(start = 12.dp, end = 12.dp, bottom = 24.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item(key = "header", span = { androidx.compose.foundation.lazy.grid.GridItemSpan(3) }) {
            Column {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 14.dp, bottom = 10.dp, start = 4.dp, end = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Каталог", style = MaterialTheme.typography.headlineSmall, color = c.textMain)
                    Spacer(Modifier.weight(1f))
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(50))
                            .background(if (activeFilters > 0) c.brand else c.chip)
                            .clickable { filtersOpen = !filtersOpen }
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            MlIcons.FilterList,
                            null,
                            tint = if (activeFilters > 0) androidx.compose.ui.graphics.Color.White else c.textMuted,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(Modifier.width(6.dp))
                        Text(
                            if (activeFilters > 0) "Фильтры · $activeFilters" else "Фильтры",
                            style = MaterialTheme.typography.labelMedium,
                            color = if (activeFilters > 0) androidx.compose.ui.graphics.Color.White else c.textMuted
                        )
                    }
                }
                MlSearchField(
                    value = query,
                    placeholder = "Что ищем сегодня?",
                    modifier = Modifier.padding(horizontal = 4.dp)
                ) { query = it }

                AnimatedVisibility(visible = filtersOpen) {
                    Column(Modifier.padding(top = 12.dp, start = 4.dp, end = 4.dp)) {
                        FilterGroup("Сортировка") {
                            DemoData.sorts.forEach { option ->
                                MlChip(option, selected = sort == option) { sort = option }
                            }
                        }
                        FilterGroup("Жанры") {
                            val list = if (allGenres) DemoData.genres else DemoData.genres.take(12)
                            list.forEach { genre ->
                                MlChip(genre, selected = genre in genres.value) {
                                    genres.value = genres.value.toggle(genre)
                                }
                            }
                            if (!allGenres) {
                                MlChip("Другие жанры +${DemoData.genres.size - 12}") { allGenres = true }
                            }
                        }
                        FilterGroup("Статус") {
                            TitleStatus.entries.forEach { status ->
                                MlChip(status.label, selected = status.name in statuses.value) {
                                    statuses.value = statuses.value.toggle(status.name)
                                }
                            }
                        }
                        FilterGroup("Тип") {
                            TitleType.entries.forEach { type ->
                                MlChip(type.label, selected = type.name in types.value) {
                                    types.value = types.value.toggle(type.name)
                                }
                            }
                        }
                        if (activeFilters > 0) {
                            Text(
                                "Сбросить фильтры",
                                style = MaterialTheme.typography.labelLarge,
                                color = c.brand,
                                modifier = Modifier
                                    .padding(top = 4.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable {
                                        genres.value = emptySet()
                                        statuses.value = emptySet()
                                        types.value = emptySet()
                                    }
                                    .padding(vertical = 8.dp)
                            )
                        }
                    }
                }

                Spacer(Modifier.height(8.dp))
                Text(
                    "Найдено: ${results.size}",
                    style = MaterialTheme.typography.labelSmall,
                    color = c.textGhost,
                    modifier = Modifier.padding(start = 4.dp, bottom = 6.dp)
                )
            }
        }

        if (results.isEmpty()) {
            item(key = "empty", span = { androidx.compose.foundation.lazy.grid.GridItemSpan(3) }) {
                EmptyState("Ничего не нашлось", "Измени запрос или сбрось фильтры")
            }
        } else {
            items(items = results, key = { it.id }) { title ->
                TitleCard(title) { onOpenTitle(title.id) }
            }
        }
    }
}

@Composable
private fun FilterGroup(title: String, content: @Composable () -> Unit) {
    val c = ml
    Column(Modifier.padding(bottom = 12.dp)) {
        Text(title, style = MaterialTheme.typography.titleSmall, color = c.textMain)
        Spacer(Modifier.height(8.dp))
        MlFlowRow(horizontalGap = 8.dp, verticalGap = 8.dp) { content() }
    }
}

/** Set<String> не сохраняется в Bundle напрямую, поэтому кладём его как список. */
private fun stringSetSaver(): Saver<MutableState<Set<String>>, Any> = listSaver(
    save = { state -> state.value.toList() },
    restore = { list -> mutableStateOf(list.filterIsInstance<String>().toSet()) }
)

private fun Set<String>.toggle(value: String): Set<String> =
    if (contains(value)) this - value else this + value
