package ru.mangalicht.app.ui

import androidx.compose.animation.AnimatedContentTransitionScope
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import ru.mangalicht.app.ui.icons.MlIcons
import ru.mangalicht.app.ui.screens.AuthScreen
import ru.mangalicht.app.ui.screens.BookmarksScreen
import ru.mangalicht.app.ui.screens.CatalogScreen
import ru.mangalicht.app.ui.screens.DetailsScreen
import ru.mangalicht.app.ui.screens.ForumScreen
import ru.mangalicht.app.ui.screens.HomeScreen
import ru.mangalicht.app.ui.screens.ProfileScreen
import ru.mangalicht.app.ui.screens.ReaderScreen
import ru.mangalicht.app.ui.screens.SearchScreen
import ru.mangalicht.app.ui.screens.SettingsScreen
import ru.mangalicht.app.ui.theme.ml

object Routes {
    const val HOME = "home"
    const val CATALOG = "catalog"
    const val FORUM = "forum"
    const val BOOKMARKS = "bookmarks"
    const val PROFILE = "profile"
    const val SEARCH = "search"
    const val SETTINGS = "settings"
    const val AUTH = "auth"
    const val DETAILS = "details/{titleId}"
    const val READER = "reader/{titleId}/{chapterId}"

    fun details(titleId: String) = "details/$titleId"
    fun reader(titleId: String, chapterId: String) = "reader/$titleId/$chapterId"
}

private data class TabItem(val route: String, val label: String, val icon: ImageVector)

private val tabs = listOf(
    TabItem(Routes.HOME, "Главная", Icons.Filled.Home),
    TabItem(Routes.CATALOG, "Каталог", MlIcons.Explore),
    TabItem(Routes.FORUM, "Форум", MlIcons.Forum),
    TabItem(Routes.BOOKMARKS, "Закладки", MlIcons.Bookmark),
    TabItem(Routes.PROFILE, "Профиль", Icons.Filled.Person)
)

/** Экраны без нижней панели. */
private val fullScreenRoutes = setOf(
    Routes.DETAILS, Routes.READER, Routes.AUTH, Routes.SEARCH, Routes.SETTINGS
)

@Composable
fun MangaLichtApp() {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route
    val showBottomBar = currentRoute == null || currentRoute !in fullScreenRoutes

    // Читалка — единственный экран, который рисуется под системные панели:
    // свои шапку и футер она разводит по вставкам сама.
    val immersive = currentRoute == Routes.READER

    val c = ml

    // Вставки читаем напрямую, а не через innerPadding Scaffold: так значение
    // не зависит от того, потребил ли их кто-то выше по дереву.
    val topInset = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val bottomInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()

    Scaffold(
        containerColor = c.bgMain,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        bottomBar = {
            if (showBottomBar) {
                MlBottomBar(
                    currentRoute = currentRoute,
                    bottomInset = bottomInset,
                    onSelect = { route -> navController.switchTab(route, currentRoute) }
                )
            }
        }
    ) { innerPadding ->
        val contentBottom = when {
            immersive -> 0.dp
            showBottomBar -> innerPadding.calculateBottomPadding()
            else -> bottomInset
        }
        Box(
            Modifier
                .fillMaxSize()
                .background(c.bgMain)
                .padding(
                    top = if (immersive) 0.dp else topInset,
                    bottom = contentBottom
                )
                .then(if (immersive) Modifier else Modifier.imePadding())
        ) {
            AppNavHost(navController)
        }
    }
}

/**
 * Переключение вкладок.
 *
 * «Главная» — корень графа, поэтому для неё достаточно смотать стек назад:
 * это надёжнее, чем navigate + launchSingleTop, где popUpTo и restoreState
 * могут погасить переход и вкладка визуально «не нажимается».
 */
private fun NavHostController.switchTab(route: String, currentRoute: String?) {
    if (route == currentRoute) return
    if (route == Routes.HOME) {
        if (!popBackStack(Routes.HOME, inclusive = false)) {
            navigate(Routes.HOME) { popUpTo(Routes.HOME) { inclusive = true } }
        }
        return
    }
    navigate(route) {
        popUpTo(Routes.HOME) { saveState = true }
        launchSingleTop = true
        restoreState = true
    }
}

@Composable
private fun MlBottomBar(
    currentRoute: String?,
    bottomInset: Dp,
    onSelect: (String) -> Unit
) {
    val c = ml
    Column(Modifier.fillMaxWidth().background(c.block)) {
        Box(Modifier.fillMaxWidth().height(1.dp).background(c.border))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(58.dp)
                .padding(horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            tabs.forEach { tab ->
                BottomTab(
                    tab = tab,
                    selected = currentRoute == tab.route,
                    modifier = Modifier.weight(1f),
                    onClick = { onSelect(tab.route) }
                )
            }
        }
        // Жестовая панель Android: без этого отступа нижний ряд вкладок
        // попадает в системную зону и часть нажатий до нас не доходит.
        Spacer(Modifier.fillMaxWidth().height(bottomInset))
    }
}

@Composable
private fun BottomTab(
    tab: TabItem,
    selected: Boolean,
    modifier: Modifier,
    onClick: () -> Unit
) {
    val c = ml
    val tint by animateColorAsState(
        targetValue = if (selected) c.brand else c.textMuted,
        animationSpec = tween(120),
        label = "tabTint"
    )
    val pill by animateFloatAsState(
        targetValue = if (selected) 1f else 0f,
        animationSpec = tween(140),
        label = "tabPill"
    )
    Column(
        modifier = modifier
            .fillMaxHeight()
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier.width(38.dp).height(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Box(
                Modifier
                    .fillMaxSize()
                    .clip(RoundedCornerShape(50))
                    .background(c.brand.copy(alpha = 0.16f * pill))
            )
            Icon(tab.icon, contentDescription = tab.label, tint = tint, modifier = Modifier.size(20.dp))
        }
        Spacer(Modifier.height(3.dp))
        Text(
            text = tab.label,
            style = MaterialTheme.typography.labelSmall,
            color = tint,
            maxLines = 1,
            softWrap = false,
            overflow = TextOverflow.Ellipsis
        )
    }
}

private const val FAST = 90
private const val PUSH = 150

@Composable
private fun AppNavHost(navController: NavHostController) {
    NavHost(
        navController = navController,
        startDestination = Routes.HOME,
        enterTransition = { fadeIn(tween(FAST)) },
        exitTransition = { fadeOut(tween(FAST)) },
        popEnterTransition = { fadeIn(tween(FAST)) },
        popExitTransition = { fadeOut(tween(FAST)) }
    ) {
        composable(Routes.HOME) {
            HomeScreen(
                onOpenTitle = { navController.navigate(Routes.details(it)) },
                onOpenCatalog = { navController.switchTab(Routes.CATALOG, Routes.HOME) },
                onOpenSearch = { navController.navigate(Routes.SEARCH) },
                onOpenReader = { titleId, chapterId ->
                    navController.navigate(Routes.reader(titleId, chapterId))
                }
            )
        }
        composable(Routes.CATALOG) {
            CatalogScreen(onOpenTitle = { navController.navigate(Routes.details(it)) })
        }
        composable(Routes.FORUM) { ForumScreen(onOpenAuth = { navController.navigate(Routes.AUTH) }) }
        composable(Routes.BOOKMARKS) {
            BookmarksScreen(
                onOpenTitle = { navController.navigate(Routes.details(it)) },
                onOpenCatalog = { navController.switchTab(Routes.CATALOG, Routes.BOOKMARKS) }
            )
        }
        composable(Routes.PROFILE) {
            ProfileScreen(
                onOpenTitle = { navController.navigate(Routes.details(it)) },
                onOpenSettings = { navController.navigate(Routes.SETTINGS) },
                onOpenAuth = { navController.navigate(Routes.AUTH) }
            )
        }
        composable(Routes.SEARCH) {
            SearchScreen(
                onBack = { navController.popBackStack() },
                onOpenTitle = { navController.navigate(Routes.details(it)) }
            )
        }
        composable(Routes.SETTINGS) {
            SettingsScreen(onBack = { navController.popBackStack() })
        }
        composable(Routes.AUTH) {
            AuthScreen(onBack = { navController.popBackStack() })
        }
        composable(
            route = Routes.DETAILS,
            enterTransition = {
                slideIntoContainer(
                    AnimatedContentTransitionScope.SlideDirection.Left,
                    tween(PUSH)
                ) + fadeIn(tween(PUSH))
            },
            exitTransition = { fadeOut(tween(FAST)) },
            popExitTransition = {
                slideOutOfContainer(
                    AnimatedContentTransitionScope.SlideDirection.Right,
                    tween(PUSH)
                ) + fadeOut(tween(PUSH))
            }
        ) { entry ->
            val titleId = entry.arguments?.getString("titleId").orEmpty()
            DetailsScreen(
                titleId = titleId,
                onBack = { navController.popBackStack() },
                onOpenTitle = { navController.navigate(Routes.details(it)) },
                onRead = { chapterId -> navController.navigate(Routes.reader(titleId, chapterId)) }
            )
        }
        composable(
            route = Routes.READER,
            enterTransition = { fadeIn(tween(FAST)) },
            popExitTransition = { fadeOut(tween(FAST)) }
        ) { entry ->
            ReaderScreen(
                titleId = entry.arguments?.getString("titleId").orEmpty(),
                chapterId = entry.arguments?.getString("chapterId").orEmpty(),
                onBack = { navController.popBackStack() },
                onOpenChapter = { titleId, chapterId ->
                    navController.navigate(Routes.reader(titleId, chapterId)) {
                        popUpTo(Routes.READER) { inclusive = true }
                    }
                }
            )
        }
    }
}
