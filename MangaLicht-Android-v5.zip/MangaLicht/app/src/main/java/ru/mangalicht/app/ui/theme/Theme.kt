package ru.mangalicht.app.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.PlatformTextStyle
import androidx.compose.ui.unit.Density
import androidx.core.view.WindowCompat

/** Токены сайта, которых нет в Material-схеме. */
data class MlColors(
    val bgMain: Color,
    val block: Color,
    val blockInner: Color,
    val border: Color,
    val brand: Color,
    val accent: Color,
    val yellow: Color,
    val positive: Color,
    val negative: Color,
    val textMain: Color,
    val textMuted: Color,
    val textGhost: Color,
    val chip: Color,
    val chipSelected: Color,
    val overlay: Color,
    val isDark: Boolean
)

private val DarkMl = MlColors(
    bgMain = Palette.black,
    block = Color(0xFF121215),
    blockInner = Palette.grey800,
    border = Color(0xFF232327),
    brand = Palette.alertDark,
    accent = Palette.accentDark,
    yellow = Palette.yellowDark,
    positive = Palette.greenDark,
    negative = Palette.negativeDark,
    textMain = Palette.white,
    textMuted = Palette.grey100,
    textGhost = Color(0x4DE4E5E7),
    chip = Palette.grey800,
    chipSelected = Palette.alertDark,
    overlay = Color(0xCC000000),
    isDark = true
)

private val LightMl = MlColors(
    bgMain = Palette.white,
    block = Palette.grey50,
    blockInner = Palette.white,
    border = Color(0xFFD8DADE),
    brand = Palette.alertLight,
    accent = Palette.accentLight,
    yellow = Palette.yellowLight,
    positive = Palette.greenLight,
    negative = Palette.negativeLight,
    textMain = Palette.black,
    textMuted = Palette.grey500,
    textGhost = Color(0x4D000000),
    chip = Color(0xFFEDEEF0),
    chipSelected = Palette.alertLight,
    overlay = Color(0x99000000),
    isDark = false
)

val LocalMlColors = staticCompositionLocalOf { DarkMl }

private val darkScheme = darkColorScheme(
    primary = Palette.alertDark,
    onPrimary = Palette.white,
    secondary = Palette.accentDark,
    onSecondary = Palette.white,
    tertiary = Palette.yellowDark,
    background = Palette.black,
    onBackground = Palette.white,
    surface = Palette.black,
    onSurface = Palette.white,
    surfaceVariant = Palette.grey800,
    onSurfaceVariant = Palette.grey100,
    outline = Color(0xFF232327),
    error = Palette.alertDark
)

private val lightScheme = lightColorScheme(
    primary = Palette.alertLight,
    onPrimary = Palette.white,
    secondary = Palette.accentLight,
    onSecondary = Palette.white,
    tertiary = Palette.yellowLight,
    background = Palette.white,
    onBackground = Palette.black,
    surface = Palette.white,
    onSurface = Palette.black,
    surfaceVariant = Palette.grey50,
    onSurfaceVariant = Palette.grey500,
    outline = Color(0xFFD8DADE),
    error = Palette.alertLight
)

/** Радиусы мобильной сетки сайта: 12dp. */
private val MlShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(12.dp),
    large = RoundedCornerShape(16.dp),
    extraLarge = RoundedCornerShape(22.dp)
)

/**
 * Отключаем includeFontPadding: иначе текст в чипах, бейджах и таб-баре
 * съезжает по вертикали, и тем сильнее, чем крупнее системный шрифт.
 */
private val MlPlatform = PlatformTextStyle(includeFontPadding = false)

private fun mlText(size: Int, line: Int, weight: FontWeight = FontWeight.Normal) = TextStyle(
    fontSize = size.sp,
    lineHeight = line.sp,
    fontWeight = weight,
    platformStyle = MlPlatform
)

private val MlTypography = Typography(
    displaySmall = mlText(30, 36, FontWeight.Black),
    headlineMedium = mlText(26, 32, FontWeight.Bold),
    headlineSmall = mlText(22, 28, FontWeight.Bold),
    titleLarge = mlText(19, 25, FontWeight.Bold),
    titleMedium = mlText(16, 21, FontWeight.SemiBold),
    titleSmall = mlText(14, 19, FontWeight.SemiBold),
    bodyLarge = mlText(15, 22),
    bodyMedium = mlText(14, 20),
    bodySmall = mlText(13, 18),
    labelLarge = mlText(14, 18, FontWeight.SemiBold),
    labelMedium = mlText(12, 16, FontWeight.Medium),
    labelSmall = mlText(11, 14, FontWeight.Medium)
)

/**
 * Границы масштаба шрифта, которые выдерживает вёрстка.
 *
 * Android разрешает системный масштаб до 2.0 — при нём таб-бар, чипы и
 * карточки каталога рассыпаются. Мы уважаем настройку пользователя, но
 * ограничиваем её коридором: интерфейс укрупняется, ничего не ломая.
 */
private const val MIN_FONT_SCALE = 0.85f
private const val MAX_FONT_SCALE = 1.30f

@Composable
fun MangaLichtTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val mlColors = if (darkTheme) DarkMl else LightMl

    // Зажимаем масштаб шрифта в безопасный коридор для всего дерева сразу.
    val systemDensity = LocalDensity.current
    val density = remember(systemDensity.density, systemDensity.fontScale) {
        Density(
            density = systemDensity.density,
            fontScale = systemDensity.fontScale.coerceIn(MIN_FONT_SCALE, MAX_FONT_SCALE)
        )
    }

    // Контрастные иконки системных панелей: приложение рисуется edge-to-edge.
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window ?: return@SideEffect
            WindowCompat.getInsetsController(window, view).apply {
                isAppearanceLightStatusBars = !darkTheme
                isAppearanceLightNavigationBars = !darkTheme
            }
        }
    }

    CompositionLocalProvider(
        LocalMlColors provides mlColors,
        LocalDensity provides density
    ) {
        MaterialTheme(
            colorScheme = if (darkTheme) darkScheme else lightScheme,
            shapes = MlShapes,
            typography = MlTypography,
            content = content
        )
    }
}

/** Короткий доступ: `ml.brand`, `ml.block` и т.д. */
val ml: MlColors
    @Composable get() = LocalMlColors.current
