package ru.mangalicht.app.ui.theme

import androidx.compose.ui.graphics.Color

/** Палитра один-в-один из theme-vars.scss сайта MangaLicht. */
object Palette {
    val white = Color(0xFFFFFFFF)
    val grey50 = Color(0xFFE4E5E7)
    val grey100 = Color(0xFFC9CBCF)
    val grey200 = Color(0xFFAEB1B7)
    val grey250 = Color(0xFFA4A6AD)
    val grey300 = Color(0xFF93969F)
    val grey400 = Color(0xFF787C87)
    val grey500 = Color(0xFF60636C)
    val grey600 = Color(0xFF484A51)
    val grey700 = Color(0xFF303136)
    val grey800 = Color(0xFF18181B)
    val grey850 = Color(0xFF101013)
    val black = Color(0xFF000000)

    val accentLight = Color(0xFF168FFF)
    val accentDark = Color(0xFF0085FF)
    val alertLight = Color(0xFFC41E3A)
    val alertDark = Color(0xFFE4334A)
    val yellowLight = Color(0xFFF0B32D)
    val yellowDark = Color(0xFFF7C870)
    val greenLight = Color(0xFF7ADC92)
    val greenDark = Color(0xFF40DD8F)

    // Цвет ошибок. Намеренно уводим в оранжево-красный, чтобы он не сливался
    // с фирменным alert-красным, которым покрашены основные действия.
    val negativeLight = Color(0xFFD64535)
    val negativeDark = Color(0xFFFF7A6B)
}
