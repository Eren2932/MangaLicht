package ru.mangalicht.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.KeyboardArrowRight
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import ru.mangalicht.app.data.ReadingStatus
import ru.mangalicht.app.data.ServiceLocator
import ru.mangalicht.app.ui.components.CoverArt
import ru.mangalicht.app.ui.components.Pill

@Composable
fun BookmarksScreen(padding: PaddingValues, openTitle: (Int) -> Unit) {
    val repository = ServiceLocator.repository
    var statusName by rememberSaveable { mutableStateOf(ReadingStatus.READING.name) }
    val status = ReadingStatus.entries.first { it.name == statusName }
    val counters = repository.profile().counters
    val all = repository.titles()

    val items = remember(statusName) {
        when (status) {
            ReadingStatus.READING -> all.take(4)
            ReadingStatus.PLANNED -> all.drop(4).take(5)
            ReadingStatus.COMPLETED -> all.filter { it.releaseStatus == "Завершён" }
            ReadingStatus.ON_HOLD -> all.drop(9).take(2)
            ReadingStatus.DROPPED -> all.takeLast(1)
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(
            start = 16.dp,
            end = 16.dp,
            bottom = padding.calculateBottomPadding() + 26.dp
        ),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item(key = "header") {
            Column(Modifier.statusBarsPadding().padding(top = 10.dp)) {
                Text("Закладки", style = MaterialTheme.typography.headlineMedium)
                Spacer(Modifier.height(4.dp))
                Text(
                    "Твои списки чтения",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(14.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(ReadingStatus.entries.toList()) { value ->
                        Pill(
                            text = value.label + " " + (counters[value] ?: 0),
                            selected = statusName == value.name
                        ) { statusName = value.name }
                    }
                }
            }
        }

        if (items.isEmpty()) {
            item(key = "empty") {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 70.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("Список пуст", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Добавляй тайтлы из каталога",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            items(items, key = { it.id }) { item ->
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surfaceContainer,
                    modifier = Modifier.fillMaxWidth().clickable { openTitle(item.id) }
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        CoverArt(item.title, item.paletteSeed, Modifier.size(56.dp, 76.dp), letterSize = 28)
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                item.title,
                                style = MaterialTheme.typography.titleMedium,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                            Spacer(Modifier.height(5.dp))
                            Text(
                                item.kind.label + " · " + item.releaseStatus,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(Modifier.height(8.dp))
                            LinearProgressIndicator(
                                progress = { 0.2f + item.id % 6 * 0.13f },
                                modifier = Modifier.fillMaxWidth().height(4.dp),
                                color = MaterialTheme.colorScheme.secondary,
                                trackColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)
                            )
                        }
                        Icon(
                            Icons.AutoMirrored.Outlined.KeyboardArrowRight,
                            null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}
