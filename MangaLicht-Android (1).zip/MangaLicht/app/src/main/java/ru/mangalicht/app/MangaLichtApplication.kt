package ru.mangalicht.app

import android.app.Application

class MangaLichtApplication : Application()
