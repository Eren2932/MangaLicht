package ru.mangalicht.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val gradients = listOf(
    listOf(Color(0xFF1F2A46), Color(0xFF0B0D14)),
    listOf(Color(0xFF3A2140), Color(0xFF120A16)),
    listOf(Color(0xFF10333A), Color(0xFF07161A)),
    listOf(Color(0xFF3A2320), Color(0xFF150B09)),
    listOf(Color(0xFF23324A), Color(0xFF0A1018)),
    listOf(Color(0xFF2C2F3A), Color(0xFF101116)),
    listOf(Color(0xFF14364A), Color(0xFF07131B)),
    listOf(Color(0xFF3D2C1A), Color(0xFF16100A)),
    listOf(Color(0xFF1C3A2E), Color(0xFF091612)),
    listOf(Color(0xFF32223F), Color(0xFF130C18)),
    listOf(Color(0xFF412A2A), Color(0xFF170E0E)),
    listOf(Color(0xFF1E2F3F), Color(0xFF0A1017))
)

fun gradientFor(seed: Int): List<Color> = gradients[seed.mod(gradients.size)]

/**
 * Обложка-заглушка с фирменным градиентом.
 * При подключении API заменяется на загрузку изображения без изменения разметки.
 */
@Composable
fun CoverArt(
    title: String,
    seed: Int,
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(14.dp),
    letterSize: Int = 64
) {
    Box(
        modifier = modifier.clip(shape).background(Brush.linearGradient(gradientFor(seed))),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = title.take(1).uppercase(),
            color = Color.White.copy(alpha = 0.16f),
            fontSize = letterSize.sp,
            fontWeight = FontWeight.Black
        )
    }
}
