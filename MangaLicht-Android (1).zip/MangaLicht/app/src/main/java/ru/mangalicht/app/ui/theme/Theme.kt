package ru.mangalicht.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val DarkColors = darkColorScheme(
    primary = AccentDark,
    onPrimary = White,
    primaryContainer = Grey700,
    onPrimaryContainer = White,
    secondary = AlertDark,
    onSecondary = White,
    tertiary = GreenDark,
    background = BlackPure,
    onBackground = White,
    surface = Grey850,
    onSurface = White,
    surfaceVariant = Grey700,
    onSurfaceVariant = Grey100,
    surfaceContainer = Grey800,
    surfaceContainerHigh = Grey700,
    outline = Grey600,
    outlineVariant = Grey700,
    error = AlertDark,
    onError = White
)

private val LightColors = lightColorScheme(
    primary = AccentLight,
    onPrimary = White,
    primaryContainer = Grey50,
    onPrimaryContainer = Grey850,
    secondary = AlertLight,
    onSecondary = White,
    tertiary = GreenLight,
    background = White,
    onBackground = BlackPure,
    surface = White,
    onSurface = BlackPure,
    surfaceVariant = Grey50,
    onSurfaceVariant = Grey500,
    surfaceContainer = Grey50,
    surfaceContainerHigh = Grey50,
    outline = Grey200,
    outlineVariant = Grey50,
    error = AlertLight,
    onError = White
)

private val AppShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(20.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun MangaLichtTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = AppTypography,
        shapes = AppShapes,
        content = content
    )
}
