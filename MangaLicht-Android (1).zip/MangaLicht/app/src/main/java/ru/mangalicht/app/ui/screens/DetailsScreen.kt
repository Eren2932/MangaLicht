package ru.mangalicht.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import ru.mangalicht.app.data.ServiceLocator
import ru.mangalicht.app.ui.components.CoverArt
import ru.mangalicht.app.ui.components.Pill
import ru.mangalicht.app.ui.components.formatRating
import ru.mangalicht.app.ui.components.gradientFor

@Composable
fun DetailsScreen(titleId: Int, onBack: () -> Unit, openReader: (Int, Int) -> Unit) {
    val repository = ServiceLocator.repository
    val item = repository.titleById(titleId) ?: repository.titles().first()
    val chapters = repository.chapters(item.id)
    var expanded by rememberSaveable { mutableStateOf(false) }

    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 40.dp)
        ) {
            item(key = "cover") {
                Box(Modifier.fillMaxWidth().height(390.dp)) {
                    Box(
                        Modifier
                            .fillMaxSize()
                            .background(Brush.verticalGradient(gradientFor(item.paletteSeed)))
                    )
                    Box(
                        Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    listOf(Color.Transparent, MaterialTheme.colorScheme.background)
                                )
                            )
                    )
                    Row(
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(horizontal = 18.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.Bottom
                    ) {
                        CoverArt(item.title, item.paletteSeed, Modifier.size(110.dp, 150.dp), letterSize = 46)
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                item.title,
                                style = MaterialTheme.typography.headlineSmall,
                                maxLines = 3,
                                overflow = TextOverflow.Ellipsis
                            )
                            Spacer(Modifier.height(5.dp))
                            Text(
                                item.originalTitle,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(Modifier.height(9.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                if (item.rating != null) {
                                    Icon(
                                        Icons.Filled.Star,
                                        null,
                                        tint = MaterialTheme.colorScheme.secondary,
                                        modifier = Modifier.size(15.dp)
                                    )
                                    Spacer(Modifier.width(4.dp))
                                    Text(
                                        formatRating(item.rating),
                                        style = MaterialTheme.typography.labelLarge
                                    )
                                    Spacer(Modifier.width(10.dp))
                                }
                                Text(
                                    item.kind.label + " · " + item.year,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }

            item(key = "genres") {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 18.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    item { Pill(item.releaseStatus, true) {} }
                    items(item.genres) { genre -> Pill(genre, false) {} }
                }
            }

            item(key = "actions") {
                Row(Modifier.fillMaxWidth().padding(18.dp)) {
                    Button(
                        onClick = { openReader(item.id, chapters.firstOrNull()?.number ?: 1) },
                        modifier = Modifier.weight(1f).height(52.dp),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.secondary,
                            contentColor = Color.White
                        )
                    ) {
                        Icon(Icons.Filled.MenuBook, null, Modifier.size(19.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Продолжить чтение")
                    }
                    Spacer(Modifier.width(10.dp))
                    OutlinedIconButton(
                        onClick = {},
                        modifier = Modifier.size(52.dp),
                        shape = RoundedCornerShape(14.dp)
                    ) { Icon(Icons.Outlined.BookmarkBorder, "В закладки") }
                    Spacer(Modifier.width(10.dp))
                    OutlinedIconButton(
                        onClick = {},
                        modifier = Modifier.size(52.dp),
                        shape = RoundedCornerShape(14.dp)
                    ) { Icon(Icons.Outlined.Share, "Поделиться") }
                }
            }

            item(key = "description") {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { expanded = !expanded }
                        .padding(horizontal = 18.dp)
                ) {
                    Text("Описание", style = MaterialTheme.typography.titleLarge)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        item.description,
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = if (expanded) 30 else 3,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        if (expanded) "Свернуть" else "Читать полностью",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.secondary
                    )
                }
            }

            item(key = "chaptersHeader") {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 18.dp, end = 18.dp, top = 26.dp, bottom = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Главы", style = MaterialTheme.typography.titleLarge)
                    Spacer(Modifier.width(8.dp))
                    Text(
                        "всего " + item.chapters,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            items(chapters, key = { it.number }) { chapter ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { openReader(item.id, chapter.number) }
                        .padding(horizontal = 18.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        chapter.number.toString(),
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier.width(46.dp)
                    )
                    Column(Modifier.weight(1f)) {
                        Text(chapter.name, style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(3.dp))
                        Text(
                            chapter.pages.toString() + " стр. · " + chapter.published,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.22f))
            }
        }

        Surface(
            shape = CircleShape,
            color = MaterialTheme.colorScheme.background.copy(alpha = 0.72f),
            modifier = Modifier
                .statusBarsPadding()
                .padding(12.dp)
                .size(42.dp)
                .clickable(onClick = onBack)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, "Назад")
            }
        }
    }
}
