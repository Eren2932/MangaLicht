package ru.mangalicht.app.ui

import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.Explore
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import ru.mangalicht.app.ui.screens.BookmarksScreen
import ru.mangalicht.app.ui.screens.CatalogScreen
import ru.mangalicht.app.ui.screens.DetailsScreen
import ru.mangalicht.app.ui.screens.HomeScreen
import ru.mangalicht.app.ui.screens.ProfileScreen
import ru.mangalicht.app.ui.screens.ReaderScreen

object Routes {
    const val HOME = "home"
    const val CATALOG = "catalog"
    const val BOOKMARKS = "bookmarks"
    const val PROFILE = "profile"
    const val DETAILS = "details"
    const val READER = "reader"
}

private data class TabItem(
    val route: String,
    val label: String,
    val active: ImageVector,
    val idle: ImageVector
)

private val tabItems = listOf(
    TabItem(Routes.HOME, "Главная", Icons.Filled.Home, Icons.Outlined.Home),
    TabItem(Routes.CATALOG, "Обзор", Icons.Filled.Explore, Icons.Outlined.Explore),
    TabItem(Routes.BOOKMARKS, "Закладки", Icons.Filled.Bookmark, Icons.Outlined.BookmarkBorder),
    TabItem(Routes.PROFILE, "Профиль", Icons.Filled.Person, Icons.Outlined.Person)
)

private const val TAB_ANIM = 120
private const val PUSH_ANIM = 170

@Composable
fun MangaLichtApp() {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val destination = backStackEntry?.destination
    val currentRoute = destination?.route.orEmpty()
    val fullScreen = currentRoute.startsWith(Routes.DETAILS) || currentRoute.startsWith(Routes.READER)

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            if (!fullScreen) {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    tonalElevation = 0.dp
                ) {
                    tabItems.forEach { tab ->
                        val selected = destination?.hierarchy?.any { it.route == tab.route } == true
                        NavigationBarItem(
                            selected = selected,
                            alwaysShowLabel = true,
                            onClick = {
                                if (!selected) {
                                    navController.navigate(tab.route) {
                                        popUpTo(navController.graph.findStartDestination().id) {
                                            saveState = true
                                        }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                            },
                            icon = {
                                Icon(
                                    imageVector = if (selected) tab.active else tab.idle,
                                    contentDescription = tab.label
                                )
                            },
                            label = {
                                Text(tab.label, style = MaterialTheme.typography.labelSmall)
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = MaterialTheme.colorScheme.secondary,
                                selectedTextColor = MaterialTheme.colorScheme.secondary,
                                indicatorColor = MaterialTheme.colorScheme.secondary.copy(alpha = 0.14f),
                                unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                    }
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = Routes.HOME,
            modifier = Modifier.fillMaxSize(),
            enterTransition = { fadeIn(tween(TAB_ANIM)) },
            exitTransition = { fadeOut(tween(TAB_ANIM)) },
            popEnterTransition = { fadeIn(tween(TAB_ANIM)) },
            popExitTransition = { fadeOut(tween(TAB_ANIM)) }
        ) {
            composable(Routes.HOME) {
                HomeScreen(
                    padding = padding,
                    openCatalog = { navController.switchTab(Routes.CATALOG) },
                    openTitle = navController::openTitle
                )
            }
            composable(Routes.CATALOG) {
                CatalogScreen(padding = padding, openTitle = navController::openTitle)
            }
            composable(Routes.BOOKMARKS) {
                BookmarksScreen(padding = padding, openTitle = navController::openTitle)
            }
            composable(Routes.PROFILE) {
                ProfileScreen(padding = padding, openTitle = navController::openTitle)
            }
            composable(
                route = Routes.DETAILS + "/{titleId}",
                enterTransition = {
                    slideInHorizontally(tween(PUSH_ANIM)) { full -> full / 5 } + fadeIn(tween(PUSH_ANIM))
                },
                exitTransition = { fadeOut(tween(TAB_ANIM)) },
                popExitTransition = {
                    slideOutHorizontally(tween(PUSH_ANIM)) { full -> full / 5 } + fadeOut(tween(PUSH_ANIM))
                }
            ) { entry ->
                DetailsScreen(
                    titleId = entry.arguments?.getString("titleId")?.toIntOrNull() ?: 1,
                    onBack = { navController.popBackStack() },
                    openReader = { id, chapter ->
                        navController.navigate(Routes.READER + "/" + id + "/" + chapter) {
                            launchSingleTop = true
                        }
                    }
                )
            }
            composable(
                route = Routes.READER + "/{titleId}/{chapter}",
                enterTransition = {
                    fadeIn(tween(TAB_ANIM)) + scaleIn(tween(TAB_ANIM), initialScale = 0.99f)
                },
                popExitTransition = {
                    fadeOut(tween(TAB_ANIM)) + scaleOut(tween(TAB_ANIM), targetScale = 0.99f)
                }
            ) { entry ->
                ReaderScreen(
                    titleId = entry.arguments?.getString("titleId")?.toIntOrNull() ?: 1,
                    chapter = entry.arguments?.getString("chapter")?.toIntOrNull() ?: 1,
                    onBack = { navController.popBackStack() }
                )
            }
        }
    }
}

private fun NavHostController.openTitle(id: Int) {
    navigate(Routes.DETAILS + "/" + id) { launchSingleTop = true }
}

private fun NavHostController.switchTab(route: String) {
    navigate(route) {
        popUpTo(graph.findStartDestination().id) { saveState = true }
        launchSingleTop = true
        restoreState = true
    }
}
