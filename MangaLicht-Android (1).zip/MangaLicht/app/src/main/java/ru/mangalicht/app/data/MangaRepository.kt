package ru.mangalicht.app.data

/**
 * Единая точка данных приложения. Сейчас работает локальная реализация.
 * Для подключения backend достаточно добавить RemoteMangaRepository с тем же
 * контрактом и подменить реализацию в ServiceLocator: экраны не изменятся.
 */
interface MangaRepository {
    fun titles(): List<TitleItem>
    fun titleById(id: Int): TitleItem?
    fun chapters(id: Int): List<ChapterItem>
    fun history(): List<HistoryEntry>
    fun ratings(): List<RatingEntry>
    fun activity(): List<Pair<String, Int>>
    fun profile(): UserProfile
    fun topics(): List<ForumTopic>
}

class LocalMangaRepository : MangaRepository {
    override fun titles() = DemoData.titles
    override fun titleById(id: Int) = DemoData.titles.firstOrNull { it.id == id }
    override fun chapters(id: Int) = titleById(id)?.let { DemoData.chaptersFor(it) } ?: emptyList()
    override fun history() = DemoData.history
    override fun ratings() = DemoData.ratings
    override fun activity() = DemoData.activity
    override fun profile() = DemoData.profile
    override fun topics() = DemoData.topics
}

object ServiceLocator {
    val repository: MangaRepository by lazy { LocalMangaRepository() }
}
