package ru.mangalicht.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import ru.mangalicht.app.data.ServiceLocator
import ru.mangalicht.app.data.TitleKind
import ru.mangalicht.app.ui.components.Pill
import ru.mangalicht.app.ui.components.TitleGridCard

private enum class SortMode(val label: String) {
    RATING("По рейтингу"),
    NEW("Новые"),
    CHAPTERS("Больше глав"),
    NAME("По алфавиту")
}

@Composable
fun CatalogScreen(padding: PaddingValues, openTitle: (Int) -> Unit) {
    val repository = ServiceLocator.repository
    var query by rememberSaveable { mutableStateOf("") }
    var kindName by rememberSaveable { mutableStateOf<String?>(null) }
    var sortName by rememberSaveable { mutableStateOf(SortMode.RATING.name) }
    val gridState = rememberLazyGridState()

    val kind = kindName?.let { name -> TitleKind.entries.first { it.name == name } }
    val sort = SortMode.entries.first { it.name == sortName }

    val items = remember(query, kindName, sortName) {
        repository.titles()
            .filter { item ->
                (kind == null || item.kind == kind) &&
                    (query.isBlank() ||
                        item.title.contains(query, ignoreCase = true) ||
                        item.originalTitle.contains(query, ignoreCase = true) ||
                        item.genres.any { it.contains(query, ignoreCase = true) })
            }
            .let { list ->
                when (sort) {
                    SortMode.RATING -> list.sortedByDescending { it.rating ?: 0.0 }
                    SortMode.NEW -> list.sortedByDescending { it.year }
                    SortMode.CHAPTERS -> list.sortedByDescending { it.chapters }
                    SortMode.NAME -> list.sortedBy { it.title }
                }
            }
    }

    LazyVerticalGrid(
        columns = GridCells.Adaptive(158.dp),
        state = gridState,
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(
            start = 16.dp,
            end = 16.dp,
            bottom = padding.calculateBottomPadding() + 26.dp
        ),
        horizontalArrangement = Arrangement.spacedBy(14.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        item(span = { GridItemSpan(maxLineSpan) }, key = "header") {
            Column(Modifier.statusBarsPadding().padding(top = 10.dp)) {
                Text("Каталог", style = MaterialTheme.typography.headlineMedium)
                Spacer(Modifier.height(4.dp))
                Text(
                    "Манга, манхва, маньхуа и вебтуны",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(14.dp))
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Название, оригинал или жанр") },
                    leadingIcon = { Icon(Icons.Outlined.Search, null) },
                    trailingIcon = {
                        if (query.isNotEmpty()) {
                            IconButton(onClick = { query = "" }) {
                                Icon(Icons.Outlined.Close, "Очистить")
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search)
                )
                Spacer(Modifier.height(12.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    item { Pill("Все типы", kindName == null) { kindName = null } }
                    items(TitleKind.entries.toList()) { value ->
                        Pill(value.label, kindName == value.name) {
                            kindName = if (kindName == value.name) null else value.name
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(SortMode.entries.toList()) { mode ->
                        Pill(mode.label, sortName == mode.name) { sortName = mode.name }
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    "Найдено: " + items.size,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        if (items.isEmpty()) {
            item(span = { GridItemSpan(maxLineSpan) }, key = "empty") {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 60.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("Ничего не найдено", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Измени запрос или сбрось фильтры",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(14.dp))
                    Button(onClick = { query = ""; kindName = null }) { Text("Сбросить") }
                }
            }
        } else {
            items(items, key = { it.id }) { item ->
                TitleGridCard(item = item, onClick = { openTitle(item.id) })
            }
        }
    }
}
