package ru.mangalicht.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import ru.mangalicht.app.ui.MangaLichtApp
import ru.mangalicht.app.ui.theme.MangaLichtTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContent {
            MangaLichtTheme { MangaLichtApp() }
        }
    }
}
