package ru.mangalicht.app.data

enum class TitleKind(val label: String) {
    MANGA("Манга"), MANHWA("Манхва"), MANHUA("Маньхуа"), WEBTOON("Вебтун")
}

enum class ReadingStatus(val label: String) {
    READING("Читаю"), PLANNED("В планах"), COMPLETED("Прочитано"),
    ON_HOLD("Отложено"), DROPPED("Брошено")
}

data class TitleItem(
    val id: Int,
    val title: String,
    val originalTitle: String,
    val description: String,
    val kind: TitleKind,
    val genres: List<String>,
    val year: Int,
    val chapters: Int,
    val rating: Double?,
    val releaseStatus: String,
    val paletteSeed: Int
)

data class ChapterItem(val number: Int, val name: String, val pages: Int, val published: String)

data class HistoryEntry(val titleId: Int, val title: String, val chapter: Int, val whenLabel: String, val paletteSeed: Int)

data class RatingEntry(val titleId: Int, val title: String, val stars: Int, val whenLabel: String, val paletteSeed: Int)

data class ForumTopic(val id: Int, val title: String, val category: String, val author: String, val age: String, val comments: Int, val views: Int)

data class UserProfile(
    val nickname: String,
    val level: Int,
    val status: String,
    val online: Boolean,
    val comments: Int,
    val reviews: Int,
    val collections: Int,
    val friends: Int,
    val chaptersRead: Int,
    val readingTime: String,
    val counters: Map<ReadingStatus, Int>
)
