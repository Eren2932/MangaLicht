package ru.mangalicht.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.NotificationsNone
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import ru.mangalicht.app.data.ReadingStatus
import ru.mangalicht.app.data.ServiceLocator
import ru.mangalicht.app.ui.components.ActivityChart
import ru.mangalicht.app.ui.components.CoverArt
import ru.mangalicht.app.ui.components.DonutChart
import ru.mangalicht.app.ui.components.LegendRow
import ru.mangalicht.app.ui.components.SectionHeader
import ru.mangalicht.app.ui.components.StarRow
import ru.mangalicht.app.ui.components.gradientFor
import ru.mangalicht.app.ui.theme.AlertDark
import ru.mangalicht.app.ui.theme.BlueStat
import ru.mangalicht.app.ui.theme.GreenDark
import ru.mangalicht.app.ui.theme.PurpleStat
import ru.mangalicht.app.ui.theme.YellowLight

private val statusColors = mapOf(
    ReadingStatus.READING to GreenDark,
    ReadingStatus.PLANNED to PurpleStat,
    ReadingStatus.COMPLETED to BlueStat,
    ReadingStatus.ON_HOLD to YellowLight,
    ReadingStatus.DROPPED to AlertDark
)

@Composable
fun ProfileScreen(padding: PaddingValues, openTitle: (Int) -> Unit) {
    val repository = ServiceLocator.repository
    val profile = repository.profile()

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = padding.calculateBottomPadding() + 26.dp)
    ) {
        item(key = "searchBar") {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(50),
                    color = MaterialTheme.colorScheme.surfaceContainer,
                    modifier = Modifier.weight(1f).clickable { }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Outlined.Search,
                            null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(Modifier.width(10.dp))
                        Text(
                            "Поиск пользователей",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                IconButton(onClick = {}) { Icon(Icons.Outlined.Settings, "Настройки") }
                IconButton(onClick = {}) { Icon(Icons.Outlined.NotificationsNone, "Уведомления") }
            }
        }

        item(key = "identity") {
            Column(
                modifier = Modifier.fillMaxWidth().padding(top = 10.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(112.dp)
                        .background(
                            Brush.linearGradient(gradientFor(profile.nickname.length)),
                            CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        profile.nickname.take(1),
                        style = MaterialTheme.typography.headlineLarge,
                        color = Color.White.copy(alpha = 0.9f)
                    )
                }
                Spacer(Modifier.height(14.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(profile.nickname, style = MaterialTheme.typography.headlineSmall)
                    Spacer(Modifier.width(8.dp))
                    Surface(
                        shape = RoundedCornerShape(50),
                        color = Color.Transparent,
                        border = BorderStroke(1.dp, GreenDark.copy(alpha = 0.6f))
                    ) {
                        Text(
                            profile.level.toString(),
                            style = MaterialTheme.typography.labelSmall,
                            color = GreenDark,
                            modifier = Modifier.padding(horizontal = 9.dp, vertical = 2.dp)
                        )
                    }
                }
                Spacer(Modifier.height(5.dp))
                Text(
                    profile.status,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    if (profile.online) "онлайн" else "не в сети",
                    style = MaterialTheme.typography.bodySmall,
                    color = if (profile.online) GreenDark else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        item(key = "counters") {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 22.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                ProfileCounter(profile.comments, "комментариев")
                ProfileCounter(profile.reviews, "отзывов")
                ProfileCounter(profile.collections, "коллекций")
                ProfileCounter(profile.friends, "друзей")
            }
        }

        item(key = "actions") {
            Column(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                OutlinedButton(
                    onClick = {},
                    modifier = Modifier.fillMaxWidth().height(50.dp),
                    shape = RoundedCornerShape(50),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = MaterialTheme.colorScheme.secondary
                    ),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
                ) { Text("Редактировать профиль") }
                Spacer(Modifier.height(12.dp))
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceContainer,
                    modifier = Modifier.size(width = 74.dp, height = 42.dp).clickable { }
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            Icons.Outlined.Add,
                            "Добавить",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Spacer(Modifier.height(20.dp))
                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.35f))
            }
        }

        item(key = "stats") {
            Column(Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Статистика", style = MaterialTheme.typography.titleLarge)
                    Spacer(Modifier.width(7.dp))
                    Icon(
                        Icons.Outlined.Info,
                        null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(Modifier.weight(1f))
                    Text(
                        "Показать все",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier.clickable { }
                    )
                }
                Spacer(Modifier.height(18.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        ReadingStatus.entries.forEach { value ->
                            LegendRow(
                                color = statusColors[value] ?: BlueStat,
                                label = value.label,
                                value = profile.counters[value] ?: 0
                            )
                        }
                    }
                    DonutChart(
                        values = ReadingStatus.entries.map { value ->
                            (statusColors[value] ?: BlueStat) to (profile.counters[value] ?: 0)
                        },
                        modifier = Modifier.size(142.dp)
                    )
                }
                Spacer(Modifier.height(18.dp))
                StatLine("Прочитано глав", profile.chaptersRead.toString())
                StatLine("Время чтения", profile.readingTime)
            }
        }

        item(key = "ratingsHeader") {
            Column(Modifier.padding(horizontal = 16.dp)) {
                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.35f))
                Spacer(Modifier.height(20.dp))
                SectionHeader(title = "Оценки тайтлов", action = "Показать все")
                Spacer(Modifier.height(6.dp))
            }
        }

        items(repository.ratings(), key = { "rating" + it.titleId }) { entry ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { openTitle(entry.titleId) }
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                CoverArt(entry.title, entry.paletteSeed, Modifier.size(52.dp, 70.dp), letterSize = 26)
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        entry.title,
                        style = MaterialTheme.typography.titleMedium,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(Modifier.height(6.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        StarRow(entry.stars)
                        Spacer(Modifier.width(8.dp))
                        Text(
                            entry.whenLabel,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        item(key = "activity") {
            Column(Modifier.padding(16.dp)) {
                Spacer(Modifier.height(6.dp))
                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.35f))
                Spacer(Modifier.height(20.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Динамика чтения глав", style = MaterialTheme.typography.titleLarge)
                    Spacer(Modifier.width(7.dp))
                    Icon(
                        Icons.Outlined.Info,
                        null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(16.dp)
                    )
                }
                Spacer(Modifier.height(18.dp))
                ActivityChart(repository.activity(), Modifier.fillMaxWidth())
            }
        }

        item(key = "historyHeader") {
            Column(Modifier.padding(horizontal = 16.dp)) {
                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.35f))
                Spacer(Modifier.height(20.dp))
                SectionHeader(title = "Прочитано недавно", action = "Показать все")
                Spacer(Modifier.height(6.dp))
            }
        }

        items(repository.history(), key = { "history" + it.titleId }) { entry ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { openTitle(entry.titleId) }
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                CoverArt(entry.title, entry.paletteSeed, Modifier.size(52.dp, 70.dp), letterSize = 26)
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        entry.title,
                        style = MaterialTheme.typography.titleMedium,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(Modifier.height(5.dp))
                    Text(
                        "Глава " + entry.chapter + " · " + entry.whenLabel,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        item(key = "version") {
            Text(
                "MangaLicht 0.2.0",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(vertical = 24.dp)
            )
        }
    }
}

@Composable
private fun ProfileCounter(value: Int, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value.toString(), style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(3.dp))
        Text(
            label,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun StatLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Text(
            label + ":",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.width(8.dp))
        Text(value, style = MaterialTheme.typography.labelLarge)
    }
}
