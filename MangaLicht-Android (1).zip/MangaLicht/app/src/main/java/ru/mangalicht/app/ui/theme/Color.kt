package ru.mangalicht.app.ui.theme

import androidx.compose.ui.graphics.Color

val White = Color(0xFFFFFFFF)
val Grey50 = Color(0xFFE4E5E7)
val Grey100 = Color(0xFFC9CBCF)
val Grey200 = Color(0xFFAEB1B7)
val Grey300 = Color(0xFF93969F)
val Grey500 = Color(0xFF60636C)
val Grey600 = Color(0xFF484A51)
val Grey700 = Color(0xFF303136)
val Grey800 = Color(0xFF18181B)
val Grey850 = Color(0xFF101013)
val BlackPure = Color(0xFF000000)

val AccentLight = Color(0xFF168FFF)
val AccentDark = Color(0xFF0085FF)
val AlertLight = Color(0xFFC41E3A)
val AlertDark = Color(0xFFE4334A)
val YellowLight = Color(0xFFF0B32D)
val GreenLight = Color(0xFF7ADC92)
val GreenDark = Color(0xFF40DD8F)
val PurpleStat = Color(0xFF9B6BE0)
val BlueStat = Color(0xFF5A63D8)
