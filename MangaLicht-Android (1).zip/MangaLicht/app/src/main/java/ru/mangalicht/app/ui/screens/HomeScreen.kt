package ru.mangalicht.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.outlined.NotificationsNone
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import ru.mangalicht.app.data.ServiceLocator
import ru.mangalicht.app.ui.components.CoverArt
import ru.mangalicht.app.ui.components.SectionHeader
import ru.mangalicht.app.ui.components.TitleGridCard
import ru.mangalicht.app.ui.components.gradientFor

@Composable
fun HomeScreen(padding: PaddingValues, openCatalog: () -> Unit, openTitle: (Int) -> Unit) {
    val repository = ServiceLocator.repository
    val titles = repository.titles()
    val hero = titles.first()
    val listState = rememberLazyListState()

    LazyColumn(
        state = listState,
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = padding.calculateBottomPadding() + 26.dp)
    ) {
        item(key = "topbar") {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 18.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "Manga",
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.secondary
                )
                Text("Licht", style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.weight(1f))
                IconButton(onClick = openCatalog) { Icon(Icons.Outlined.Search, "Поиск") }
                IconButton(onClick = {}) { Icon(Icons.Outlined.NotificationsNone, "Уведомления") }
            }
        }

        item(key = "hero") {
            Box(
                modifier = Modifier
                    .padding(horizontal = 16.dp)
                    .fillMaxWidth()
                    .height(340.dp)
                    .background(
                        Brush.verticalGradient(gradientFor(hero.paletteSeed)),
                        RoundedCornerShape(22.dp)
                    )
            ) {
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(20.dp)
                ) {
                    Text(
                        "НОВИНКА НЕДЕЛИ",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.secondary
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        hero.title,
                        style = MaterialTheme.typography.headlineLarge,
                        color = Color.White,
                        maxLines = 3,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(Modifier.height(10.dp))
                    Text(
                        hero.description,
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color.White.copy(alpha = 0.74f),
                        maxLines = 3,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(Modifier.height(16.dp))
                    Row {
                        Button(
                            onClick = { openTitle(hero.id) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.secondary,
                                contentColor = Color.White
                            )
                        ) {
                            Icon(Icons.Filled.MenuBook, null, Modifier.size(18.dp))
                            Spacer(Modifier.width(7.dp))
                            Text("Читать")
                        }
                        Spacer(Modifier.width(10.dp))
                        OutlinedButton(
                            onClick = openCatalog,
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)
                        ) { Text("Каталог") }
                    }
                }
            }
        }

        item(key = "continueReading") {
            Column(Modifier.padding(top = 26.dp)) {
                SectionHeader(
                    title = "Продолжить чтение",
                    action = "Все",
                    onAction = openCatalog,
                    modifier = Modifier.padding(horizontal = 18.dp)
                )
                Spacer(Modifier.height(12.dp))
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 18.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(repository.history(), key = { it.titleId }) { entry ->
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = MaterialTheme.colorScheme.surfaceContainer,
                            modifier = Modifier
                                .width(252.dp)
                                .clickable { openTitle(entry.titleId) }
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                CoverArt(entry.title, entry.paletteSeed, Modifier.size(52.dp, 72.dp), letterSize = 26)
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(
                                        entry.title,
                                        style = MaterialTheme.typography.titleSmall,
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Spacer(Modifier.height(6.dp))
                                    Text(
                                        "Глава " + entry.chapter,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Spacer(Modifier.height(8.dp))
                                    LinearProgressIndicator(
                                        progress = { 0.3f + entry.titleId % 5 * 0.12f },
                                        modifier = Modifier.fillMaxWidth().height(4.dp),
                                        color = MaterialTheme.colorScheme.secondary,
                                        trackColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        item(key = "newChapters") {
            Column(Modifier.padding(top = 26.dp)) {
                SectionHeader(
                    title = "Новые главы",
                    action = "Все",
                    onAction = openCatalog,
                    modifier = Modifier.padding(horizontal = 18.dp)
                )
                Spacer(Modifier.height(12.dp))
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 18.dp),
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    items(titles.take(8), key = { it.id }) { item ->
                        Box(Modifier.width(140.dp)) {
                            TitleGridCard(item = item, onClick = { openTitle(item.id) })
                        }
                    }
                }
            }
        }

        item(key = "popularHeader") {
            Box(Modifier.padding(start = 18.dp, end = 18.dp, top = 28.dp, bottom = 10.dp)) {
                SectionHeader(title = "Популярное сейчас")
            }
        }

        items(titles.sortedByDescending { it.rating ?: 0.0 }.take(6), key = { "popular" + it.id }) { item ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { openTitle(item.id) }
                    .padding(horizontal = 18.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                CoverArt(item.title, item.paletteSeed, Modifier.size(58.dp, 78.dp), letterSize = 28)
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        item.title,
                        style = MaterialTheme.typography.titleMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        item.kind.label + " · " + item.genres.joinToString(", "),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Глав: " + item.chapters,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}
